﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using ClosedXML.Excel;

namespace PotroCao
{
    // Regras e funções reaproveitadas pelas telas novas
    public static class Utilitarios
    {
        // Quantidade a partir da qual o estoque é considerado baixo
        public const int ESTOQUE_BAIXO = 5;

        // Exporta o conteúdo de um DataGridView para Excel (mesmo padrão da tela de clientes)
        public static void ExportarExcel(DataGridView grade, string nomeAba, string nomeArquivo)
        {
            DataTable tabela = grade.DataSource as DataTable;

            if (tabela == null || tabela.Rows.Count == 0)
            {
                CaixaMensagem.Show("Não existem dados para exportar!", "PotroCão",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog salvar = new SaveFileDialog())
            {
                salvar.Filter = "Arquivo Excel (*.xlsx)|*.xlsx";
                salvar.Title = "Exportar " + nomeAba;
                salvar.FileName = nomeArquivo + "_PotroCao.xlsx";
                salvar.DefaultExt = "xlsx";
                salvar.AddExtension = true;

                if (salvar.ShowDialog() != DialogResult.OK)
                    return;

                try
                {
                    using (XLWorkbook planilha = new XLWorkbook())
                    {
                        var aba = planilha.Worksheets.Add(nomeAba);

                        aba.Cell(1, 1).InsertTable(tabela, false);

                        aba.Row(1).Style.Font.Bold = true;
                        aba.Row(1).Style.Fill.BackgroundColor = XLColor.FromHtml("#6320B5");
                        aba.Row(1).Style.Font.FontColor = XLColor.White;

                        aba.Columns().AdjustToContents();
                        aba.RangeUsed().SetAutoFilter();
                        aba.SheetView.FreezeRows(1);

                        planilha.SaveAs(salvar.FileName);
                    }

                    CaixaMensagem.Show("Planilha exportada com sucesso!", "PotroCão",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception erro)
                {
                    CaixaMensagem.Show("Erro ao exportar a planilha: " + erro.Message, "PotroCão",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Pega o código da linha selecionada na grade (coluna "Código")
        public static int CodigoSelecionado(DataGridView grade)
        {
            if (grade.CurrentRow == null || grade.CurrentRow.IsNewRow)
                return 0;

            object valor = grade.CurrentRow.Cells["Código"].Value;

            if (valor == null || valor == DBNull.Value)
                return 0;

            return Convert.ToInt32(valor);
        }

        // Lê o texto de uma coluna da linha selecionada
        public static string TextoSelecionado(DataGridView grade, string coluna)
        {
            if (grade.CurrentRow == null || grade.CurrentRow.IsNewRow)
                return "";

            object valor = grade.CurrentRow.Cells[coluna].Value;
            return valor == null ? "" : valor.ToString();
        }

        // Pinta de cinza as linhas inativas
        public static void DestacarInativos(DataGridView grade, string colunaSituacao)
        {
            if (!grade.Columns.Contains(colunaSituacao))
                return;

            foreach (DataGridViewRow linha in grade.Rows)
            {
                string situacao = Convert.ToString(linha.Cells[colunaSituacao].Value);

                if (situacao.StartsWith("Inativ"))
                {
                    linha.DefaultCellStyle.ForeColor = Color.Gray;
                    linha.DefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
                }
            }
        }

        public static void Erro(string mensagem)
        {
            CaixaMensagem.Show(mensagem, "PotroCão", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static void Aviso(string mensagem)
        {
            CaixaMensagem.Show(mensagem, "PotroCão", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void Sucesso(string mensagem)
        {
            CaixaMensagem.Show(mensagem, "PotroCão", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static bool Confirmar(string mensagem, string titulo)
        {
            return CaixaMensagem.Show(mensagem, titulo, MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes;
        }
    }
}
