﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmConsultarCategoria : Form
    {
        // Qual lista está sendo exibida: "ativas", "inativas" ou "todas"
        private string filtroAtual = "ativas";

        public FrmConsultarCategoria()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void FrmConsultarCategoria_Load(object sender, EventArgs e)
        {
            CarregarCategorias();
        }

        private void CarregarCategorias()
        {
            string condicao;

            if (filtroAtual == "inativas")
            {
                condicao = "c.ativo = 0";
                lblExibindoCategoria.Text = "Exibindo: categorias inativas";
            }
            else if (filtroAtual == "todas")
            {
                condicao = "1 = 1";
                lblExibindoCategoria.Text = "Exibindo: todas as categorias";
            }
            else
            {
                condicao = "c.ativo = 1";
                lblExibindoCategoria.Text = "Exibindo: categorias ativas";
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            c.codCategoria AS 'Código',
                            c.nome AS 'Nome',
                            c.descricao AS 'Descrição',
                            (SELECT COUNT(*) FROM produto p
                              WHERE p.codCategoria = c.codCategoria
                              AND p.ativo = 1) AS 'Produtos ativos',
                            CASE WHEN c.ativo = 1 THEN 'Ativa' ELSE 'Inativa' END AS 'Situação'
                        FROM categoria_produto c
                        WHERE " + condicao + @"
                        AND c.nome LIKE @pesquisa
                        ORDER BY c.nome";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@pesquisa",
                            "%" + txtPesquisarCategoria.Text.Trim() + "%");

                        using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                        {
                            DataTable tabela = new DataTable();
                            adaptador.Fill(tabela);
                            dgvCategorias.DataSource = tabela;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar categorias: " + ex.Message);
            }
        }

        private void dgvCategorias_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (dgvCategorias.Columns.Contains("Código"))
                dgvCategorias.Columns["Código"].FillWeight = 40;

            if (dgvCategorias.Columns.Contains("Descrição"))
                dgvCategorias.Columns["Descrição"].FillWeight = 200;

            if (dgvCategorias.Columns.Contains("Produtos ativos"))
                dgvCategorias.Columns["Produtos ativos"].FillWeight = 60;

            if (dgvCategorias.Columns.Contains("Situação"))
                dgvCategorias.Columns["Situação"].FillWeight = 50;

            Utilitarios.DestacarInativos(dgvCategorias, "Situação");
        }

        // ---------- PESQUISA E FILTROS ----------

        private void btnPesquisarCategoria_Click(object sender, EventArgs e)
        {
            CarregarCategorias();
        }

        private void btnAtualizarCategoria_Click(object sender, EventArgs e)
        {
            txtPesquisarCategoria.Clear();
            filtroAtual = "ativas";
            CarregarCategorias();
        }

        private void btnVerAtivasCategoria_Click(object sender, EventArgs e)
        {
            filtroAtual = "ativas";
            CarregarCategorias();
        }

        private void btnVerInativasCategoria_Click(object sender, EventArgs e)
        {
            filtroAtual = "inativas";
            CarregarCategorias();
        }

        private void btnVerTodasCategorias_Click(object sender, EventArgs e)
        {
            filtroAtual = "todas";
            CarregarCategorias();
        }

        // ---------- NOVA / EDITAR ----------

        private void btnNovaCategoria_Click(object sender, EventArgs e)
        {
            using (FrmCadastrarCategoria tela = new FrmCadastrarCategoria())
            {
                tela.ShowDialog();
            }

            CarregarCategorias();
        }

        private void btnEditarCategoria_Click(object sender, EventArgs e)
        {
            EditarSelecionada();
        }

        private void dgvCategorias_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                EditarSelecionada();
        }

        private void EditarSelecionada()
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvCategorias);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione uma categoria para editar!");
                return;
            }

            using (FrmCadastrarCategoria tela = new FrmCadastrarCategoria())
            {
                tela.CarregarCategoria(codigo);
                tela.ShowDialog();
            }

            CarregarCategorias();
        }

        // ---------- INATIVAR / REATIVAR ----------

        private void btnInativarCategoria_Click(object sender, EventArgs e)
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvCategorias);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione uma categoria para inativar!");
                return;
            }

            if (Utilitarios.TextoSelecionado(dgvCategorias, "Situação") == "Inativa")
            {
                Utilitarios.Aviso("Essa categoria já está inativa.");
                return;
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    // Não deixa inativar categoria que ainda tem produtos ativos
                    string sqlProdutos = @"SELECT COUNT(*) FROM produto
                                           WHERE codCategoria = @codigo AND ativo = 1";

                    using (MySqlCommand verificar = new MySqlCommand(sqlProdutos, conexao))
                    {
                        verificar.Parameters.AddWithValue("@codigo", codigo);
                        int qtd = Convert.ToInt32(verificar.ExecuteScalar());

                        if (qtd > 0)
                        {
                            Utilitarios.Aviso("Não é possível inativar esta categoria.\n\n" +
                                "Existem " + qtd + " produto(s) ativo(s) vinculado(s) a ela.\n" +
                                "Inative ou mude a categoria desses produtos primeiro.");
                            return;
                        }
                    }

                    if (!Utilitarios.Confirmar("Deseja realmente inativar esta categoria?",
                                               "Confirmar inativação"))
                        return;

                    string sql = @"UPDATE categoria_produto SET ativo = 0
                                   WHERE codCategoria = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@codigo", codigo);
                        comando.ExecuteNonQuery();
                    }
                }

                Utilitarios.Sucesso("Categoria inativada com sucesso!");
                CarregarCategorias();
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao inativar categoria: " + ex.Message);
            }
        }

        private void btnReativarCategoria_Click(object sender, EventArgs e)
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvCategorias);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione uma categoria para reativar!\n\n" +
                    "Dica: clique em \"Ver Inativas\" para listar as categorias inativas.");
                return;
            }

            if (Utilitarios.TextoSelecionado(dgvCategorias, "Situação") == "Ativa")
            {
                Utilitarios.Aviso("Essa categoria já está ativa.");
                return;
            }

            if (!Utilitarios.Confirmar("Deseja realmente reativar esta categoria?",
                                       "Confirmar reativação"))
                return;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"UPDATE categoria_produto SET ativo = 1
                                   WHERE codCategoria = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@codigo", codigo);
                        comando.ExecuteNonQuery();
                    }
                }

                Utilitarios.Sucesso("Categoria reativada com sucesso!");
                CarregarCategorias();
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao reativar categoria: " + ex.Message);
            }
        }

        // ---------- EXPORTAR / VOLTAR ----------

        private void btnExportarCategorias_Click(object sender, EventArgs e)
        {
            Utilitarios.ExportarExcel(dgvCategorias, "Categorias", "Categorias");
        }

        private void btnVoltarCategoria_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
