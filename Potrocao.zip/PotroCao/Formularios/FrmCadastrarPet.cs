﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmCadastrarPet : Form
    {
        private int codigoPet = 0;

        public FrmCadastrarPet()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void CarregarClientes()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = "SELECT codCli, nome FROM cliente ORDER BY nome";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    cmbDonoPet.DataSource = tabela;
                    cmbDonoPet.DisplayMember = "nome";
                    cmbDonoPet.ValueMember = "codCli";
                    cmbDonoPet.SelectedIndex = -1;
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao carregar clientes: " + erro.Message);
            }
        }

        public void CarregarPet(int codigo)
        {
            codigoPet = codigo;

            CarregarClientes();

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT nome, especie, raca, codCli
                                   FROM pet
                                   WHERE codpet = @codigo";

                    MySqlCommand comando = new MySqlCommand(sql, conexao);
                    comando.Parameters.AddWithValue("@codigo", codigo);

                    using (MySqlDataReader leitor = comando.ExecuteReader())
                    {
                        if (leitor.Read())
                        {
                            txtNomePet.Text = leitor["nome"].ToString();
                            cmbEspecie.Text = leitor["especie"].ToString();
                            txtRacaPet.Text = leitor["raca"].ToString();

                            cmbDonoPet.SelectedValue =
                                Convert.ToInt32(leitor["codCli"]);
                        }
                        else
                        {
                            CaixaMensagem.Show("Pet não encontrado!");
                        }
                    }
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao carregar dados do pet: " + erro.Message);
            }
        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FrmCadastrarPet_Load(object sender, EventArgs e)
        {
            if (codigoPet == 0)
            {
                CarregarClientes();
            }
        }

        private void btnSalvarPet_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNomePet.Text) ||
                cmbEspecie.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(txtRacaPet.Text) ||
                cmbDonoPet.SelectedIndex == -1)
            {
                CaixaMensagem.Show("Preencha todos os campos!");
                return;
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql;

                    if (codigoPet == 0)
                    {
                        sql = @"INSERT INTO pet
                                (nome, especie, raca, codCli)
                                VALUES
                                (@nome, @especie, @raca, @codCli)";
                    }
                    else
                    {
                        sql = @"UPDATE pet
                                SET nome = @nome,
                                    especie = @especie,
                                    raca = @raca,
                                    codCli = @codCli
                                WHERE codpet = @codigo";
                    }

                    MySqlCommand comando = new MySqlCommand(sql, conexao);

                    comando.Parameters.AddWithValue(
                        "@nome", txtNomePet.Text.Trim());

                    comando.Parameters.AddWithValue(
                        "@especie", cmbEspecie.Text);

                    comando.Parameters.AddWithValue(
                        "@raca", txtRacaPet.Text.Trim());

                    comando.Parameters.AddWithValue(
                        "@codCli", Convert.ToInt32(cmbDonoPet.SelectedValue));

                    if (codigoPet != 0)
                    {
                        comando.Parameters.AddWithValue("@codigo", codigoPet);
                    }

                    comando.ExecuteNonQuery();

                    if (codigoPet == 0)
                    {
                        CaixaMensagem.Show("Pet cadastrado com sucesso!");

                        txtNomePet.Clear();
                        cmbEspecie.SelectedIndex = -1;
                        txtRacaPet.Clear();
                        cmbDonoPet.SelectedIndex = -1;
                    }
                    else
                    {
                        CaixaMensagem.Show("Pet atualizado com sucesso!");
                        this.Close();
                    }
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao salvar pet: " + erro.Message);
            }
        }

        private void btnLimparPet_Click(object sender, EventArgs e)
        {
            txtNomePet.Clear();
            cmbEspecie.SelectedIndex = -1;
            txtRacaPet.Clear();
            cmbDonoPet.SelectedIndex = -1;
        }

        private void btnVoltarPet_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
