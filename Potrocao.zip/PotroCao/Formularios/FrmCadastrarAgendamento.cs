﻿
using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmCadastrarAgendamento : Form
    {
        private int codigoAgendamento = 0;
        private bool carregandoDados = false;

        private DateTime dataOriginal;
        private TimeSpan horarioOriginal;

        public FrmCadastrarAgendamento()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        // CARREGAR CLIENTES
        private void CarregarClientes(bool incluirInativos = false)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT codCli, nome
                                   FROM cliente";

                    if (!incluirInativos)
                        sql += " WHERE status = 'Ativo'";

                    sql += " ORDER BY nome";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    cmbClienteAgendamento.DataSource = tabela;
                    cmbClienteAgendamento.DisplayMember = "nome";
                    cmbClienteAgendamento.ValueMember = "codCli";
                    cmbClienteAgendamento.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao carregar clientes: " + ex.Message);
            }
        }

        // ABERTURA DO FORMULÁRIO
        private void FrmCadastrarAgendamento_Load(object sender, EventArgs e)
        {
            CarregarClientes(codigoAgendamento != 0);
            CarregarFuncionarios();

            cmbStatusAgendamento.Items.Clear();
            cmbStatusAgendamento.Items.Add("Pendente");
            cmbStatusAgendamento.Items.Add("Confirmado");
            cmbStatusAgendamento.Items.Add("Concluído");
            cmbStatusAgendamento.Items.Add("Cancelado");

            cmbStatusAgendamento.SelectedIndex = 0;

            if (codigoAgendamento == 0)
            {
                dtpDataAgendamento.MinDate = DateTime.Today;
                CarregarHorarios();
            }
            else
            {
                dtpDataAgendamento.MinDate =
                    DateTimePicker.MinimumDateTime;

                CarregarDadosAgendamento();
            }
        }

        // CARREGAR HORÁRIOS
        private void CarregarHorarios(bool permitirPassados = false)
        {
            cmbHorarioAgendamento.Items.Clear();

            DateTime dataEscolhida = dtpDataAgendamento.Value.Date;

            if (dataEscolhida.DayOfWeek == DayOfWeek.Sunday)
            {
                if (!permitirPassados)
                    CaixaMensagem.Show("O PotroCão não funciona aos domingos!");

                return;
            }

            DateTime inicio = dataEscolhida.AddHours(8);

            DateTime limite = dataEscolhida.AddHours(
                dataEscolhida.DayOfWeek == DayOfWeek.Saturday ? 14 : 18
            );

            while (inicio < limite)
            {
                if (permitirPassados ||
                    dataEscolhida > DateTime.Today ||
                    inicio > DateTime.Now)
                {
                    cmbHorarioAgendamento.Items.Add(
                        inicio.ToString("HH:mm")
                    );
                }

                inicio = inicio.AddMinutes(30);
            }
        }

        private void dtpDataAgendamento_ValueChanged(object sender, EventArgs e)
        {
            CarregarHorarios(codigoAgendamento != 0);
        }

        // CARREGAR PETS
        private void CarregarPets(int codigoCliente, bool incluirInativos = false)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT codpet, nome
                                   FROM pet
                                   WHERE codCli = @codigoCliente";

                    if (!incluirInativos)
                        sql += " AND status = 'Ativo'";

                    sql += " ORDER BY nome";

                    MySqlCommand comando =
                        new MySqlCommand(sql, conexao);

                    comando.Parameters.AddWithValue(
                        "@codigoCliente", codigoCliente
                    );

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(comando);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    cmbPetAgendamento.DataSource = tabela;
                    cmbPetAgendamento.DisplayMember = "nome";
                    cmbPetAgendamento.ValueMember = "codpet";
                    cmbPetAgendamento.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao carregar pets: " + ex.Message);
            }
        }

        private void cmbClienteAgendamento_SelectedIndexChanged(
            object sender, EventArgs e)
        {
            if (carregandoDados)
                return;

            if (cmbClienteAgendamento.SelectedValue == null ||
                cmbClienteAgendamento.SelectedValue is DataRowView)
                return;

            int codigoCliente =
                Convert.ToInt32(cmbClienteAgendamento.SelectedValue);

            CarregarPets(codigoCliente);
        }

        // CARREGAR FUNCIONÁRIOS
        private void CarregarFuncionarios()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql =
                        "SELECT codFun, nome FROM funcionario ORDER BY nome";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    DataRow linha = tabela.NewRow();
                    linha["codFun"] = DBNull.Value;
                    linha["nome"] = "Sem responsável";

                    tabela.Rows.InsertAt(linha, 0);

                    cmbFuncionarioAgendamento.DataSource = tabela;
                    cmbFuncionarioAgendamento.DisplayMember = "nome";
                    cmbFuncionarioAgendamento.ValueMember = "codFun";
                    cmbFuncionarioAgendamento.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao carregar funcionários: " + ex.Message);
            }
        }

        // RECEBER CÓDIGO DO AGENDAMENTO PARA EDIÇÃO
        public void CarregarAgendamento(int codigo)
        {
            codigoAgendamento = codigo;
        }

        // PREENCHER FORMULÁRIO COM DADOS EXISTENTES
        private void CarregarDadosAgendamento()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT *
                                   FROM agendamento
                                   WHERE codAgendamento = @codigo";

                    MySqlCommand comando =
                        new MySqlCommand(sql, conexao);

                    comando.Parameters.AddWithValue(
                        "@codigo", codigoAgendamento
                    );

                    using (MySqlDataReader leitor = comando.ExecuteReader())
                    {
                        if (!leitor.Read())
                        {
                            CaixaMensagem.Show("Agendamento não encontrado!");
                            Close();
                            return;
                        }

                        int codigoCliente =
                            Convert.ToInt32(leitor["codCli"]);

                        int codigoPet =
                            Convert.ToInt32(leitor["codpet"]);

                        int? codigoFuncionario =
                            leitor["codFun"] == DBNull.Value
                            ? (int?)null
                            : Convert.ToInt32(leitor["codFun"]);

                        dataOriginal =
                            Convert.ToDateTime(leitor["data"]).Date;

                        horarioOriginal =
                            (TimeSpan)leitor["horario"];

                        carregandoDados = true;

                        dtpDataAgendamento.Value = dataOriginal;

                        cmbStatusAgendamento.Text =
                            leitor["status"].ToString();

                        txtObservacoesAgendamento.Text =
                            leitor["observacoes"] == DBNull.Value
                            ? ""
                            : leitor["observacoes"].ToString();

                        leitor.Close();

                        cmbClienteAgendamento.SelectedValue = codigoCliente;

                        CarregarPets(codigoCliente, true);

                        cmbPetAgendamento.SelectedValue = codigoPet;

                        if (codigoFuncionario.HasValue)
                            cmbFuncionarioAgendamento.SelectedValue =
                                codigoFuncionario.Value;
                        else
                            cmbFuncionarioAgendamento.SelectedIndex = 0;

                        CarregarHorarios(true);

                        string horarioTexto =
                            horarioOriginal.ToString(@"hh\:mm");

                        if (!cmbHorarioAgendamento.Items.Contains(horarioTexto))
                            cmbHorarioAgendamento.Items.Add(horarioTexto);

                        cmbHorarioAgendamento.SelectedItem = horarioTexto;

                        carregandoDados = false;
                    }
                }
            }
            catch (Exception ex)
            {
                carregandoDados = false;

                CaixaMensagem.Show(
                    "Erro ao carregar agendamento: " + ex.Message
                );
            }
        }

        // SALVAR OU ATUALIZAR AGENDAMENTO
        private void btnSalvarAgendamento_Click(object sender, EventArgs e)
        {
            if (cmbClienteAgendamento.SelectedIndex == -1 ||
                cmbPetAgendamento.SelectedIndex == -1)
            {
                CaixaMensagem.Show("Selecione o cliente e o pet!");
                return;
            }

            if (cmbHorarioAgendamento.SelectedIndex == -1)
            {
                CaixaMensagem.Show("Selecione um horário disponível!");
                return;
            }

            if (cmbStatusAgendamento.SelectedIndex == -1)
            {
                CaixaMensagem.Show("Selecione o status do agendamento!");
                return;
            }

            DateTime dataEscolhida = dtpDataAgendamento.Value.Date;

            TimeSpan horarioEscolhido =
                TimeSpan.Parse(cmbHorarioAgendamento.Text);

            bool horarioAlterado =
                dataEscolhida != dataOriginal ||
                horarioEscolhido != horarioOriginal;

            if (codigoAgendamento == 0 || horarioAlterado)
            {
                if (dataEscolhida < DateTime.Today)
                {
                    CaixaMensagem.Show("Não é possível agendar em datas passadas!");
                    return;
                }

                if (dataEscolhida.DayOfWeek == DayOfWeek.Sunday)
                {
                    CaixaMensagem.Show("O PotroCão não funciona aos domingos!");
                    return;
                }

                if (dataEscolhida == DateTime.Today &&
                    horarioEscolhido <= DateTime.Now.TimeOfDay)
                {
                    CaixaMensagem.Show("Esse horário já passou! Escolha outro.");
                    CarregarHorarios(codigoAgendamento != 0);
                    return;
                }
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql;

                    if (codigoAgendamento == 0)
                    {
                        sql = @"INSERT INTO agendamento
                        (data, horario, status, observacoes, codCli, codpet, codFun)
                        VALUES
                        (@data, @horario, @status, @observacoes, @codCli, @codpet, @codFun)";
                    }
                    else
                    {
                        sql = @"UPDATE agendamento SET
                        data = @data,
                        horario = @horario,
                        status = @status,
                        observacoes = @observacoes,
                        codCli = @codCli,
                        codpet = @codpet,
                        codFun = @codFun
                        WHERE codAgendamento = @codigo";
                    }

                    MySqlCommand comando =
                        new MySqlCommand(sql, conexao);

                    comando.Parameters.AddWithValue(
                        "@data", dataEscolhida
                    );

                    comando.Parameters.AddWithValue(
                        "@horario", horarioEscolhido
                    );

                    comando.Parameters.AddWithValue(
                        "@status", cmbStatusAgendamento.Text
                    );

                    comando.Parameters.AddWithValue(
                        "@observacoes",
                        string.IsNullOrWhiteSpace(txtObservacoesAgendamento.Text)
                        ? (object)DBNull.Value
                        : txtObservacoesAgendamento.Text
                    );

                    comando.Parameters.AddWithValue(
                        "@codCli", cmbClienteAgendamento.SelectedValue
                    );

                    comando.Parameters.AddWithValue(
                        "@codpet", cmbPetAgendamento.SelectedValue
                    );

                    comando.Parameters.AddWithValue(
                        "@codFun",
                        cmbFuncionarioAgendamento.SelectedValue == null ||
                        cmbFuncionarioAgendamento.SelectedValue == DBNull.Value
                        ? (object)DBNull.Value
                        : cmbFuncionarioAgendamento.SelectedValue
                    );

                    if (codigoAgendamento != 0)
                    {
                        comando.Parameters.AddWithValue(
                            "@codigo", codigoAgendamento
                        );
                    }

                    comando.ExecuteNonQuery();

                    if (codigoAgendamento == 0)
                    {
                        CaixaMensagem.Show("Agendamento cadastrado com sucesso!");
                        LimparCampos();
                    }
                    else
                    {
                        CaixaMensagem.Show("Agendamento atualizado com sucesso!");
                        Close();
                    }
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show(
                    "Erro ao salvar agendamento: " + ex.Message
                );
            }
        }

        // LIMPAR CAMPOS
        private void LimparCampos()
        {
            cmbClienteAgendamento.SelectedIndex = -1;
            cmbPetAgendamento.DataSource = null;

            cmbFuncionarioAgendamento.SelectedIndex = 0;

            dtpDataAgendamento.Value = DateTime.Today;

            cmbStatusAgendamento.SelectedIndex = 0;

            txtObservacoesAgendamento.Clear();

            CarregarHorarios();
        }

        private void btnLimparAgendamento_Click_1(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void btnVoltarAgendamento_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
