﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmCadastrarCategoria : Form
    {
        // 0 = nova categoria | maior que 0 = editando
        private int codigoCategoria = 0;

        public FrmCadastrarCategoria()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void FrmCadastrarCategoria_Load(object sender, EventArgs e)
        {
            txtNomeCategoria.Focus();
        }

        // Chamado pela tela de consulta para editar
        public void CarregarCategoria(int codigo)
        {
            codigoCategoria = codigo;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT nome, descricao
                                   FROM categoria_produto
                                   WHERE codCategoria = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@codigo", codigo);

                        using (MySqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtNomeCategoria.Text = reader["nome"].ToString();
                                txtDescricaoCategoria.Text = reader["descricao"].ToString();

                                lblTituloCategoria.Text = "Editar Categoria";
                                this.Text = "PotroCão - Editar Categoria";
                            }
                            else
                            {
                                Utilitarios.Aviso("Categoria não encontrada!");
                                codigoCategoria = 0;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar categoria: " + ex.Message);
            }
        }

        private void btnSalvarCategoria_Click(object sender, EventArgs e)
        {
            string nome = txtNomeCategoria.Text.Trim();
            string descricao = txtDescricaoCategoria.Text.Trim();

            if (string.IsNullOrWhiteSpace(nome))
            {
                Utilitarios.Aviso("Informe o nome da categoria!");
                txtNomeCategoria.Focus();
                return;
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    // Impede cadastrar duas categorias com o mesmo nome
                    string sqlDuplicada = @"SELECT COUNT(*)
                                            FROM categoria_produto
                                            WHERE nome = @nome
                                            AND codCategoria <> @codigo";

                    using (MySqlCommand verificar = new MySqlCommand(sqlDuplicada, conexao))
                    {
                        verificar.Parameters.AddWithValue("@nome", nome);
                        verificar.Parameters.AddWithValue("@codigo", codigoCategoria);

                        if (Convert.ToInt32(verificar.ExecuteScalar()) > 0)
                        {
                            Utilitarios.Aviso("Já existe uma categoria com esse nome!");
                            txtNomeCategoria.Focus();
                            return;
                        }
                    }

                    string sql;

                    if (codigoCategoria == 0)
                    {
                        sql = @"INSERT INTO categoria_produto (nome, descricao, ativo)
                                VALUES (@nome, @descricao, 1)";
                    }
                    else
                    {
                        sql = @"UPDATE categoria_produto SET
                                    nome = @nome,
                                    descricao = @descricao
                                WHERE codCategoria = @codigo";
                    }

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@nome", nome);
                        comando.Parameters.AddWithValue("@descricao", descricao);
                        comando.Parameters.AddWithValue("@codigo", codigoCategoria);

                        comando.ExecuteNonQuery();
                    }
                }

                if (codigoCategoria == 0)
                {
                    Utilitarios.Sucesso("Categoria cadastrada com sucesso!");
                    LimparCampos();
                }
                else
                {
                    Utilitarios.Sucesso("Categoria atualizada com sucesso!");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao salvar categoria: " + ex.Message);
            }
        }

        private void LimparCampos()
        {
            txtNomeCategoria.Clear();
            txtDescricaoCategoria.Clear();
            txtNomeCategoria.Focus();
        }

        private void btnLimparCategoria_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void btnVoltarCategoria_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
