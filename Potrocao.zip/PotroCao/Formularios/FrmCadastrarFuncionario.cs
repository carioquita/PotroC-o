﻿
using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmCadastrarFuncionario : Form
    {
        private int codigoFuncionario = 0;

        public FrmCadastrarFuncionario()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void FrmCadastrarFuncionario_Load(object sender, EventArgs e)
        {
            dtpNascimentoFuncionario.MaxDate = DateTime.Today;
            dtpNascimentoFuncionario.Value = DateTime.Today;

            cmbCargoFuncionario.Items.Clear();
            cmbCargoFuncionario.Items.Add("Atendente");
            cmbCargoFuncionario.Items.Add("Veterinário");
            cmbCargoFuncionario.Items.Add("Tosador");
            cmbCargoFuncionario.Items.Add("Banhista");
            cmbCargoFuncionario.Items.Add("Gerente");
            cmbCargoFuncionario.Items.Add("Outro");

            cmbCargoFuncionario.SelectedIndex = -1;
        }

        public void CarregarFuncionario(int codigo)
        {
            codigoFuncionario = codigo;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT * FROM funcionario
                                   WHERE codFun = @codigo";

                    MySqlCommand comando = new MySqlCommand(sql, conexao);
                    comando.Parameters.AddWithValue("@codigo", codigo);

                    using (MySqlDataReader reader = comando.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtNomeFuncionario.Text = reader["nome"].ToString();
                            txtRGFuncionario.Text = reader["rg"].ToString();
                            txtEmailFuncionario.Text = reader["email"].ToString();
                            txtTelefoneFuncionario.Text = reader["telefone"].ToString();
                            txtEnderecoFuncionario.Text = reader["endereco"].ToString();

                            dtpNascimentoFuncionario.Value =
                                Convert.ToDateTime(reader["datanasc"]);

                            cmbCargoFuncionario.Text = reader["cargo"].ToString();
                        }
                        else
                        {
                            CaixaMensagem.Show("Funcionário não encontrado!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao carregar funcionário: " + ex.Message);
            }
        }

        private void btnSalvarFuncionario_Click(object sender, EventArgs e)
        {
            SalvarFuncionario();
        }

        private void btnSalvarFuncionario_Click_1(object sender, EventArgs e)
        {
            SalvarFuncionario();
        }

        private void SalvarFuncionario()
        {
            if (string.IsNullOrWhiteSpace(txtNomeFuncionario.Text) ||
                string.IsNullOrWhiteSpace(txtRGFuncionario.Text) ||
                string.IsNullOrWhiteSpace(txtEmailFuncionario.Text) ||
                string.IsNullOrWhiteSpace(txtTelefoneFuncionario.Text) ||
                string.IsNullOrWhiteSpace(txtEnderecoFuncionario.Text) ||
                cmbCargoFuncionario.SelectedIndex == -1)
            {
                CaixaMensagem.Show("Preencha todos os campos!");
                return;
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql;

                    if (codigoFuncionario == 0)
                    {
                        sql = @"INSERT INTO funcionario
                        (nome, rg, email, telefone, endereco, datanasc, cargo)
                        VALUES
                        (@nome, @rg, @email, @telefone, @endereco, @datanasc, @cargo)";
                    }
                    else
                    {
                        sql = @"UPDATE funcionario SET
                        nome = @nome,
                        rg = @rg,
                        email = @email,
                        telefone = @telefone,
                        endereco = @endereco,
                        datanasc = @datanasc,
                        cargo = @cargo
                        WHERE codFun = @codigo";
                    }

                    MySqlCommand comando = new MySqlCommand(sql, conexao);

                    comando.Parameters.AddWithValue("@nome", txtNomeFuncionario.Text.Trim());
                    comando.Parameters.AddWithValue("@rg", txtRGFuncionario.Text.Trim());
                    comando.Parameters.AddWithValue("@email", txtEmailFuncionario.Text.Trim());
                    comando.Parameters.AddWithValue("@telefone", txtTelefoneFuncionario.Text.Trim());
                    comando.Parameters.AddWithValue("@endereco", txtEnderecoFuncionario.Text.Trim());
                    comando.Parameters.AddWithValue("@datanasc", dtpNascimentoFuncionario.Value.Date);
                    comando.Parameters.AddWithValue("@cargo", cmbCargoFuncionario.Text);

                    if (codigoFuncionario != 0)
                    {
                        comando.Parameters.AddWithValue("@codigo", codigoFuncionario);
                    }

                    comando.ExecuteNonQuery();

                    if (codigoFuncionario == 0)
                    {
                        CaixaMensagem.Show("Funcionário cadastrado com sucesso!");
                    }
                    else
                    {
                        CaixaMensagem.Show("Funcionário atualizado com sucesso!");
                    }

                    codigoFuncionario = 0;
                    LimparCampos();
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao salvar funcionário: " + ex.Message);
            }
        }

        private void LimparCampos()
        {
            txtNomeFuncionario.Clear();
            txtRGFuncionario.Clear();
            txtEmailFuncionario.Clear();
            txtTelefoneFuncionario.Clear();
            txtEnderecoFuncionario.Clear();

            dtpNascimentoFuncionario.Value = DateTime.Today;
            cmbCargoFuncionario.SelectedIndex = -1;

            txtNomeFuncionario.Focus();
        }

        private void btnLimparFuncionario_Click(object sender, EventArgs e)
        {
            codigoFuncionario = 0;
            LimparCampos();
        }

        private void btnVoltarFuncionario_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
