﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmCadastrarServico : Form
    {
        // 0 = novo serviço | maior que 0 = editando
        private int codigoServico = 0;

        public FrmCadastrarServico()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void FrmCadastrarServico_Load(object sender, EventArgs e)
        {
            if (codigoServico != 0)
                CarregarDadosServico();

            txtNomeServico.Focus();
        }

        // Chamado pela tela de consulta para editar (os dados são lidos no Load)
        public void CarregarServico(int codigo)
        {
            codigoServico = codigo;
        }

        private void CarregarDadosServico()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT nome, descricao, preco, duracao
                                   FROM servico WHERE codServico = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@codigo", codigoServico);

                        using (MySqlDataReader reader = comando.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                Utilitarios.Aviso("Serviço não encontrado!");
                                codigoServico = 0;
                                return;
                            }

                            txtNomeServico.Text = reader["nome"].ToString();
                            txtDescricaoServico.Text = reader["descricao"].ToString();
                            nudPrecoServico.Value = Math.Min(nudPrecoServico.Maximum,
                                Convert.ToDecimal(reader["preco"]));
                            nudDuracaoServico.Value = Math.Min(nudDuracaoServico.Maximum,
                                Convert.ToDecimal(reader["duracao"]));
                        }
                    }
                }

                lblTituloServico.Text = "Editar Serviço";
                this.Text = "PotroCão - Editar Serviço";
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar serviço: " + ex.Message);
            }
        }

        private void btnSalvarServico_Click(object sender, EventArgs e)
        {
            string nome = txtNomeServico.Text.Trim();

            if (string.IsNullOrWhiteSpace(nome))
            {
                Utilitarios.Aviso("Informe o nome do serviço!");
                txtNomeServico.Focus();
                return;
            }

            if (nudPrecoServico.Value <= 0)
            {
                Utilitarios.Aviso("Informe um preço maior que zero!");
                nudPrecoServico.Focus();
                return;
            }

            if (nudDuracaoServico.Value <= 0)
            {
                Utilitarios.Aviso("Informe a duração do serviço em minutos!");
                nudDuracaoServico.Focus();
                return;
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sqlDuplicado = @"SELECT COUNT(*) FROM servico
                                            WHERE nome = @nome AND codServico <> @codigo";

                    using (MySqlCommand verificar = new MySqlCommand(sqlDuplicado, conexao))
                    {
                        verificar.Parameters.AddWithValue("@nome", nome);
                        verificar.Parameters.AddWithValue("@codigo", codigoServico);

                        if (Convert.ToInt32(verificar.ExecuteScalar()) > 0)
                        {
                            Utilitarios.Aviso("Já existe um serviço com esse nome!");
                            txtNomeServico.Focus();
                            return;
                        }
                    }

                    string sql = codigoServico == 0
                        ? @"INSERT INTO servico (nome, descricao, preco, duracao, ativo)
                            VALUES (@nome, @descricao, @preco, @duracao, 1)"
                        : @"UPDATE servico SET
                                nome = @nome,
                                descricao = @descricao,
                                preco = @preco,
                                duracao = @duracao
                            WHERE codServico = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@nome", nome);
                        // a coluna descricao não aceita nulo: grava texto vazio quando não informada
                        comando.Parameters.AddWithValue("@descricao", txtDescricaoServico.Text.Trim());
                        comando.Parameters.AddWithValue("@preco", nudPrecoServico.Value);
                        comando.Parameters.AddWithValue("@duracao", (int)nudDuracaoServico.Value);
                        comando.Parameters.AddWithValue("@codigo", codigoServico);
                        comando.ExecuteNonQuery();
                    }
                }

                if (codigoServico == 0)
                {
                    Utilitarios.Sucesso("Serviço cadastrado com sucesso!");
                    LimparCampos();
                }
                else
                {
                    Utilitarios.Sucesso("Serviço atualizado com sucesso!");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao salvar serviço: " + ex.Message);
            }
        }

        private void LimparCampos()
        {
            txtNomeServico.Clear();
            txtDescricaoServico.Clear();
            nudPrecoServico.Value = 0;
            nudDuracaoServico.Value = 0;
            txtNomeServico.Focus();
        }

        private void btnLimparServico_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void btnVoltarServico_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
