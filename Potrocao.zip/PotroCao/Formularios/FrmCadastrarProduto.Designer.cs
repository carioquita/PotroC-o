﻿namespace PotroCao.Formularios
{
    partial class FrmCadastrarProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTituloProduto = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlDados = new System.Windows.Forms.Panel();
            this.lblSecaoProduto = new System.Windows.Forms.Label();
            this.lblNomeProduto = new System.Windows.Forms.Label();
            this.txtNomeProduto = new System.Windows.Forms.TextBox();
            this.lblCategoriaProduto = new System.Windows.Forms.Label();
            this.cmbCategoriaProduto = new System.Windows.Forms.ComboBox();
            this.lblPrecoProduto = new System.Windows.Forms.Label();
            this.nudPrecoProduto = new System.Windows.Forms.NumericUpDown();
            this.lblEstoqueProduto = new System.Windows.Forms.Label();
            this.nudEstoqueProduto = new System.Windows.Forms.NumericUpDown();
            this.lblAvisoEstoque = new System.Windows.Forms.Label();
            this.lblDescricaoProduto = new System.Windows.Forms.Label();
            this.txtDescricaoProduto = new System.Windows.Forms.TextBox();
            this.btnSalvarProduto = new System.Windows.Forms.Button();
            this.btnLimparProduto = new System.Windows.Forms.Button();
            this.btnVoltarProduto = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlDados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrecoProduto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEstoqueProduto)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTituloProduto);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTituloProduto
            // 
            this.lblTituloProduto.AutoSize = true;
            this.lblTituloProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTituloProduto.Location = new System.Drawing.Point(22, 14);
            this.lblTituloProduto.Name = "lblTituloProduto";
            this.lblTituloProduto.TabIndex = 0;
            this.lblTituloProduto.Text = "Cadastrar Produto";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Produtos vendidos no pet shop. Campos com * são obrigatórios.";
            // 
            // pnlDados
            // 
            this.pnlDados.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlDados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlDados.Controls.Add(this.btnVoltarProduto);
            this.pnlDados.Controls.Add(this.btnLimparProduto);
            this.pnlDados.Controls.Add(this.btnSalvarProduto);
            this.pnlDados.Controls.Add(this.txtDescricaoProduto);
            this.pnlDados.Controls.Add(this.lblDescricaoProduto);
            this.pnlDados.Controls.Add(this.lblAvisoEstoque);
            this.pnlDados.Controls.Add(this.nudEstoqueProduto);
            this.pnlDados.Controls.Add(this.lblEstoqueProduto);
            this.pnlDados.Controls.Add(this.nudPrecoProduto);
            this.pnlDados.Controls.Add(this.lblPrecoProduto);
            this.pnlDados.Controls.Add(this.cmbCategoriaProduto);
            this.pnlDados.Controls.Add(this.lblCategoriaProduto);
            this.pnlDados.Controls.Add(this.txtNomeProduto);
            this.pnlDados.Controls.Add(this.lblNomeProduto);
            this.pnlDados.Controls.Add(this.lblSecaoProduto);
            this.pnlDados.Location = new System.Drawing.Point(20, 100);
            this.pnlDados.Name = "pnlDados";
            this.pnlDados.Size = new System.Drawing.Size(600, 392);
            this.pnlDados.TabIndex = 1;
            this.pnlDados.Tag = "cartao";
            // 
            // lblSecaoProduto
            // 
            this.lblSecaoProduto.AutoSize = true;
            this.lblSecaoProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoProduto.Location = new System.Drawing.Point(24, 16);
            this.lblSecaoProduto.Name = "lblSecaoProduto";
            this.lblSecaoProduto.TabIndex = 0;
            this.lblSecaoProduto.Text = "Dados do produto";
            // 
            // lblNomeProduto
            // 
            this.lblNomeProduto.AutoSize = true;
            this.lblNomeProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblNomeProduto.Location = new System.Drawing.Point(24, 50);
            this.lblNomeProduto.Name = "lblNomeProduto";
            this.lblNomeProduto.TabIndex = 1;
            this.lblNomeProduto.Text = "Nome *";
            // 
            // txtNomeProduto
            // 
            this.txtNomeProduto.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeProduto.Location = new System.Drawing.Point(24, 72);
            this.txtNomeProduto.MaxLength = 100;
            this.txtNomeProduto.Name = "txtNomeProduto";
            this.txtNomeProduto.Size = new System.Drawing.Size(552, 25);
            this.txtNomeProduto.TabIndex = 2;
            // 
            // lblCategoriaProduto
            // 
            this.lblCategoriaProduto.AutoSize = true;
            this.lblCategoriaProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoriaProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblCategoriaProduto.Location = new System.Drawing.Point(24, 110);
            this.lblCategoriaProduto.Name = "lblCategoriaProduto";
            this.lblCategoriaProduto.TabIndex = 3;
            this.lblCategoriaProduto.Text = "Categoria *";
            // 
            // cmbCategoriaProduto
            // 
            this.cmbCategoriaProduto.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCategoriaProduto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategoriaProduto.FormattingEnabled = true;
            this.cmbCategoriaProduto.Location = new System.Drawing.Point(24, 132);
            this.cmbCategoriaProduto.Name = "cmbCategoriaProduto";
            this.cmbCategoriaProduto.Size = new System.Drawing.Size(264, 27);
            this.cmbCategoriaProduto.TabIndex = 4;
            // 
            // lblPrecoProduto
            // 
            this.lblPrecoProduto.AutoSize = true;
            this.lblPrecoProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPrecoProduto.Location = new System.Drawing.Point(312, 110);
            this.lblPrecoProduto.Name = "lblPrecoProduto";
            this.lblPrecoProduto.TabIndex = 5;
            this.lblPrecoProduto.Text = "Preço (R$) *";
            // 
            // nudPrecoProduto
            // 
            this.nudPrecoProduto.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudPrecoProduto.DecimalPlaces = 2;
            this.nudPrecoProduto.ThousandsSeparator = true;
            this.nudPrecoProduto.Maximum = new decimal(new int[] { 99999, 0, 0, 0});
            this.nudPrecoProduto.Location = new System.Drawing.Point(312, 132);
            this.nudPrecoProduto.Name = "nudPrecoProduto";
            this.nudPrecoProduto.Size = new System.Drawing.Size(120, 26);
            this.nudPrecoProduto.TabIndex = 6;
            // 
            // lblEstoqueProduto
            // 
            this.lblEstoqueProduto.AutoSize = true;
            this.lblEstoqueProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstoqueProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblEstoqueProduto.Location = new System.Drawing.Point(452, 110);
            this.lblEstoqueProduto.Name = "lblEstoqueProduto";
            this.lblEstoqueProduto.TabIndex = 7;
            this.lblEstoqueProduto.Text = "Estoque inicial";
            // 
            // nudEstoqueProduto
            // 
            this.nudEstoqueProduto.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudEstoqueProduto.Maximum = new decimal(new int[] { 100000, 0, 0, 0});
            this.nudEstoqueProduto.Location = new System.Drawing.Point(452, 132);
            this.nudEstoqueProduto.Name = "nudEstoqueProduto";
            this.nudEstoqueProduto.Size = new System.Drawing.Size(124, 26);
            this.nudEstoqueProduto.TabIndex = 8;
            // 
            // lblAvisoEstoque
            // 
            this.lblAvisoEstoque.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvisoEstoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(22)))), ((int)(((byte)(114)))));
            this.lblAvisoEstoque.Visible = false;
            this.lblAvisoEstoque.Location = new System.Drawing.Point(24, 166);
            this.lblAvisoEstoque.Name = "lblAvisoEstoque";
            this.lblAvisoEstoque.Size = new System.Drawing.Size(552, 20);
            this.lblAvisoEstoque.TabIndex = 9;
            this.lblAvisoEstoque.Text = "Para alterar o estoque de um produto já cadastrado, use o Controle de Estoque.";
            // 
            // lblDescricaoProduto
            // 
            this.lblDescricaoProduto.AutoSize = true;
            this.lblDescricaoProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescricaoProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblDescricaoProduto.Location = new System.Drawing.Point(24, 192);
            this.lblDescricaoProduto.Name = "lblDescricaoProduto";
            this.lblDescricaoProduto.TabIndex = 10;
            this.lblDescricaoProduto.Text = "Descrição";
            // 
            // txtDescricaoProduto
            // 
            this.txtDescricaoProduto.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescricaoProduto.Multiline = true;
            this.txtDescricaoProduto.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescricaoProduto.Location = new System.Drawing.Point(24, 214);
            this.txtDescricaoProduto.Name = "txtDescricaoProduto";
            this.txtDescricaoProduto.Size = new System.Drawing.Size(552, 90);
            this.txtDescricaoProduto.TabIndex = 11;
            // 
            // btnSalvarProduto
            // 
            this.btnSalvarProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnSalvarProduto.Location = new System.Drawing.Point(240, 334);
            this.btnSalvarProduto.Name = "btnSalvarProduto";
            this.btnSalvarProduto.Size = new System.Drawing.Size(108, 36);
            this.btnSalvarProduto.TabIndex = 12;
            this.btnSalvarProduto.Tag = "primario";
            this.btnSalvarProduto.Text = "Salvar";
            this.btnSalvarProduto.UseVisualStyleBackColor = false;
            this.btnSalvarProduto.Click += new System.EventHandler(this.btnSalvarProduto_Click);
            // 
            // btnLimparProduto
            // 
            this.btnLimparProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnLimparProduto.Location = new System.Drawing.Point(358, 334);
            this.btnLimparProduto.Name = "btnLimparProduto";
            this.btnLimparProduto.Size = new System.Drawing.Size(108, 36);
            this.btnLimparProduto.TabIndex = 13;
            this.btnLimparProduto.Tag = "secundario";
            this.btnLimparProduto.Text = "Limpar";
            this.btnLimparProduto.UseVisualStyleBackColor = false;
            this.btnLimparProduto.Click += new System.EventHandler(this.btnLimparProduto_Click);
            // 
            // btnVoltarProduto
            // 
            this.btnVoltarProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarProduto.Location = new System.Drawing.Point(476, 334);
            this.btnVoltarProduto.Name = "btnVoltarProduto";
            this.btnVoltarProduto.Size = new System.Drawing.Size(100, 36);
            this.btnVoltarProduto.TabIndex = 14;
            this.btnVoltarProduto.Tag = "neutro";
            this.btnVoltarProduto.Text = "Voltar";
            this.btnVoltarProduto.UseVisualStyleBackColor = false;
            this.btnVoltarProduto.Click += new System.EventHandler(this.btnVoltarProduto_Click);
            // 
            // FrmCadastrarProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(640, 512);
            this.Controls.Add(this.pnlDados);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmCadastrarProduto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Cadastrar Produto";
            this.Load += new System.EventHandler(this.FrmCadastrarProduto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudPrecoProduto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEstoqueProduto)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlDados.ResumeLayout(false);
            this.pnlDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTituloProduto;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlDados;
        private System.Windows.Forms.Label lblSecaoProduto;
        private System.Windows.Forms.Label lblNomeProduto;
        private System.Windows.Forms.TextBox txtNomeProduto;
        private System.Windows.Forms.Label lblCategoriaProduto;
        private System.Windows.Forms.ComboBox cmbCategoriaProduto;
        private System.Windows.Forms.Label lblPrecoProduto;
        private System.Windows.Forms.NumericUpDown nudPrecoProduto;
        private System.Windows.Forms.Label lblEstoqueProduto;
        private System.Windows.Forms.NumericUpDown nudEstoqueProduto;
        private System.Windows.Forms.Label lblAvisoEstoque;
        private System.Windows.Forms.Label lblDescricaoProduto;
        private System.Windows.Forms.TextBox txtDescricaoProduto;
        private System.Windows.Forms.Button btnSalvarProduto;
        private System.Windows.Forms.Button btnLimparProduto;
        private System.Windows.Forms.Button btnVoltarProduto;
    }
}
