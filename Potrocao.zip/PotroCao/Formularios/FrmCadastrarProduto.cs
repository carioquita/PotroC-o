﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmCadastrarProduto : Form
    {
        // 0 = novo produto | maior que 0 = editando
        private int codigoProduto = 0;

        // Categoria do produto em edição (pode estar inativa)
        private int categoriaDoProduto = 0;

        public FrmCadastrarProduto()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void FrmCadastrarProduto_Load(object sender, EventArgs e)
        {
            if (codigoProduto == 0)
                CarregarCategorias();
            else
                CarregarDadosProduto();

            txtNomeProduto.Focus();
        }

        // Carrega somente categorias ativas.
        // Na edição, inclui também a categoria atual do produto, mesmo que esteja inativa.
        private void CarregarCategorias()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT codCategoria,
                                          CASE WHEN ativo = 1 THEN nome
                                               ELSE CONCAT(nome, ' (inativa)') END AS nome
                                   FROM categoria_produto
                                   WHERE ativo = 1 OR codCategoria = @atual
                                   ORDER BY nome";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@atual", categoriaDoProduto);

                        using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                        {
                            DataTable tabela = new DataTable();
                            adaptador.Fill(tabela);

                            cmbCategoriaProduto.DataSource = tabela;
                            cmbCategoriaProduto.DisplayMember = "nome";
                            cmbCategoriaProduto.ValueMember = "codCategoria";
                            cmbCategoriaProduto.SelectedIndex = -1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar categorias: " + ex.Message);
            }
        }

        // Chamado pela tela de consulta para editar.
        // Os dados são carregados quando a tela abre (evento Load).
        public void CarregarProduto(int codigo)
        {
            codigoProduto = codigo;
        }

        private void CarregarDadosProduto()
        {
            int codigo = codigoProduto;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT nome, descricao, preco, quantidadeEstoque, codCategoria
                                   FROM produto
                                   WHERE codProduto = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@codigo", codigo);

                        using (MySqlDataReader reader = comando.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                Utilitarios.Aviso("Produto não encontrado!");
                                codigoProduto = 0;
                                return;
                            }

                            txtNomeProduto.Text = reader["nome"].ToString();
                            txtDescricaoProduto.Text = reader["descricao"].ToString();
                            nudPrecoProduto.Value = Convert.ToDecimal(reader["preco"]);
                            nudEstoqueProduto.Value = Convert.ToDecimal(reader["quantidadeEstoque"]);
                            categoriaDoProduto = Convert.ToInt32(reader["codCategoria"]);
                        }
                    }
                }

                CarregarCategorias();
                cmbCategoriaProduto.SelectedValue = categoriaDoProduto;

                // Na edição o estoque só muda pela tela de Estoque (para manter o histórico)
                lblEstoqueProduto.Text = "Estoque atual:";
                nudEstoqueProduto.Enabled = false;
                lblAvisoEstoque.Visible = true;

                lblTituloProduto.Text = "Editar Produto";
                this.Text = "PotroCão - Editar Produto";
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar produto: " + ex.Message);
            }
        }

        private void btnSalvarProduto_Click(object sender, EventArgs e)
        {
            string nome = txtNomeProduto.Text.Trim();

            if (string.IsNullOrWhiteSpace(nome))
            {
                Utilitarios.Aviso("Informe o nome do produto!");
                txtNomeProduto.Focus();
                return;
            }

            if (cmbCategoriaProduto.SelectedIndex == -1 || cmbCategoriaProduto.SelectedValue == null)
            {
                Utilitarios.Aviso("Selecione a categoria do produto!");
                cmbCategoriaProduto.Focus();
                return;
            }

            if (nudPrecoProduto.Value <= 0)
            {
                Utilitarios.Aviso("Informe um preço maior que zero!");
                nudPrecoProduto.Focus();
                return;
            }

            int codCategoria = Convert.ToInt32(cmbCategoriaProduto.SelectedValue);
            string descricao = txtDescricaoProduto.Text.Trim();

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    // Impede dois produtos com o mesmo nome
                    string sqlDuplicado = @"SELECT COUNT(*) FROM produto
                                            WHERE nome = @nome AND codProduto <> @codigo";

                    using (MySqlCommand verificar = new MySqlCommand(sqlDuplicado, conexao))
                    {
                        verificar.Parameters.AddWithValue("@nome", nome);
                        verificar.Parameters.AddWithValue("@codigo", codigoProduto);

                        if (Convert.ToInt32(verificar.ExecuteScalar()) > 0)
                        {
                            Utilitarios.Aviso("Já existe um produto com esse nome!");
                            txtNomeProduto.Focus();
                            return;
                        }
                    }

                    string sql;

                    if (codigoProduto == 0)
                    {
                        sql = @"INSERT INTO produto
                                    (nome, descricao, preco, quantidadeEstoque, codCategoria, ativo)
                                VALUES
                                    (@nome, @descricao, @preco, @estoque, @categoria, 1)";
                    }
                    else
                    {
                        // Estoque NÃO é alterado aqui
                        sql = @"UPDATE produto SET
                                    nome = @nome,
                                    descricao = @descricao,
                                    preco = @preco,
                                    codCategoria = @categoria
                                WHERE codProduto = @codigo";
                    }

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@nome", nome);
                        comando.Parameters.AddWithValue("@descricao",
                            string.IsNullOrWhiteSpace(descricao) ? (object)DBNull.Value : descricao);
                        comando.Parameters.AddWithValue("@preco", nudPrecoProduto.Value);
                        comando.Parameters.AddWithValue("@estoque", (int)nudEstoqueProduto.Value);
                        comando.Parameters.AddWithValue("@categoria", codCategoria);
                        comando.Parameters.AddWithValue("@codigo", codigoProduto);

                        comando.ExecuteNonQuery();

                        // Produto novo com estoque inicial: registra a entrada no histórico
                        int estoqueInicial = (int)nudEstoqueProduto.Value;

                        if (codigoProduto == 0 && estoqueInicial > 0)
                            RegistrarEstoqueInicial(conexao, comando.LastInsertedId, estoqueInicial);
                    }
                }

                if (codigoProduto == 0)
                {
                    Utilitarios.Sucesso("Produto cadastrado com sucesso!");
                    LimparCampos();
                }
                else
                {
                    Utilitarios.Sucesso("Produto atualizado com sucesso!");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao salvar produto: " + ex.Message);
            }
        }

        private void RegistrarEstoqueInicial(MySqlConnection conexao, long codigoNovo, int quantidade)
        {
            try
            {
                string sql = @"INSERT INTO movimentacao_estoque
                                   (codProduto, tipo, quantidade, estoqueAnterior, estoqueAtual, motivo)
                               VALUES (@c, 'Entrada', @q, 0, @q, 'Estoque inicial (cadastro do produto)')";

                using (MySqlCommand registrar = new MySqlCommand(sql, conexao))
                {
                    registrar.Parameters.AddWithValue("@c", codigoNovo);
                    registrar.Parameters.AddWithValue("@q", quantidade);
                    registrar.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                // 1146 = a tabela de histórico ainda não foi criada; o produto continua salvo normalmente
                if (ex.Number != 1146)
                    throw;
            }
        }

        private void LimparCampos()
        {
            txtNomeProduto.Clear();
            txtDescricaoProduto.Clear();
            nudPrecoProduto.Value = 0;

            if (codigoProduto == 0)
                nudEstoqueProduto.Value = 0;

            cmbCategoriaProduto.SelectedIndex = -1;
            txtNomeProduto.Focus();
        }

        private void btnLimparProduto_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void btnVoltarProduto_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
