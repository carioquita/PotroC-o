﻿namespace PotroCao.Formularios
{
    partial class FrmCadastrarFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlDados = new System.Windows.Forms.Panel();
            this.lblSecaoPessoais = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.lblRG = new System.Windows.Forms.Label();
            this.txtRGFuncionario = new System.Windows.Forms.TextBox();
            this.lblDataNascimento = new System.Windows.Forms.Label();
            this.dtpNascimentoFuncionario = new System.Windows.Forms.DateTimePicker();
            this.lblCargoFuncionario = new System.Windows.Forms.Label();
            this.cmbCargoFuncionario = new System.Windows.Forms.ComboBox();
            this.lblSecaoContato = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmailFuncionario = new System.Windows.Forms.TextBox();
            this.lblTelefone = new System.Windows.Forms.Label();
            this.txtTelefoneFuncionario = new System.Windows.Forms.TextBox();
            this.lblEndeco = new System.Windows.Forms.Label();
            this.txtEnderecoFuncionario = new System.Windows.Forms.TextBox();
            this.btnSalvarFuncionario = new System.Windows.Forms.Button();
            this.btnLimparFuncionario = new System.Windows.Forms.Button();
            this.btnVoltarFuncionario = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTitulo.Location = new System.Drawing.Point(22, 14);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Cadastro de Funcionários";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Dados da equipe do PotroCão. Todos os campos são obrigatórios.";
            // 
            // pnlDados
            // 
            this.pnlDados.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlDados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlDados.Controls.Add(this.btnVoltarFuncionario);
            this.pnlDados.Controls.Add(this.btnLimparFuncionario);
            this.pnlDados.Controls.Add(this.btnSalvarFuncionario);
            this.pnlDados.Controls.Add(this.txtEnderecoFuncionario);
            this.pnlDados.Controls.Add(this.lblEndeco);
            this.pnlDados.Controls.Add(this.txtTelefoneFuncionario);
            this.pnlDados.Controls.Add(this.lblTelefone);
            this.pnlDados.Controls.Add(this.txtEmailFuncionario);
            this.pnlDados.Controls.Add(this.lblEmail);
            this.pnlDados.Controls.Add(this.lblSecaoContato);
            this.pnlDados.Controls.Add(this.cmbCargoFuncionario);
            this.pnlDados.Controls.Add(this.lblCargoFuncionario);
            this.pnlDados.Controls.Add(this.dtpNascimentoFuncionario);
            this.pnlDados.Controls.Add(this.lblDataNascimento);
            this.pnlDados.Controls.Add(this.txtRGFuncionario);
            this.pnlDados.Controls.Add(this.lblRG);
            this.pnlDados.Controls.Add(this.txtNomeFuncionario);
            this.pnlDados.Controls.Add(this.lblNome);
            this.pnlDados.Controls.Add(this.lblSecaoPessoais);
            this.pnlDados.Location = new System.Drawing.Point(20, 100);
            this.pnlDados.Name = "pnlDados";
            this.pnlDados.Size = new System.Drawing.Size(720, 356);
            this.pnlDados.TabIndex = 1;
            this.pnlDados.Tag = "cartao";
            // 
            // lblSecaoPessoais
            // 
            this.lblSecaoPessoais.AutoSize = true;
            this.lblSecaoPessoais.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoPessoais.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoPessoais.Location = new System.Drawing.Point(24, 16);
            this.lblSecaoPessoais.Name = "lblSecaoPessoais";
            this.lblSecaoPessoais.TabIndex = 0;
            this.lblSecaoPessoais.Text = "Dados pessoais";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblNome.Location = new System.Drawing.Point(24, 50);
            this.lblNome.Name = "lblNome";
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome completo";
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeFuncionario.Location = new System.Drawing.Point(24, 72);
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(320, 25);
            this.txtNomeFuncionario.TabIndex = 2;
            // 
            // lblRG
            // 
            this.lblRG.AutoSize = true;
            this.lblRG.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblRG.Location = new System.Drawing.Point(24, 110);
            this.lblRG.Name = "lblRG";
            this.lblRG.TabIndex = 3;
            this.lblRG.Text = "RG";
            // 
            // txtRGFuncionario
            // 
            this.txtRGFuncionario.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRGFuncionario.Location = new System.Drawing.Point(24, 132);
            this.txtRGFuncionario.Name = "txtRGFuncionario";
            this.txtRGFuncionario.Size = new System.Drawing.Size(320, 25);
            this.txtRGFuncionario.TabIndex = 4;
            // 
            // lblDataNascimento
            // 
            this.lblDataNascimento.AutoSize = true;
            this.lblDataNascimento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataNascimento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblDataNascimento.Location = new System.Drawing.Point(24, 170);
            this.lblDataNascimento.Name = "lblDataNascimento";
            this.lblDataNascimento.TabIndex = 5;
            this.lblDataNascimento.Text = "Data de nascimento";
            // 
            // dtpNascimentoFuncionario
            // 
            this.dtpNascimentoFuncionario.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNascimentoFuncionario.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNascimentoFuncionario.Location = new System.Drawing.Point(24, 192);
            this.dtpNascimentoFuncionario.Name = "dtpNascimentoFuncionario";
            this.dtpNascimentoFuncionario.Size = new System.Drawing.Size(200, 26);
            this.dtpNascimentoFuncionario.TabIndex = 6;
            // 
            // lblCargoFuncionario
            // 
            this.lblCargoFuncionario.AutoSize = true;
            this.lblCargoFuncionario.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargoFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblCargoFuncionario.Location = new System.Drawing.Point(24, 230);
            this.lblCargoFuncionario.Name = "lblCargoFuncionario";
            this.lblCargoFuncionario.TabIndex = 7;
            this.lblCargoFuncionario.Text = "Cargo";
            // 
            // cmbCargoFuncionario
            // 
            this.cmbCargoFuncionario.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCargoFuncionario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCargoFuncionario.FormattingEnabled = true;
            this.cmbCargoFuncionario.Location = new System.Drawing.Point(24, 252);
            this.cmbCargoFuncionario.Name = "cmbCargoFuncionario";
            this.cmbCargoFuncionario.Size = new System.Drawing.Size(200, 27);
            this.cmbCargoFuncionario.TabIndex = 8;
            // 
            // lblSecaoContato
            // 
            this.lblSecaoContato.AutoSize = true;
            this.lblSecaoContato.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoContato.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoContato.Location = new System.Drawing.Point(376, 16);
            this.lblSecaoContato.Name = "lblSecaoContato";
            this.lblSecaoContato.TabIndex = 9;
            this.lblSecaoContato.Text = "Contato";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblEmail.Location = new System.Drawing.Point(376, 50);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.TabIndex = 10;
            this.lblEmail.Text = "E-mail";
            // 
            // txtEmailFuncionario
            // 
            this.txtEmailFuncionario.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailFuncionario.Location = new System.Drawing.Point(376, 72);
            this.txtEmailFuncionario.Name = "txtEmailFuncionario";
            this.txtEmailFuncionario.Size = new System.Drawing.Size(320, 25);
            this.txtEmailFuncionario.TabIndex = 11;
            // 
            // lblTelefone
            // 
            this.lblTelefone.AutoSize = true;
            this.lblTelefone.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblTelefone.Location = new System.Drawing.Point(376, 110);
            this.lblTelefone.Name = "lblTelefone";
            this.lblTelefone.TabIndex = 12;
            this.lblTelefone.Text = "Telefone";
            // 
            // txtTelefoneFuncionario
            // 
            this.txtTelefoneFuncionario.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefoneFuncionario.Location = new System.Drawing.Point(376, 132);
            this.txtTelefoneFuncionario.Name = "txtTelefoneFuncionario";
            this.txtTelefoneFuncionario.Size = new System.Drawing.Size(320, 25);
            this.txtTelefoneFuncionario.TabIndex = 13;
            // 
            // lblEndeco
            // 
            this.lblEndeco.AutoSize = true;
            this.lblEndeco.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndeco.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblEndeco.Location = new System.Drawing.Point(376, 170);
            this.lblEndeco.Name = "lblEndeco";
            this.lblEndeco.TabIndex = 14;
            this.lblEndeco.Text = "Endereço";
            // 
            // txtEnderecoFuncionario
            // 
            this.txtEnderecoFuncionario.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnderecoFuncionario.Location = new System.Drawing.Point(376, 192);
            this.txtEnderecoFuncionario.Name = "txtEnderecoFuncionario";
            this.txtEnderecoFuncionario.Size = new System.Drawing.Size(320, 25);
            this.txtEnderecoFuncionario.TabIndex = 15;
            // 
            // btnSalvarFuncionario
            // 
            this.btnSalvarFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnSalvarFuncionario.Location = new System.Drawing.Point(360, 298);
            this.btnSalvarFuncionario.Name = "btnSalvarFuncionario";
            this.btnSalvarFuncionario.Size = new System.Drawing.Size(108, 36);
            this.btnSalvarFuncionario.TabIndex = 16;
            this.btnSalvarFuncionario.Tag = "primario";
            this.btnSalvarFuncionario.Text = "Salvar";
            this.btnSalvarFuncionario.UseVisualStyleBackColor = false;
            this.btnSalvarFuncionario.Click += new System.EventHandler(this.btnSalvarFuncionario_Click_1);
            // 
            // btnLimparFuncionario
            // 
            this.btnLimparFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnLimparFuncionario.Location = new System.Drawing.Point(478, 298);
            this.btnLimparFuncionario.Name = "btnLimparFuncionario";
            this.btnLimparFuncionario.Size = new System.Drawing.Size(108, 36);
            this.btnLimparFuncionario.TabIndex = 17;
            this.btnLimparFuncionario.Tag = "secundario";
            this.btnLimparFuncionario.Text = "Limpar";
            this.btnLimparFuncionario.UseVisualStyleBackColor = false;
            this.btnLimparFuncionario.Click += new System.EventHandler(this.btnLimparFuncionario_Click);
            // 
            // btnVoltarFuncionario
            // 
            this.btnVoltarFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarFuncionario.Location = new System.Drawing.Point(596, 298);
            this.btnVoltarFuncionario.Name = "btnVoltarFuncionario";
            this.btnVoltarFuncionario.Size = new System.Drawing.Size(100, 36);
            this.btnVoltarFuncionario.TabIndex = 18;
            this.btnVoltarFuncionario.Tag = "neutro";
            this.btnVoltarFuncionario.Text = "Voltar";
            this.btnVoltarFuncionario.UseVisualStyleBackColor = false;
            this.btnVoltarFuncionario.Click += new System.EventHandler(this.btnVoltarFuncionario_Click);
            // 
            // FrmCadastrarFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(760, 476);
            this.Controls.Add(this.pnlDados);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmCadastrarFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Cadastro de Funcionários";
            this.Load += new System.EventHandler(this.FrmCadastrarFuncionario_Load);
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlDados.ResumeLayout(false);
            this.pnlDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlDados;
        private System.Windows.Forms.Label lblSecaoPessoais;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.Label lblRG;
        private System.Windows.Forms.TextBox txtRGFuncionario;
        private System.Windows.Forms.Label lblDataNascimento;
        private System.Windows.Forms.DateTimePicker dtpNascimentoFuncionario;
        private System.Windows.Forms.Label lblCargoFuncionario;
        private System.Windows.Forms.ComboBox cmbCargoFuncionario;
        private System.Windows.Forms.Label lblSecaoContato;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmailFuncionario;
        private System.Windows.Forms.Label lblTelefone;
        private System.Windows.Forms.TextBox txtTelefoneFuncionario;
        private System.Windows.Forms.Label lblEndeco;
        private System.Windows.Forms.TextBox txtEnderecoFuncionario;
        private System.Windows.Forms.Button btnSalvarFuncionario;
        private System.Windows.Forms.Button btnLimparFuncionario;
        private System.Windows.Forms.Button btnVoltarFuncionario;
    }
}
