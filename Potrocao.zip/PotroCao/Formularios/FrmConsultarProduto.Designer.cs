﻿namespace PotroCao.Formularios
{
    partial class FrmConsultarProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTituloConsultaProduto = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlFiltros = new System.Windows.Forms.Panel();
            this.lblPesquisarProduto = new System.Windows.Forms.Label();
            this.txtPesquisarProduto = new System.Windows.Forms.TextBox();
            this.btnPesquisarProduto = new System.Windows.Forms.Button();
            this.btnAtualizarProduto = new System.Windows.Forms.Button();
            this.btnEstoqueProduto = new System.Windows.Forms.Button();
            this.btnCategorias = new System.Windows.Forms.Button();
            this.btnEditarProduto = new System.Windows.Forms.Button();
            this.btnNovoProduto = new System.Windows.Forms.Button();
            this.lblExibindoProduto = new System.Windows.Forms.Label();
            this.lblLegendaEstoque = new System.Windows.Forms.Label();
            this.pnlGrade = new System.Windows.Forms.Panel();
            this.dgvProdutos = new System.Windows.Forms.DataGridView();
            this.btnVerAtivosProduto = new System.Windows.Forms.Button();
            this.btnVerInativosProduto = new System.Windows.Forms.Button();
            this.btnVerTodosProdutos = new System.Windows.Forms.Button();
            this.btnVoltarProduto = new System.Windows.Forms.Button();
            this.btnExportarProdutos = new System.Windows.Forms.Button();
            this.btnReativarProduto = new System.Windows.Forms.Button();
            this.btnInativarProduto = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlFiltros.SuspendLayout();
            this.pnlGrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProdutos)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTituloConsultaProduto);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTituloConsultaProduto
            // 
            this.lblTituloConsultaProduto.AutoSize = true;
            this.lblTituloConsultaProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloConsultaProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTituloConsultaProduto.Location = new System.Drawing.Point(22, 14);
            this.lblTituloConsultaProduto.Name = "lblTituloConsultaProduto";
            this.lblTituloConsultaProduto.TabIndex = 0;
            this.lblTituloConsultaProduto.Text = "Produtos";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Itens à venda, preços e quantidade em estoque.";
            // 
            // pnlFiltros
            // 
            this.pnlFiltros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.pnlFiltros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlFiltros.Controls.Add(this.btnNovoProduto);
            this.pnlFiltros.Controls.Add(this.btnEditarProduto);
            this.pnlFiltros.Controls.Add(this.btnCategorias);
            this.pnlFiltros.Controls.Add(this.btnEstoqueProduto);
            this.pnlFiltros.Controls.Add(this.btnAtualizarProduto);
            this.pnlFiltros.Controls.Add(this.btnPesquisarProduto);
            this.pnlFiltros.Controls.Add(this.txtPesquisarProduto);
            this.pnlFiltros.Controls.Add(this.lblPesquisarProduto);
            this.pnlFiltros.Location = new System.Drawing.Point(20, 100);
            this.pnlFiltros.Name = "pnlFiltros";
            this.pnlFiltros.Size = new System.Drawing.Size(1080, 72);
            this.pnlFiltros.TabIndex = 1;
            this.pnlFiltros.Tag = "cartao";
            // 
            // lblPesquisarProduto
            // 
            this.lblPesquisarProduto.AutoSize = true;
            this.lblPesquisarProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesquisarProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPesquisarProduto.Location = new System.Drawing.Point(18, 10);
            this.lblPesquisarProduto.Name = "lblPesquisarProduto";
            this.lblPesquisarProduto.TabIndex = 0;
            this.lblPesquisarProduto.Text = "Pesquisar por nome ou categoria";
            // 
            // txtPesquisarProduto
            // 
            this.txtPesquisarProduto.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisarProduto.Location = new System.Drawing.Point(18, 33);
            this.txtPesquisarProduto.Name = "txtPesquisarProduto";
            this.txtPesquisarProduto.Size = new System.Drawing.Size(300, 25);
            this.txtPesquisarProduto.TabIndex = 1;
            // 
            // btnPesquisarProduto
            // 
            this.btnPesquisarProduto.Location = new System.Drawing.Point(328, 28);
            this.btnPesquisarProduto.Name = "btnPesquisarProduto";
            this.btnPesquisarProduto.Size = new System.Drawing.Size(124, 36);
            this.btnPesquisarProduto.TabIndex = 2;
            this.btnPesquisarProduto.Tag = "primario";
            this.btnPesquisarProduto.Text = "Pesquisar";
            this.btnPesquisarProduto.UseVisualStyleBackColor = false;
            this.btnPesquisarProduto.Click += new System.EventHandler(this.btnPesquisarProduto_Click);
            // 
            // btnAtualizarProduto
            // 
            this.btnAtualizarProduto.Location = new System.Drawing.Point(462, 28);
            this.btnAtualizarProduto.Name = "btnAtualizarProduto";
            this.btnAtualizarProduto.Size = new System.Drawing.Size(36, 36);
            this.btnAtualizarProduto.TabIndex = 3;
            this.btnAtualizarProduto.Tag = "secundario";
            this.btnAtualizarProduto.Text = "Atualizar";
            this.btnAtualizarProduto.UseVisualStyleBackColor = false;
            this.btnAtualizarProduto.Click += new System.EventHandler(this.btnAtualizarProduto_Click);
            // 
            // btnEstoqueProduto
            // 
            this.btnEstoqueProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnEstoqueProduto.Location = new System.Drawing.Point(956, 18);
            this.btnEstoqueProduto.Name = "btnEstoqueProduto";
            this.btnEstoqueProduto.Size = new System.Drawing.Size(106, 36);
            this.btnEstoqueProduto.TabIndex = 4;
            this.btnEstoqueProduto.Tag = "confirmar";
            this.btnEstoqueProduto.Text = "Estoque";
            this.btnEstoqueProduto.UseVisualStyleBackColor = false;
            this.btnEstoqueProduto.Click += new System.EventHandler(this.btnEstoqueProduto_Click);
            // 
            // btnCategorias
            // 
            this.btnCategorias.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnCategorias.Location = new System.Drawing.Point(818, 18);
            this.btnCategorias.Name = "btnCategorias";
            this.btnCategorias.Size = new System.Drawing.Size(128, 36);
            this.btnCategorias.TabIndex = 5;
            this.btnCategorias.Tag = "secundario";
            this.btnCategorias.Text = "Categorias";
            this.btnCategorias.UseVisualStyleBackColor = false;
            this.btnCategorias.Click += new System.EventHandler(this.btnCategorias_Click);
            // 
            // btnEditarProduto
            // 
            this.btnEditarProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnEditarProduto.Location = new System.Drawing.Point(704, 18);
            this.btnEditarProduto.Name = "btnEditarProduto";
            this.btnEditarProduto.Size = new System.Drawing.Size(104, 36);
            this.btnEditarProduto.TabIndex = 6;
            this.btnEditarProduto.Tag = "primario";
            this.btnEditarProduto.Text = "Editar";
            this.btnEditarProduto.UseVisualStyleBackColor = false;
            this.btnEditarProduto.Click += new System.EventHandler(this.btnEditarProduto_Click);
            // 
            // btnNovoProduto
            // 
            this.btnNovoProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnNovoProduto.Location = new System.Drawing.Point(552, 18);
            this.btnNovoProduto.Name = "btnNovoProduto";
            this.btnNovoProduto.Size = new System.Drawing.Size(142, 36);
            this.btnNovoProduto.TabIndex = 7;
            this.btnNovoProduto.Tag = "especial";
            this.btnNovoProduto.Text = "Novo Produto";
            this.btnNovoProduto.UseVisualStyleBackColor = false;
            this.btnNovoProduto.Click += new System.EventHandler(this.btnNovoProduto_Click);
            // 
            // lblExibindoProduto
            // 
            this.lblExibindoProduto.AutoSize = true;
            this.lblExibindoProduto.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExibindoProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblExibindoProduto.Location = new System.Drawing.Point(24, 184);
            this.lblExibindoProduto.Name = "lblExibindoProduto";
            this.lblExibindoProduto.TabIndex = 2;
            this.lblExibindoProduto.Text = "Exibindo: registros ativos";
            // 
            // lblLegendaEstoque
            // 
            this.lblLegendaEstoque.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.lblLegendaEstoque.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegendaEstoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(22)))), ((int)(((byte)(114)))));
            this.lblLegendaEstoque.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblLegendaEstoque.Location = new System.Drawing.Point(600, 184);
            this.lblLegendaEstoque.Name = "lblLegendaEstoque";
            this.lblLegendaEstoque.Size = new System.Drawing.Size(496, 20);
            this.lblLegendaEstoque.TabIndex = 3;
            this.lblLegendaEstoque.Text = "";
            // 
            // pnlGrade
            // 
            this.pnlGrade.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlGrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlGrade.Controls.Add(this.dgvProdutos);
            this.pnlGrade.Location = new System.Drawing.Point(20, 212);
            this.pnlGrade.Name = "pnlGrade";
            this.pnlGrade.Padding = new System.Windows.Forms.Padding(12);
            this.pnlGrade.Size = new System.Drawing.Size(1080, 328);
            this.pnlGrade.TabIndex = 4;
            this.pnlGrade.Tag = "cartao";
            // 
            // dgvProdutos
            // 
            this.dgvProdutos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProdutos.AllowUserToAddRows = false;
            this.dgvProdutos.AllowUserToDeleteRows = false;
            this.dgvProdutos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProdutos.BackgroundColor = System.Drawing.Color.White;
            this.dgvProdutos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvProdutos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvProdutos.MultiSelect = false;
            this.dgvProdutos.ReadOnly = true;
            this.dgvProdutos.RowHeadersVisible = false;
            this.dgvProdutos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProdutos.Location = new System.Drawing.Point(0, 0);
            this.dgvProdutos.Name = "dgvProdutos";
            this.dgvProdutos.Size = new System.Drawing.Size(100, 100);
            this.dgvProdutos.TabIndex = 0;
            this.dgvProdutos.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProdutos_CellDoubleClick);
            this.dgvProdutos.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvProdutos_DataBindingComplete);
            // 
            // btnVerAtivosProduto
            // 
            this.btnVerAtivosProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerAtivosProduto.Location = new System.Drawing.Point(20, 560);
            this.btnVerAtivosProduto.Name = "btnVerAtivosProduto";
            this.btnVerAtivosProduto.Size = new System.Drawing.Size(128, 36);
            this.btnVerAtivosProduto.TabIndex = 5;
            this.btnVerAtivosProduto.Tag = "secundario";
            this.btnVerAtivosProduto.Text = "Ver Ativos";
            this.btnVerAtivosProduto.UseVisualStyleBackColor = false;
            this.btnVerAtivosProduto.Click += new System.EventHandler(this.btnVerAtivosProduto_Click);
            // 
            // btnVerInativosProduto
            // 
            this.btnVerInativosProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerInativosProduto.Location = new System.Drawing.Point(158, 560);
            this.btnVerInativosProduto.Name = "btnVerInativosProduto";
            this.btnVerInativosProduto.Size = new System.Drawing.Size(142, 36);
            this.btnVerInativosProduto.TabIndex = 6;
            this.btnVerInativosProduto.Tag = "secundario";
            this.btnVerInativosProduto.Text = "Ver Inativos";
            this.btnVerInativosProduto.UseVisualStyleBackColor = false;
            this.btnVerInativosProduto.Click += new System.EventHandler(this.btnVerInativosProduto_Click);
            // 
            // btnVerTodosProdutos
            // 
            this.btnVerTodosProdutos.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerTodosProdutos.Location = new System.Drawing.Point(310, 560);
            this.btnVerTodosProdutos.Name = "btnVerTodosProdutos";
            this.btnVerTodosProdutos.Size = new System.Drawing.Size(120, 36);
            this.btnVerTodosProdutos.TabIndex = 7;
            this.btnVerTodosProdutos.Tag = "secundario";
            this.btnVerTodosProdutos.Text = "Ver Todos";
            this.btnVerTodosProdutos.UseVisualStyleBackColor = false;
            this.btnVerTodosProdutos.Click += new System.EventHandler(this.btnVerTodosProdutos_Click);
            // 
            // btnVoltarProduto
            // 
            this.btnVoltarProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarProduto.Location = new System.Drawing.Point(996, 560);
            this.btnVoltarProduto.Name = "btnVoltarProduto";
            this.btnVoltarProduto.Size = new System.Drawing.Size(104, 36);
            this.btnVoltarProduto.TabIndex = 8;
            this.btnVoltarProduto.Tag = "neutro";
            this.btnVoltarProduto.Text = "Voltar";
            this.btnVoltarProduto.UseVisualStyleBackColor = false;
            this.btnVoltarProduto.Click += new System.EventHandler(this.btnVoltarProduto_Click);
            // 
            // btnExportarProdutos
            // 
            this.btnExportarProdutos.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnExportarProdutos.Location = new System.Drawing.Point(830, 560);
            this.btnExportarProdutos.Name = "btnExportarProdutos";
            this.btnExportarProdutos.Size = new System.Drawing.Size(156, 36);
            this.btnExportarProdutos.TabIndex = 9;
            this.btnExportarProdutos.Tag = "confirmar";
            this.btnExportarProdutos.Text = "Exportar Excel";
            this.btnExportarProdutos.UseVisualStyleBackColor = false;
            this.btnExportarProdutos.Click += new System.EventHandler(this.btnExportarProdutos_Click);
            // 
            // btnReativarProduto
            // 
            this.btnReativarProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnReativarProduto.Location = new System.Drawing.Point(707, 560);
            this.btnReativarProduto.Name = "btnReativarProduto";
            this.btnReativarProduto.Size = new System.Drawing.Size(113, 36);
            this.btnReativarProduto.TabIndex = 10;
            this.btnReativarProduto.Tag = "confirmar";
            this.btnReativarProduto.Text = "Reativar";
            this.btnReativarProduto.UseVisualStyleBackColor = false;
            this.btnReativarProduto.Click += new System.EventHandler(this.btnReativarProduto_Click);
            // 
            // btnInativarProduto
            // 
            this.btnInativarProduto.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnInativarProduto.Location = new System.Drawing.Point(584, 560);
            this.btnInativarProduto.Name = "btnInativarProduto";
            this.btnInativarProduto.Size = new System.Drawing.Size(113, 36);
            this.btnInativarProduto.TabIndex = 11;
            this.btnInativarProduto.Tag = "alerta";
            this.btnInativarProduto.Text = "Inativar";
            this.btnInativarProduto.UseVisualStyleBackColor = false;
            this.btnInativarProduto.Click += new System.EventHandler(this.btnInativarProduto_Click);
            // 
            // FrmConsultarProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1120, 620);
            this.Controls.Add(this.btnInativarProduto);
            this.Controls.Add(this.btnReativarProduto);
            this.Controls.Add(this.btnExportarProdutos);
            this.Controls.Add(this.btnVoltarProduto);
            this.Controls.Add(this.btnVerTodosProdutos);
            this.Controls.Add(this.btnVerInativosProduto);
            this.Controls.Add(this.btnVerAtivosProduto);
            this.Controls.Add(this.pnlGrade);
            this.Controls.Add(this.lblLegendaEstoque);
            this.Controls.Add(this.lblExibindoProduto);
            this.Controls.Add(this.pnlFiltros);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1136, 659);
            this.Name = "FrmConsultarProduto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Produtos";
            this.Load += new System.EventHandler(this.FrmConsultarProduto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProdutos)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlFiltros.ResumeLayout(false);
            this.pnlFiltros.PerformLayout();
            this.pnlGrade.ResumeLayout(false);
            this.pnlGrade.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTituloConsultaProduto;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlFiltros;
        private System.Windows.Forms.Label lblPesquisarProduto;
        private System.Windows.Forms.TextBox txtPesquisarProduto;
        private System.Windows.Forms.Button btnPesquisarProduto;
        private System.Windows.Forms.Button btnAtualizarProduto;
        private System.Windows.Forms.Button btnEstoqueProduto;
        private System.Windows.Forms.Button btnCategorias;
        private System.Windows.Forms.Button btnEditarProduto;
        private System.Windows.Forms.Button btnNovoProduto;
        private System.Windows.Forms.Label lblExibindoProduto;
        private System.Windows.Forms.Label lblLegendaEstoque;
        private System.Windows.Forms.Panel pnlGrade;
        private System.Windows.Forms.DataGridView dgvProdutos;
        private System.Windows.Forms.Button btnVerAtivosProduto;
        private System.Windows.Forms.Button btnVerInativosProduto;
        private System.Windows.Forms.Button btnVerTodosProdutos;
        private System.Windows.Forms.Button btnVoltarProduto;
        private System.Windows.Forms.Button btnExportarProdutos;
        private System.Windows.Forms.Button btnReativarProduto;
        private System.Windows.Forms.Button btnInativarProduto;
    }
}
