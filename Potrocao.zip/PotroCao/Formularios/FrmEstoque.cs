﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    // Controle de estoque: entradas, saídas e histórico de movimentações
    public partial class FrmEstoque : Form
    {
        private bool somenteEstoqueBaixo = false;
        private int produtoInicial = 0;
        private bool carregando = false;

        public FrmEstoque()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        // Permite abrir a tela já com um produto selecionado (usado pela consulta de produtos)
        public void SelecionarProduto(int codigoProduto)
        {
            produtoInicial = codigoProduto;
        }

        private void FrmEstoque_Load(object sender, EventArgs e)
        {
            cmbTipoMovimentacao.Items.Clear();
            cmbTipoMovimentacao.Items.Add("Entrada");
            cmbTipoMovimentacao.Items.Add("Saída");
            cmbTipoMovimentacao.SelectedIndex = 0;

            cmbMotivo.Items.Clear();
            cmbMotivo.Items.AddRange(new object[]
            {
                "Compra / reposição",
                "Venda",
                "Uso em serviço",
                "Devolução",
                "Perda ou avaria",
                "Ajuste de inventário"
            });

            nudQuantidadeMovimentacao.Minimum = 0;
            nudQuantidadeMovimentacao.Maximum = 100000;

            lblLegendaEstoque.Text = "Vermelho = estoque baixo (" + Utilitarios.ESTOQUE_BAIXO +
                                     " unidades ou menos)";

            CarregarFuncionarios();
            CarregarProdutos();
        }

        // ================= LISTA DE PRODUTOS =================

        private void CarregarProdutos(int manterSelecionado = 0)
        {
            carregando = true;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            p.codProduto AS 'Código',
                            p.nome AS 'Produto',
                            c.nome AS 'Categoria',
                            p.quantidadeEstoque AS 'Estoque',
                            CASE
                                WHEN p.quantidadeEstoque = 0 THEN 'Zerado'
                                WHEN p.quantidadeEstoque <= @minimo THEN 'Baixo'
                                ELSE 'Normal'
                            END AS 'Situação'
                        FROM produto p
                        INNER JOIN categoria_produto c ON c.codCategoria = p.codCategoria
                        WHERE p.ativo = 1
                          AND (p.nome LIKE @pesquisa OR c.nome LIKE @pesquisa)";

                    if (somenteEstoqueBaixo)
                        sql += " AND p.quantidadeEstoque <= @minimo";

                    sql += " ORDER BY p.nome";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@pesquisa", "%" + txtPesquisarEstoque.Text.Trim() + "%");
                        comando.Parameters.AddWithValue("@minimo", Utilitarios.ESTOQUE_BAIXO);

                        using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                        {
                            DataTable tabela = new DataTable();
                            adaptador.Fill(tabela);
                            dgvEstoque.DataSource = tabela;
                        }
                    }
                }

                lblExibindoEstoque.Text = somenteEstoqueBaixo
                    ? "Exibindo: somente produtos com estoque baixo"
                    : "Exibindo: todos os produtos ativos";

                btnEstoqueBaixo.Text = somenteEstoqueBaixo ? "Ver Todos" : "Só Estoque Baixo";
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar produtos: " + ex.Message);
            }
            finally
            {
                carregando = false;
            }

            // reposiciona a seleção no produto desejado
            int alvo = manterSelecionado != 0 ? manterSelecionado : produtoInicial;
            produtoInicial = 0;
            dgvEstoque.ClearSelection();

            DataGridViewRow escolhida = dgvEstoque.Rows.Count > 0 ? dgvEstoque.Rows[0] : null;

            foreach (DataGridViewRow linha in dgvEstoque.Rows)
            {
                if (alvo != 0 && Convert.ToInt32(linha.Cells["Código"].Value) == alvo)
                {
                    escolhida = linha;
                    break;
                }
            }

            if (escolhida != null)
            {
                carregando = true;
                dgvEstoque.CurrentCell = escolhida.Cells["Produto"];
                escolhida.Selected = true;
                carregando = false;
            }

            AtualizarProdutoSelecionado();
        }

        private void dgvEstoque_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (dgvEstoque.Columns.Contains("Código")) dgvEstoque.Columns["Código"].FillWeight = 40;
            if (dgvEstoque.Columns.Contains("Produto")) dgvEstoque.Columns["Produto"].FillWeight = 170;
            if (dgvEstoque.Columns.Contains("Estoque"))
            {
                dgvEstoque.Columns["Estoque"].FillWeight = 55;
                dgvEstoque.Columns["Estoque"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            if (dgvEstoque.Columns.Contains("Situação")) dgvEstoque.Columns["Situação"].FillWeight = 60;

            foreach (DataGridViewRow linha in dgvEstoque.Rows)
            {
                string situacao = Convert.ToString(linha.Cells["Situação"].Value);

                if (situacao != "Normal")
                {
                    linha.DefaultCellStyle.ForeColor = Color.Firebrick;
                    linha.DefaultCellStyle.BackColor = Color.FromArgb(255, 235, 235);
                }
            }
        }

        private void dgvEstoque_SelectionChanged(object sender, EventArgs e)
        {
            if (!carregando)
                AtualizarProdutoSelecionado();
        }

        private void AtualizarProdutoSelecionado()
        {
            int codigo = ProdutoSelecionado();

            if (codigo == 0)
            {
                lblProdutoSelecionado.Text = "Selecione um produto na lista ao lado";
                lblEstoqueAtual.Text = "Estoque atual: –";
                btnRegistrarMovimentacao.Enabled = false;
                dgvHistorico.DataSource = null;
                lblHistoricoInfo.Text = "";
                return;
            }

            lblProdutoSelecionado.Text = Utilitarios.TextoSelecionado(dgvEstoque, "Produto");
            lblEstoqueAtual.Text = "Estoque atual: " + Utilitarios.TextoSelecionado(dgvEstoque, "Estoque") + " un.";
            btnRegistrarMovimentacao.Enabled = true;

            CarregarHistorico(codigo);
        }

        private int ProdutoSelecionado()
        {
            if (dgvEstoque.SelectedRows.Count == 0)
                return 0;

            return Utilitarios.CodigoSelecionado(dgvEstoque);
        }

        // ================= HISTÓRICO =================

        private void CarregarHistorico(int codigoProduto)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            DATE_FORMAT(m.dataHora, '%d/%m/%Y %H:%i') AS 'Data e hora',
                            m.tipo AS 'Tipo',
                            m.quantidade AS 'Quantidade',
                            m.estoqueAnterior AS 'Antes',
                            m.estoqueAtual AS 'Depois',
                            IFNULL(m.motivo, '') AS 'Motivo',
                            IFNULL(f.nome, '—') AS 'Responsável'
                        FROM movimentacao_estoque m
                        LEFT JOIN funcionario f ON f.codFun = m.codFun
                        WHERE m.codProduto = @produto
                        ORDER BY m.dataHora DESC, m.codMovimentacao DESC
                        LIMIT 50";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@produto", codigoProduto);

                        using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                        {
                            DataTable tabela = new DataTable();
                            adaptador.Fill(tabela);
                            dgvHistorico.DataSource = tabela;

                            lblHistoricoInfo.Text = tabela.Rows.Count == 0
                                ? "Nenhuma movimentação registrada para este produto"
                                : "Últimas " + tabela.Rows.Count + " movimentações deste produto";
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                dgvHistorico.DataSource = null;

                // 1146 = tabela não existe (script do banco ainda não foi executado)
                lblHistoricoInfo.Text = ex.Number == 1146
                    ? "Tabela de histórico não encontrada: execute o script criar_movimentacao_estoque.sql"
                    : "Erro ao carregar histórico: " + ex.Message;
            }
            catch (Exception ex)
            {
                dgvHistorico.DataSource = null;
                lblHistoricoInfo.Text = "Erro ao carregar histórico: " + ex.Message;
            }
        }

        private void dgvHistorico_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || dgvHistorico.Columns[e.ColumnIndex].Name != "Tipo")
                return;

            string tipo = Convert.ToString(e.Value);
            e.CellStyle.ForeColor = tipo == "Entrada" ? Tema.Sucesso : Tema.Magenta;
            e.CellStyle.Font = Tema.FonteForte(9.75f);
        }

        // ================= REGISTRAR MOVIMENTAÇÃO =================

        private void CarregarFuncionarios()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT 0 AS codFun, '(não informado)' AS nome
                                   UNION ALL
                                   SELECT codFun, nome FROM funcionario WHERE status = 'Ativo'
                                   ORDER BY codFun = 0 DESC, nome";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                    {
                        DataTable tabela = new DataTable();
                        adaptador.Fill(tabela);

                        cmbResponsavelEstoque.DataSource = tabela;
                        cmbResponsavelEstoque.DisplayMember = "nome";
                        cmbResponsavelEstoque.ValueMember = "codFun";
                    }
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar funcionários: " + ex.Message);
            }
        }

        private void btnRegistrarMovimentacao_Click(object sender, EventArgs e)
        {
            int codigo = ProdutoSelecionado();

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione um produto na lista!");
                return;
            }

            int quantidade = (int)nudQuantidadeMovimentacao.Value;

            if (quantidade <= 0)
            {
                Utilitarios.Aviso("Informe uma quantidade maior que zero!");
                nudQuantidadeMovimentacao.Focus();
                return;
            }

            bool entrada = cmbTipoMovimentacao.Text == "Entrada";
            string motivo = cmbMotivo.Text.Trim();

            if (string.IsNullOrWhiteSpace(motivo))
            {
                Utilitarios.Aviso("Informe o motivo da movimentação (ex.: Compra, Venda, Ajuste).");
                cmbMotivo.Focus();
                return;
            }

            int codFun = 0;
            if (cmbResponsavelEstoque.SelectedValue != null)
                int.TryParse(cmbResponsavelEstoque.SelectedValue.ToString(), out codFun);

            string produto = lblProdutoSelecionado.Text;

            if (!Utilitarios.Confirmar(
                    "Confirmar " + (entrada ? "ENTRADA" : "SAÍDA") + " de " + quantidade +
                    " unidade(s) de \"" + produto + "\"?\n\nMotivo: " + motivo,
                    "Confirmar movimentação"))
                return;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    using (MySqlTransaction transacao = conexao.BeginTransaction())
                    {
                        try
                        {
                            // Lê o estoque travando a linha, para dois lançamentos ao mesmo tempo não se atrapalharem
                            int anterior;

                            using (MySqlCommand ler = new MySqlCommand(
                                "SELECT quantidadeEstoque FROM produto WHERE codProduto = @c FOR UPDATE",
                                conexao, transacao))
                            {
                                ler.Parameters.AddWithValue("@c", codigo);
                                anterior = Convert.ToInt32(ler.ExecuteScalar());
                            }

                            int atual = entrada ? anterior + quantidade : anterior - quantidade;

                            if (atual < 0)
                            {
                                transacao.Rollback();
                                Utilitarios.Aviso("Saída maior que o estoque disponível!\n\n" +
                                    "Estoque atual: " + anterior + " un.\nSaída pedida: " + quantidade + " un.");
                                return;
                            }

                            using (MySqlCommand atualizar = new MySqlCommand(
                                "UPDATE produto SET quantidadeEstoque = @q WHERE codProduto = @c",
                                conexao, transacao))
                            {
                                atualizar.Parameters.AddWithValue("@q", atual);
                                atualizar.Parameters.AddWithValue("@c", codigo);
                                atualizar.ExecuteNonQuery();
                            }

                            using (MySqlCommand registrar = new MySqlCommand(
                                @"INSERT INTO movimentacao_estoque
                                    (codProduto, tipo, quantidade, estoqueAnterior, estoqueAtual, motivo, codFun)
                                  VALUES (@c, @tipo, @qtd, @ant, @atual, @motivo, @fun)",
                                conexao, transacao))
                            {
                                registrar.Parameters.AddWithValue("@c", codigo);
                                registrar.Parameters.AddWithValue("@tipo", entrada ? "Entrada" : "Saída");
                                registrar.Parameters.AddWithValue("@qtd", quantidade);
                                registrar.Parameters.AddWithValue("@ant", anterior);
                                registrar.Parameters.AddWithValue("@atual", atual);
                                registrar.Parameters.AddWithValue("@motivo", motivo);
                                registrar.Parameters.AddWithValue("@fun", codFun == 0 ? (object)DBNull.Value : codFun);
                                registrar.ExecuteNonQuery();
                            }

                            transacao.Commit();

                            string alerta = atual <= Utilitarios.ESTOQUE_BAIXO
                                ? "\n\nAtenção: o estoque deste produto está baixo."
                                : "";

                            Utilitarios.Sucesso("Movimentação registrada com sucesso!\n\n" +
                                "Estoque anterior: " + anterior + " un.\nEstoque atual: " + atual + " un." + alerta);
                        }
                        catch
                        {
                            transacao.Rollback();
                            throw;
                        }
                    }
                }

                nudQuantidadeMovimentacao.Value = 0;
                cmbMotivo.Text = "";
                CarregarProdutos(codigo);
            }
            catch (MySqlException ex) when (ex.Number == 1146)
            {
                Utilitarios.Erro("A tabela de histórico ainda não existe no banco.\n\n" +
                    "Execute o script criar_movimentacao_estoque.sql no phpMyAdmin e tente de novo.\n" +
                    "Nenhuma alteração foi feita no estoque.");
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao registrar movimentação: " + ex.Message +
                    "\n\nNenhuma alteração foi feita no estoque.");
            }
        }

        // ================= FILTROS / EXPORTAR / VOLTAR =================

        private void btnPesquisarEstoque_Click(object sender, EventArgs e)
        {
            CarregarProdutos(ProdutoSelecionado());
        }

        private void btnAtualizarEstoque_Click(object sender, EventArgs e)
        {
            txtPesquisarEstoque.Clear();
            somenteEstoqueBaixo = false;
            CarregarProdutos(ProdutoSelecionado());
        }

        private void btnEstoqueBaixo_Click(object sender, EventArgs e)
        {
            somenteEstoqueBaixo = !somenteEstoqueBaixo;
            CarregarProdutos();
        }

        private void btnExportarEstoque_Click(object sender, EventArgs e)
        {
            Utilitarios.ExportarExcel(dgvEstoque, "Estoque", "Estoque");
        }

        private void btnVoltarEstoque_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
