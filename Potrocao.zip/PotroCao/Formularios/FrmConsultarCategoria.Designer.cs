﻿namespace PotroCao.Formularios
{
    partial class FrmConsultarCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTituloConsultaCategoria = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlFiltros = new System.Windows.Forms.Panel();
            this.lblPesquisarCategoria = new System.Windows.Forms.Label();
            this.txtPesquisarCategoria = new System.Windows.Forms.TextBox();
            this.btnPesquisarCategoria = new System.Windows.Forms.Button();
            this.btnAtualizarCategoria = new System.Windows.Forms.Button();
            this.btnEditarCategoria = new System.Windows.Forms.Button();
            this.btnNovaCategoria = new System.Windows.Forms.Button();
            this.lblExibindoCategoria = new System.Windows.Forms.Label();
            this.pnlGrade = new System.Windows.Forms.Panel();
            this.dgvCategorias = new System.Windows.Forms.DataGridView();
            this.btnVerAtivasCategoria = new System.Windows.Forms.Button();
            this.btnVerInativasCategoria = new System.Windows.Forms.Button();
            this.btnVerTodasCategorias = new System.Windows.Forms.Button();
            this.btnVoltarCategoria = new System.Windows.Forms.Button();
            this.btnExportarCategorias = new System.Windows.Forms.Button();
            this.btnReativarCategoria = new System.Windows.Forms.Button();
            this.btnInativarCategoria = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlFiltros.SuspendLayout();
            this.pnlGrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategorias)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTituloConsultaCategoria);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTituloConsultaCategoria
            // 
            this.lblTituloConsultaCategoria.AutoSize = true;
            this.lblTituloConsultaCategoria.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloConsultaCategoria.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTituloConsultaCategoria.Location = new System.Drawing.Point(22, 14);
            this.lblTituloConsultaCategoria.Name = "lblTituloConsultaCategoria";
            this.lblTituloConsultaCategoria.TabIndex = 0;
            this.lblTituloConsultaCategoria.Text = "Categorias de Produtos";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Cadastre, edite, inative e reative as categorias do estoque.";
            // 
            // pnlFiltros
            // 
            this.pnlFiltros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.pnlFiltros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlFiltros.Controls.Add(this.btnNovaCategoria);
            this.pnlFiltros.Controls.Add(this.btnEditarCategoria);
            this.pnlFiltros.Controls.Add(this.btnAtualizarCategoria);
            this.pnlFiltros.Controls.Add(this.btnPesquisarCategoria);
            this.pnlFiltros.Controls.Add(this.txtPesquisarCategoria);
            this.pnlFiltros.Controls.Add(this.lblPesquisarCategoria);
            this.pnlFiltros.Location = new System.Drawing.Point(20, 100);
            this.pnlFiltros.Name = "pnlFiltros";
            this.pnlFiltros.Size = new System.Drawing.Size(1000, 72);
            this.pnlFiltros.TabIndex = 1;
            this.pnlFiltros.Tag = "cartao";
            // 
            // lblPesquisarCategoria
            // 
            this.lblPesquisarCategoria.AutoSize = true;
            this.lblPesquisarCategoria.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesquisarCategoria.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPesquisarCategoria.Location = new System.Drawing.Point(18, 10);
            this.lblPesquisarCategoria.Name = "lblPesquisarCategoria";
            this.lblPesquisarCategoria.TabIndex = 0;
            this.lblPesquisarCategoria.Text = "Pesquisar por nome";
            // 
            // txtPesquisarCategoria
            // 
            this.txtPesquisarCategoria.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisarCategoria.Location = new System.Drawing.Point(18, 33);
            this.txtPesquisarCategoria.Name = "txtPesquisarCategoria";
            this.txtPesquisarCategoria.Size = new System.Drawing.Size(300, 25);
            this.txtPesquisarCategoria.TabIndex = 1;
            // 
            // btnPesquisarCategoria
            // 
            this.btnPesquisarCategoria.Location = new System.Drawing.Point(328, 28);
            this.btnPesquisarCategoria.Name = "btnPesquisarCategoria";
            this.btnPesquisarCategoria.Size = new System.Drawing.Size(124, 36);
            this.btnPesquisarCategoria.TabIndex = 2;
            this.btnPesquisarCategoria.Tag = "primario";
            this.btnPesquisarCategoria.Text = "Pesquisar";
            this.btnPesquisarCategoria.UseVisualStyleBackColor = false;
            this.btnPesquisarCategoria.Click += new System.EventHandler(this.btnPesquisarCategoria_Click);
            // 
            // btnAtualizarCategoria
            // 
            this.btnAtualizarCategoria.Location = new System.Drawing.Point(462, 28);
            this.btnAtualizarCategoria.Name = "btnAtualizarCategoria";
            this.btnAtualizarCategoria.Size = new System.Drawing.Size(36, 36);
            this.btnAtualizarCategoria.TabIndex = 3;
            this.btnAtualizarCategoria.Tag = "secundario";
            this.btnAtualizarCategoria.Text = "Atualizar";
            this.btnAtualizarCategoria.UseVisualStyleBackColor = false;
            this.btnAtualizarCategoria.Click += new System.EventHandler(this.btnAtualizarCategoria_Click);
            // 
            // btnEditarCategoria
            // 
            this.btnEditarCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnEditarCategoria.Location = new System.Drawing.Point(878, 18);
            this.btnEditarCategoria.Name = "btnEditarCategoria";
            this.btnEditarCategoria.Size = new System.Drawing.Size(104, 36);
            this.btnEditarCategoria.TabIndex = 4;
            this.btnEditarCategoria.Tag = "primario";
            this.btnEditarCategoria.Text = "Editar";
            this.btnEditarCategoria.UseVisualStyleBackColor = false;
            this.btnEditarCategoria.Click += new System.EventHandler(this.btnEditarCategoria_Click);
            // 
            // btnNovaCategoria
            // 
            this.btnNovaCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnNovaCategoria.Location = new System.Drawing.Point(712, 18);
            this.btnNovaCategoria.Name = "btnNovaCategoria";
            this.btnNovaCategoria.Size = new System.Drawing.Size(156, 36);
            this.btnNovaCategoria.TabIndex = 5;
            this.btnNovaCategoria.Tag = "especial";
            this.btnNovaCategoria.Text = "Nova Categoria";
            this.btnNovaCategoria.UseVisualStyleBackColor = false;
            this.btnNovaCategoria.Click += new System.EventHandler(this.btnNovaCategoria_Click);
            // 
            // lblExibindoCategoria
            // 
            this.lblExibindoCategoria.AutoSize = true;
            this.lblExibindoCategoria.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExibindoCategoria.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblExibindoCategoria.Location = new System.Drawing.Point(24, 184);
            this.lblExibindoCategoria.Name = "lblExibindoCategoria";
            this.lblExibindoCategoria.TabIndex = 2;
            this.lblExibindoCategoria.Text = "Exibindo: registros ativos";
            // 
            // pnlGrade
            // 
            this.pnlGrade.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlGrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlGrade.Controls.Add(this.dgvCategorias);
            this.pnlGrade.Location = new System.Drawing.Point(20, 212);
            this.pnlGrade.Name = "pnlGrade";
            this.pnlGrade.Padding = new System.Windows.Forms.Padding(12);
            this.pnlGrade.Size = new System.Drawing.Size(1000, 328);
            this.pnlGrade.TabIndex = 3;
            this.pnlGrade.Tag = "cartao";
            // 
            // dgvCategorias
            // 
            this.dgvCategorias.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCategorias.AllowUserToAddRows = false;
            this.dgvCategorias.AllowUserToDeleteRows = false;
            this.dgvCategorias.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCategorias.BackgroundColor = System.Drawing.Color.White;
            this.dgvCategorias.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvCategorias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvCategorias.MultiSelect = false;
            this.dgvCategorias.ReadOnly = true;
            this.dgvCategorias.RowHeadersVisible = false;
            this.dgvCategorias.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCategorias.Location = new System.Drawing.Point(0, 0);
            this.dgvCategorias.Name = "dgvCategorias";
            this.dgvCategorias.Size = new System.Drawing.Size(100, 100);
            this.dgvCategorias.TabIndex = 0;
            this.dgvCategorias.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCategorias_CellDoubleClick);
            this.dgvCategorias.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvCategorias_DataBindingComplete);
            // 
            // btnVerAtivasCategoria
            // 
            this.btnVerAtivasCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerAtivasCategoria.Location = new System.Drawing.Point(20, 560);
            this.btnVerAtivasCategoria.Name = "btnVerAtivasCategoria";
            this.btnVerAtivasCategoria.Size = new System.Drawing.Size(128, 36);
            this.btnVerAtivasCategoria.TabIndex = 4;
            this.btnVerAtivasCategoria.Tag = "secundario";
            this.btnVerAtivasCategoria.Text = "Ver Ativas";
            this.btnVerAtivasCategoria.UseVisualStyleBackColor = false;
            this.btnVerAtivasCategoria.Click += new System.EventHandler(this.btnVerAtivasCategoria_Click);
            // 
            // btnVerInativasCategoria
            // 
            this.btnVerInativasCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerInativasCategoria.Location = new System.Drawing.Point(158, 560);
            this.btnVerInativasCategoria.Name = "btnVerInativasCategoria";
            this.btnVerInativasCategoria.Size = new System.Drawing.Size(142, 36);
            this.btnVerInativasCategoria.TabIndex = 5;
            this.btnVerInativasCategoria.Tag = "secundario";
            this.btnVerInativasCategoria.Text = "Ver Inativas";
            this.btnVerInativasCategoria.UseVisualStyleBackColor = false;
            this.btnVerInativasCategoria.Click += new System.EventHandler(this.btnVerInativasCategoria_Click);
            // 
            // btnVerTodasCategorias
            // 
            this.btnVerTodasCategorias.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerTodasCategorias.Location = new System.Drawing.Point(310, 560);
            this.btnVerTodasCategorias.Name = "btnVerTodasCategorias";
            this.btnVerTodasCategorias.Size = new System.Drawing.Size(120, 36);
            this.btnVerTodasCategorias.TabIndex = 6;
            this.btnVerTodasCategorias.Tag = "secundario";
            this.btnVerTodasCategorias.Text = "Ver Todas";
            this.btnVerTodasCategorias.UseVisualStyleBackColor = false;
            this.btnVerTodasCategorias.Click += new System.EventHandler(this.btnVerTodasCategorias_Click);
            // 
            // btnVoltarCategoria
            // 
            this.btnVoltarCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarCategoria.Location = new System.Drawing.Point(916, 560);
            this.btnVoltarCategoria.Name = "btnVoltarCategoria";
            this.btnVoltarCategoria.Size = new System.Drawing.Size(104, 36);
            this.btnVoltarCategoria.TabIndex = 7;
            this.btnVoltarCategoria.Tag = "neutro";
            this.btnVoltarCategoria.Text = "Voltar";
            this.btnVoltarCategoria.UseVisualStyleBackColor = false;
            this.btnVoltarCategoria.Click += new System.EventHandler(this.btnVoltarCategoria_Click);
            // 
            // btnExportarCategorias
            // 
            this.btnExportarCategorias.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnExportarCategorias.Location = new System.Drawing.Point(750, 560);
            this.btnExportarCategorias.Name = "btnExportarCategorias";
            this.btnExportarCategorias.Size = new System.Drawing.Size(156, 36);
            this.btnExportarCategorias.TabIndex = 8;
            this.btnExportarCategorias.Tag = "confirmar";
            this.btnExportarCategorias.Text = "Exportar Excel";
            this.btnExportarCategorias.UseVisualStyleBackColor = false;
            this.btnExportarCategorias.Click += new System.EventHandler(this.btnExportarCategorias_Click);
            // 
            // btnReativarCategoria
            // 
            this.btnReativarCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnReativarCategoria.Location = new System.Drawing.Point(627, 560);
            this.btnReativarCategoria.Name = "btnReativarCategoria";
            this.btnReativarCategoria.Size = new System.Drawing.Size(113, 36);
            this.btnReativarCategoria.TabIndex = 9;
            this.btnReativarCategoria.Tag = "confirmar";
            this.btnReativarCategoria.Text = "Reativar";
            this.btnReativarCategoria.UseVisualStyleBackColor = false;
            this.btnReativarCategoria.Click += new System.EventHandler(this.btnReativarCategoria_Click);
            // 
            // btnInativarCategoria
            // 
            this.btnInativarCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnInativarCategoria.Location = new System.Drawing.Point(504, 560);
            this.btnInativarCategoria.Name = "btnInativarCategoria";
            this.btnInativarCategoria.Size = new System.Drawing.Size(113, 36);
            this.btnInativarCategoria.TabIndex = 10;
            this.btnInativarCategoria.Tag = "alerta";
            this.btnInativarCategoria.Text = "Inativar";
            this.btnInativarCategoria.UseVisualStyleBackColor = false;
            this.btnInativarCategoria.Click += new System.EventHandler(this.btnInativarCategoria_Click);
            // 
            // FrmConsultarCategoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1040, 620);
            this.Controls.Add(this.btnInativarCategoria);
            this.Controls.Add(this.btnReativarCategoria);
            this.Controls.Add(this.btnExportarCategorias);
            this.Controls.Add(this.btnVoltarCategoria);
            this.Controls.Add(this.btnVerTodasCategorias);
            this.Controls.Add(this.btnVerInativasCategoria);
            this.Controls.Add(this.btnVerAtivasCategoria);
            this.Controls.Add(this.pnlGrade);
            this.Controls.Add(this.lblExibindoCategoria);
            this.Controls.Add(this.pnlFiltros);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1056, 659);
            this.Name = "FrmConsultarCategoria";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Categorias de Produtos";
            this.Load += new System.EventHandler(this.FrmConsultarCategoria_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategorias)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlFiltros.ResumeLayout(false);
            this.pnlFiltros.PerformLayout();
            this.pnlGrade.ResumeLayout(false);
            this.pnlGrade.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTituloConsultaCategoria;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlFiltros;
        private System.Windows.Forms.Label lblPesquisarCategoria;
        private System.Windows.Forms.TextBox txtPesquisarCategoria;
        private System.Windows.Forms.Button btnPesquisarCategoria;
        private System.Windows.Forms.Button btnAtualizarCategoria;
        private System.Windows.Forms.Button btnEditarCategoria;
        private System.Windows.Forms.Button btnNovaCategoria;
        private System.Windows.Forms.Label lblExibindoCategoria;
        private System.Windows.Forms.Panel pnlGrade;
        private System.Windows.Forms.DataGridView dgvCategorias;
        private System.Windows.Forms.Button btnVerAtivasCategoria;
        private System.Windows.Forms.Button btnVerInativasCategoria;
        private System.Windows.Forms.Button btnVerTodasCategorias;
        private System.Windows.Forms.Button btnVoltarCategoria;
        private System.Windows.Forms.Button btnExportarCategorias;
        private System.Windows.Forms.Button btnReativarCategoria;
        private System.Windows.Forms.Button btnInativarCategoria;
    }
}
