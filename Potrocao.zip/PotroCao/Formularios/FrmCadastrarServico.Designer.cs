﻿namespace PotroCao.Formularios
{
    partial class FrmCadastrarServico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTituloServico = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlDados = new System.Windows.Forms.Panel();
            this.lblSecaoServico = new System.Windows.Forms.Label();
            this.lblNomeServico = new System.Windows.Forms.Label();
            this.txtNomeServico = new System.Windows.Forms.TextBox();
            this.lblPrecoServico = new System.Windows.Forms.Label();
            this.nudPrecoServico = new System.Windows.Forms.NumericUpDown();
            this.lblDuracaoServico = new System.Windows.Forms.Label();
            this.nudDuracaoServico = new System.Windows.Forms.NumericUpDown();
            this.lblDescricaoServico = new System.Windows.Forms.Label();
            this.txtDescricaoServico = new System.Windows.Forms.TextBox();
            this.btnSalvarServico = new System.Windows.Forms.Button();
            this.btnLimparServico = new System.Windows.Forms.Button();
            this.btnVoltarServico = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlDados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrecoServico)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDuracaoServico)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTituloServico);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTituloServico
            // 
            this.lblTituloServico.AutoSize = true;
            this.lblTituloServico.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTituloServico.Location = new System.Drawing.Point(22, 14);
            this.lblTituloServico.Name = "lblTituloServico";
            this.lblTituloServico.TabIndex = 0;
            this.lblTituloServico.Text = "Cadastrar Serviço";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Banho, tosa e demais serviços oferecidos. Campos com * são obrigatórios.";
            // 
            // pnlDados
            // 
            this.pnlDados.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlDados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlDados.Controls.Add(this.btnVoltarServico);
            this.pnlDados.Controls.Add(this.btnLimparServico);
            this.pnlDados.Controls.Add(this.btnSalvarServico);
            this.pnlDados.Controls.Add(this.txtDescricaoServico);
            this.pnlDados.Controls.Add(this.lblDescricaoServico);
            this.pnlDados.Controls.Add(this.nudDuracaoServico);
            this.pnlDados.Controls.Add(this.lblDuracaoServico);
            this.pnlDados.Controls.Add(this.nudPrecoServico);
            this.pnlDados.Controls.Add(this.lblPrecoServico);
            this.pnlDados.Controls.Add(this.txtNomeServico);
            this.pnlDados.Controls.Add(this.lblNomeServico);
            this.pnlDados.Controls.Add(this.lblSecaoServico);
            this.pnlDados.Location = new System.Drawing.Point(20, 100);
            this.pnlDados.Name = "pnlDados";
            this.pnlDados.Size = new System.Drawing.Size(600, 346);
            this.pnlDados.TabIndex = 1;
            this.pnlDados.Tag = "cartao";
            // 
            // lblSecaoServico
            // 
            this.lblSecaoServico.AutoSize = true;
            this.lblSecaoServico.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoServico.Location = new System.Drawing.Point(24, 16);
            this.lblSecaoServico.Name = "lblSecaoServico";
            this.lblSecaoServico.TabIndex = 0;
            this.lblSecaoServico.Text = "Dados do serviço";
            // 
            // lblNomeServico
            // 
            this.lblNomeServico.AutoSize = true;
            this.lblNomeServico.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblNomeServico.Location = new System.Drawing.Point(24, 50);
            this.lblNomeServico.Name = "lblNomeServico";
            this.lblNomeServico.TabIndex = 1;
            this.lblNomeServico.Text = "Nome *";
            // 
            // txtNomeServico
            // 
            this.txtNomeServico.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeServico.Location = new System.Drawing.Point(24, 72);
            this.txtNomeServico.MaxLength = 100;
            this.txtNomeServico.Name = "txtNomeServico";
            this.txtNomeServico.Size = new System.Drawing.Size(552, 25);
            this.txtNomeServico.TabIndex = 2;
            // 
            // lblPrecoServico
            // 
            this.lblPrecoServico.AutoSize = true;
            this.lblPrecoServico.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPrecoServico.Location = new System.Drawing.Point(24, 110);
            this.lblPrecoServico.Name = "lblPrecoServico";
            this.lblPrecoServico.TabIndex = 3;
            this.lblPrecoServico.Text = "Preço (R$) *";
            // 
            // nudPrecoServico
            // 
            this.nudPrecoServico.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudPrecoServico.DecimalPlaces = 2;
            this.nudPrecoServico.ThousandsSeparator = true;
            this.nudPrecoServico.Maximum = new decimal(new int[] { 99999, 0, 0, 0});
            this.nudPrecoServico.Location = new System.Drawing.Point(24, 132);
            this.nudPrecoServico.Name = "nudPrecoServico";
            this.nudPrecoServico.Size = new System.Drawing.Size(160, 26);
            this.nudPrecoServico.TabIndex = 4;
            // 
            // lblDuracaoServico
            // 
            this.lblDuracaoServico.AutoSize = true;
            this.lblDuracaoServico.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDuracaoServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblDuracaoServico.Location = new System.Drawing.Point(208, 110);
            this.lblDuracaoServico.Name = "lblDuracaoServico";
            this.lblDuracaoServico.TabIndex = 5;
            this.lblDuracaoServico.Text = "Duração (minutos) *";
            // 
            // nudDuracaoServico
            // 
            this.nudDuracaoServico.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudDuracaoServico.Maximum = new decimal(new int[] { 600, 0, 0, 0});
            this.nudDuracaoServico.Location = new System.Drawing.Point(208, 132);
            this.nudDuracaoServico.Name = "nudDuracaoServico";
            this.nudDuracaoServico.Size = new System.Drawing.Size(160, 26);
            this.nudDuracaoServico.TabIndex = 6;
            // 
            // lblDescricaoServico
            // 
            this.lblDescricaoServico.AutoSize = true;
            this.lblDescricaoServico.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescricaoServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblDescricaoServico.Location = new System.Drawing.Point(24, 170);
            this.lblDescricaoServico.Name = "lblDescricaoServico";
            this.lblDescricaoServico.TabIndex = 7;
            this.lblDescricaoServico.Text = "Descrição";
            // 
            // txtDescricaoServico
            // 
            this.txtDescricaoServico.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescricaoServico.Multiline = true;
            this.txtDescricaoServico.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescricaoServico.Location = new System.Drawing.Point(24, 192);
            this.txtDescricaoServico.Name = "txtDescricaoServico";
            this.txtDescricaoServico.Size = new System.Drawing.Size(552, 70);
            this.txtDescricaoServico.TabIndex = 8;
            // 
            // btnSalvarServico
            // 
            this.btnSalvarServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnSalvarServico.Location = new System.Drawing.Point(240, 288);
            this.btnSalvarServico.Name = "btnSalvarServico";
            this.btnSalvarServico.Size = new System.Drawing.Size(108, 36);
            this.btnSalvarServico.TabIndex = 9;
            this.btnSalvarServico.Tag = "primario";
            this.btnSalvarServico.Text = "Salvar";
            this.btnSalvarServico.UseVisualStyleBackColor = false;
            this.btnSalvarServico.Click += new System.EventHandler(this.btnSalvarServico_Click);
            // 
            // btnLimparServico
            // 
            this.btnLimparServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnLimparServico.Location = new System.Drawing.Point(358, 288);
            this.btnLimparServico.Name = "btnLimparServico";
            this.btnLimparServico.Size = new System.Drawing.Size(108, 36);
            this.btnLimparServico.TabIndex = 10;
            this.btnLimparServico.Tag = "secundario";
            this.btnLimparServico.Text = "Limpar";
            this.btnLimparServico.UseVisualStyleBackColor = false;
            this.btnLimparServico.Click += new System.EventHandler(this.btnLimparServico_Click);
            // 
            // btnVoltarServico
            // 
            this.btnVoltarServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarServico.Location = new System.Drawing.Point(476, 288);
            this.btnVoltarServico.Name = "btnVoltarServico";
            this.btnVoltarServico.Size = new System.Drawing.Size(100, 36);
            this.btnVoltarServico.TabIndex = 11;
            this.btnVoltarServico.Tag = "neutro";
            this.btnVoltarServico.Text = "Voltar";
            this.btnVoltarServico.UseVisualStyleBackColor = false;
            this.btnVoltarServico.Click += new System.EventHandler(this.btnVoltarServico_Click);
            // 
            // FrmCadastrarServico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(640, 466);
            this.Controls.Add(this.pnlDados);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmCadastrarServico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Cadastrar Serviço";
            this.Load += new System.EventHandler(this.FrmCadastrarServico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudPrecoServico)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDuracaoServico)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlDados.ResumeLayout(false);
            this.pnlDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTituloServico;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlDados;
        private System.Windows.Forms.Label lblSecaoServico;
        private System.Windows.Forms.Label lblNomeServico;
        private System.Windows.Forms.TextBox txtNomeServico;
        private System.Windows.Forms.Label lblPrecoServico;
        private System.Windows.Forms.NumericUpDown nudPrecoServico;
        private System.Windows.Forms.Label lblDuracaoServico;
        private System.Windows.Forms.NumericUpDown nudDuracaoServico;
        private System.Windows.Forms.Label lblDescricaoServico;
        private System.Windows.Forms.TextBox txtDescricaoServico;
        private System.Windows.Forms.Button btnSalvarServico;
        private System.Windows.Forms.Button btnLimparServico;
        private System.Windows.Forms.Button btnVoltarServico;
    }
}
