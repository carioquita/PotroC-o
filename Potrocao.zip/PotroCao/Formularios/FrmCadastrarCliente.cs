﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmCadastrarCliente : Form
    {
        private int codigoCliente = 0;
        public FrmCadastrarCliente()


        {
            InitializeComponent();
            Tema.Aplicar(this);
        }
        public void CarregarCliente(int codigo)
        {
            codigoCliente = codigo;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT *
                           FROM cliente
                           WHERE codCli = @codigo";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                    {
                        cmd.Parameters.AddWithValue("@codigo", codigo);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtNome.Text = reader["nome"].ToString();
                                txtCPF.Text = reader["cpf"].ToString();
                                txtRG.Text = reader["rg"].ToString();
                                txtTelefone.Text = reader["telefone"].ToString();
                                txtEmail.Text = reader["email"].ToString();
                                txtEndereco.Text = reader["endereco"].ToString();
                                txtCidade.Text = reader["cidade"].ToString();

                                if (reader["datanasc"] != DBNull.Value)
                                {
                                    dtpDataNascimento.Value =
                                        Convert.ToDateTime(reader["datanasc"]);

                                    dtpDataNascimento.Checked = true;
                                }
                                else
                                {
                                    dtpDataNascimento.Checked = false;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao carregar cliente: " + erro.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }


        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text) ||
                string.IsNullOrWhiteSpace(txtTelefone.Text))
            {
                CaixaMensagem.Show("Preencha o nome e o telefone do cliente!");
                return;
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql;

                    if (codigoCliente == 0)
                    {
                        sql = @"INSERT INTO cliente
                (nome, email, telefone, rg, cpf, cidade, datanasc, endereco)
                VALUES
                (@nome, @email, @telefone, @rg, @cpf, @cidade, @datanasc, @endereco)";
                    }
                    else
                    {
                        sql = @"UPDATE cliente SET
                nome = @nome,
                email = @email,
                telefone = @telefone,
                rg = @rg,
                cpf = @cpf,
                cidade = @cidade,
                datanasc = @datanasc,
                endereco = @endereco
                WHERE codCli = @codigo";
                    }

                    using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                    {
                        cmd.Parameters.AddWithValue("@nome", txtNome.Text.Trim());

                        cmd.Parameters.AddWithValue("@email",
                            string.IsNullOrWhiteSpace(txtEmail.Text)
                            ? (object)DBNull.Value : txtEmail.Text.Trim());

                        cmd.Parameters.AddWithValue("@telefone", txtTelefone.Text.Trim());

                        cmd.Parameters.AddWithValue("@rg",
                            string.IsNullOrWhiteSpace(txtRG.Text)
                            ? (object)DBNull.Value : txtRG.Text.Trim());

                        cmd.Parameters.AddWithValue("@cpf",
                            string.IsNullOrWhiteSpace(txtCPF.Text)
                            ? (object)DBNull.Value : txtCPF.Text.Trim());

                        cmd.Parameters.AddWithValue("@cidade",
                            string.IsNullOrWhiteSpace(txtCidade.Text)
                            ? (object)DBNull.Value : txtCidade.Text.Trim());

                        cmd.Parameters.AddWithValue("@datanasc",
                            dtpDataNascimento.Checked
                            ? (object)dtpDataNascimento.Value.Date : DBNull.Value);

                        cmd.Parameters.AddWithValue("@endereco",
                        string.IsNullOrWhiteSpace(txtEndereco.Text)
                        ? (object)DBNull.Value : txtEndereco.Text.Trim());

                        if (codigoCliente != 0)
                        {
                            cmd.Parameters.AddWithValue("@codigo", codigoCliente);
                        }

                        cmd.ExecuteNonQuery();
                    }
                }

                if (codigoCliente == 0)
                {
                    CaixaMensagem.Show("Cliente cadastrado com sucesso!",
                        "PotroCão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    CaixaMensagem.Show("Cliente atualizado com sucesso!",
                        "PotroCão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                this.Close();
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao salvar cliente: " + erro.Message);
            }
        }


        
        private void LimparCampos()
        {
            txtNome.Clear();
            txtCPF.Clear();
            txtRG.Clear();
            txtTelefone.Clear();
            txtEmail.Clear();
            txtEndereco.Clear();
            txtCidade.Clear();

            dtpDataNascimento.Value = DateTime.Today;
            dtpDataNascimento.Checked = false;
        }

        private void FrmCadastrarCliente_Load(object sender, EventArgs e)
        {

        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
