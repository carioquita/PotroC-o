﻿namespace PotroCao.Formularios
{
    partial class FrmEstoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlFiltros = new System.Windows.Forms.Panel();
            this.lblPesquisarEstoque = new System.Windows.Forms.Label();
            this.txtPesquisarEstoque = new System.Windows.Forms.TextBox();
            this.btnPesquisarEstoque = new System.Windows.Forms.Button();
            this.btnAtualizarEstoque = new System.Windows.Forms.Button();
            this.btnEstoqueBaixo = new System.Windows.Forms.Button();
            this.lblExibindoEstoque = new System.Windows.Forms.Label();
            this.lblLegendaEstoque = new System.Windows.Forms.Label();
            this.pnlProdutosEstoque = new System.Windows.Forms.Panel();
            this.dgvEstoque = new System.Windows.Forms.DataGridView();
            this.pnlMovimentar = new System.Windows.Forms.Panel();
            this.lblSecaoMovimentar = new System.Windows.Forms.Label();
            this.lblProdutoSelecionado = new System.Windows.Forms.Label();
            this.lblEstoqueAtual = new System.Windows.Forms.Label();
            this.lblTipoMovimentacao = new System.Windows.Forms.Label();
            this.cmbTipoMovimentacao = new System.Windows.Forms.ComboBox();
            this.lblQuantidadeMovimentacao = new System.Windows.Forms.Label();
            this.nudQuantidadeMovimentacao = new System.Windows.Forms.NumericUpDown();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.cmbMotivo = new System.Windows.Forms.ComboBox();
            this.lblResponsavelEstoque = new System.Windows.Forms.Label();
            this.cmbResponsavelEstoque = new System.Windows.Forms.ComboBox();
            this.btnRegistrarMovimentacao = new System.Windows.Forms.Button();
            this.lblSecaoHistorico = new System.Windows.Forms.Label();
            this.lblHistoricoInfo = new System.Windows.Forms.Label();
            this.pnlHistorico = new System.Windows.Forms.Panel();
            this.dgvHistorico = new System.Windows.Forms.DataGridView();
            this.btnExportarEstoque = new System.Windows.Forms.Button();
            this.btnVoltarEstoque = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlFiltros.SuspendLayout();
            this.pnlProdutosEstoque.SuspendLayout();
            this.pnlMovimentar.SuspendLayout();
            this.pnlHistorico.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstoque)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantidadeMovimentacao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistorico)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTitulo.Location = new System.Drawing.Point(22, 14);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Controle de Estoque";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Registre entradas e saídas. Cada movimentação fica guardada no histórico.";
            // 
            // pnlFiltros
            // 
            this.pnlFiltros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.pnlFiltros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlFiltros.Controls.Add(this.btnEstoqueBaixo);
            this.pnlFiltros.Controls.Add(this.btnAtualizarEstoque);
            this.pnlFiltros.Controls.Add(this.btnPesquisarEstoque);
            this.pnlFiltros.Controls.Add(this.txtPesquisarEstoque);
            this.pnlFiltros.Controls.Add(this.lblPesquisarEstoque);
            this.pnlFiltros.Location = new System.Drawing.Point(20, 100);
            this.pnlFiltros.Name = "pnlFiltros";
            this.pnlFiltros.Size = new System.Drawing.Size(640, 72);
            this.pnlFiltros.TabIndex = 1;
            this.pnlFiltros.Tag = "cartao";
            // 
            // lblPesquisarEstoque
            // 
            this.lblPesquisarEstoque.AutoSize = true;
            this.lblPesquisarEstoque.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesquisarEstoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPesquisarEstoque.Location = new System.Drawing.Point(18, 10);
            this.lblPesquisarEstoque.Name = "lblPesquisarEstoque";
            this.lblPesquisarEstoque.TabIndex = 0;
            this.lblPesquisarEstoque.Text = "Pesquisar por nome ou categoria";
            // 
            // txtPesquisarEstoque
            // 
            this.txtPesquisarEstoque.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisarEstoque.Location = new System.Drawing.Point(18, 33);
            this.txtPesquisarEstoque.Name = "txtPesquisarEstoque";
            this.txtPesquisarEstoque.Size = new System.Drawing.Size(250, 25);
            this.txtPesquisarEstoque.TabIndex = 1;
            // 
            // btnPesquisarEstoque
            // 
            this.btnPesquisarEstoque.Location = new System.Drawing.Point(278, 28);
            this.btnPesquisarEstoque.Name = "btnPesquisarEstoque";
            this.btnPesquisarEstoque.Size = new System.Drawing.Size(124, 36);
            this.btnPesquisarEstoque.TabIndex = 2;
            this.btnPesquisarEstoque.Tag = "primario";
            this.btnPesquisarEstoque.Text = "Pesquisar";
            this.btnPesquisarEstoque.UseVisualStyleBackColor = false;
            this.btnPesquisarEstoque.Click += new System.EventHandler(this.btnPesquisarEstoque_Click);
            // 
            // btnAtualizarEstoque
            // 
            this.btnAtualizarEstoque.Location = new System.Drawing.Point(412, 28);
            this.btnAtualizarEstoque.Name = "btnAtualizarEstoque";
            this.btnAtualizarEstoque.Size = new System.Drawing.Size(36, 36);
            this.btnAtualizarEstoque.TabIndex = 3;
            this.btnAtualizarEstoque.Tag = "secundario";
            this.btnAtualizarEstoque.Text = "Atualizar";
            this.btnAtualizarEstoque.UseVisualStyleBackColor = false;
            this.btnAtualizarEstoque.Click += new System.EventHandler(this.btnAtualizarEstoque_Click);
            // 
            // btnEstoqueBaixo
            // 
            this.btnEstoqueBaixo.Location = new System.Drawing.Point(460, 28);
            this.btnEstoqueBaixo.Name = "btnEstoqueBaixo";
            this.btnEstoqueBaixo.Size = new System.Drawing.Size(162, 36);
            this.btnEstoqueBaixo.TabIndex = 4;
            this.btnEstoqueBaixo.Tag = "confirmar";
            this.btnEstoqueBaixo.Text = "Só Estoque Baixo";
            this.btnEstoqueBaixo.UseVisualStyleBackColor = false;
            this.btnEstoqueBaixo.Click += new System.EventHandler(this.btnEstoqueBaixo_Click);
            // 
            // lblExibindoEstoque
            // 
            this.lblExibindoEstoque.AutoSize = true;
            this.lblExibindoEstoque.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExibindoEstoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblExibindoEstoque.Location = new System.Drawing.Point(24, 184);
            this.lblExibindoEstoque.Name = "lblExibindoEstoque";
            this.lblExibindoEstoque.TabIndex = 2;
            this.lblExibindoEstoque.Text = "Exibindo: todos os produtos ativos";
            // 
            // lblLegendaEstoque
            // 
            this.lblLegendaEstoque.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.lblLegendaEstoque.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegendaEstoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(22)))), ((int)(((byte)(114)))));
            this.lblLegendaEstoque.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblLegendaEstoque.Location = new System.Drawing.Point(330, 184);
            this.lblLegendaEstoque.Name = "lblLegendaEstoque";
            this.lblLegendaEstoque.Size = new System.Drawing.Size(330, 20);
            this.lblLegendaEstoque.TabIndex = 3;
            this.lblLegendaEstoque.Text = "";
            // 
            // pnlProdutosEstoque
            // 
            this.pnlProdutosEstoque.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.pnlProdutosEstoque.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlProdutosEstoque.Controls.Add(this.dgvEstoque);
            this.pnlProdutosEstoque.Location = new System.Drawing.Point(20, 208);
            this.pnlProdutosEstoque.Name = "pnlProdutosEstoque";
            this.pnlProdutosEstoque.Padding = new System.Windows.Forms.Padding(10);
            this.pnlProdutosEstoque.Size = new System.Drawing.Size(640, 174);
            this.pnlProdutosEstoque.TabIndex = 4;
            this.pnlProdutosEstoque.Tag = "cartao";
            // 
            // dgvEstoque
            // 
            this.dgvEstoque.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEstoque.AllowUserToAddRows = false;
            this.dgvEstoque.AllowUserToDeleteRows = false;
            this.dgvEstoque.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEstoque.BackgroundColor = System.Drawing.Color.White;
            this.dgvEstoque.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvEstoque.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvEstoque.MultiSelect = false;
            this.dgvEstoque.ReadOnly = true;
            this.dgvEstoque.RowHeadersVisible = false;
            this.dgvEstoque.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEstoque.Location = new System.Drawing.Point(0, 0);
            this.dgvEstoque.Name = "dgvEstoque";
            this.dgvEstoque.Size = new System.Drawing.Size(100, 100);
            this.dgvEstoque.TabIndex = 0;
            this.dgvEstoque.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvEstoque_DataBindingComplete);
            this.dgvEstoque.SelectionChanged += new System.EventHandler(this.dgvEstoque_SelectionChanged);
            // 
            // pnlMovimentar
            // 
            this.pnlMovimentar.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.pnlMovimentar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlMovimentar.Controls.Add(this.btnRegistrarMovimentacao);
            this.pnlMovimentar.Controls.Add(this.cmbResponsavelEstoque);
            this.pnlMovimentar.Controls.Add(this.lblResponsavelEstoque);
            this.pnlMovimentar.Controls.Add(this.cmbMotivo);
            this.pnlMovimentar.Controls.Add(this.lblMotivo);
            this.pnlMovimentar.Controls.Add(this.nudQuantidadeMovimentacao);
            this.pnlMovimentar.Controls.Add(this.lblQuantidadeMovimentacao);
            this.pnlMovimentar.Controls.Add(this.cmbTipoMovimentacao);
            this.pnlMovimentar.Controls.Add(this.lblTipoMovimentacao);
            this.pnlMovimentar.Controls.Add(this.lblEstoqueAtual);
            this.pnlMovimentar.Controls.Add(this.lblProdutoSelecionado);
            this.pnlMovimentar.Controls.Add(this.lblSecaoMovimentar);
            this.pnlMovimentar.Location = new System.Drawing.Point(680, 100);
            this.pnlMovimentar.Name = "pnlMovimentar";
            this.pnlMovimentar.Size = new System.Drawing.Size(400, 282);
            this.pnlMovimentar.TabIndex = 5;
            this.pnlMovimentar.Tag = "cartao";
            // 
            // lblSecaoMovimentar
            // 
            this.lblSecaoMovimentar.AutoSize = true;
            this.lblSecaoMovimentar.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoMovimentar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoMovimentar.Location = new System.Drawing.Point(22, 16);
            this.lblSecaoMovimentar.Name = "lblSecaoMovimentar";
            this.lblSecaoMovimentar.TabIndex = 0;
            this.lblSecaoMovimentar.Text = "Movimentar estoque";
            // 
            // lblProdutoSelecionado
            // 
            this.lblProdutoSelecionado.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdutoSelecionado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblProdutoSelecionado.Location = new System.Drawing.Point(22, 44);
            this.lblProdutoSelecionado.Name = "lblProdutoSelecionado";
            this.lblProdutoSelecionado.Size = new System.Drawing.Size(356, 40);
            this.lblProdutoSelecionado.TabIndex = 1;
            this.lblProdutoSelecionado.Text = "Selecione um produto na lista ao lado";
            // 
            // lblEstoqueAtual
            // 
            this.lblEstoqueAtual.AutoSize = true;
            this.lblEstoqueAtual.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstoqueAtual.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblEstoqueAtual.Location = new System.Drawing.Point(22, 86);
            this.lblEstoqueAtual.Name = "lblEstoqueAtual";
            this.lblEstoqueAtual.TabIndex = 2;
            this.lblEstoqueAtual.Text = "Estoque atual: –";
            // 
            // lblTipoMovimentacao
            // 
            this.lblTipoMovimentacao.AutoSize = true;
            this.lblTipoMovimentacao.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoMovimentacao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblTipoMovimentacao.Location = new System.Drawing.Point(22, 114);
            this.lblTipoMovimentacao.Name = "lblTipoMovimentacao";
            this.lblTipoMovimentacao.TabIndex = 3;
            this.lblTipoMovimentacao.Text = "Tipo";
            // 
            // cmbTipoMovimentacao
            // 
            this.cmbTipoMovimentacao.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTipoMovimentacao.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoMovimentacao.FormattingEnabled = true;
            this.cmbTipoMovimentacao.Location = new System.Drawing.Point(22, 136);
            this.cmbTipoMovimentacao.Name = "cmbTipoMovimentacao";
            this.cmbTipoMovimentacao.Size = new System.Drawing.Size(168, 27);
            this.cmbTipoMovimentacao.TabIndex = 4;
            // 
            // lblQuantidadeMovimentacao
            // 
            this.lblQuantidadeMovimentacao.AutoSize = true;
            this.lblQuantidadeMovimentacao.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidadeMovimentacao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblQuantidadeMovimentacao.Location = new System.Drawing.Point(210, 114);
            this.lblQuantidadeMovimentacao.Name = "lblQuantidadeMovimentacao";
            this.lblQuantidadeMovimentacao.TabIndex = 5;
            this.lblQuantidadeMovimentacao.Text = "Quantidade";
            // 
            // nudQuantidadeMovimentacao
            // 
            this.nudQuantidadeMovimentacao.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudQuantidadeMovimentacao.Maximum = new decimal(new int[] { 100000, 0, 0, 0});
            this.nudQuantidadeMovimentacao.Location = new System.Drawing.Point(210, 136);
            this.nudQuantidadeMovimentacao.Name = "nudQuantidadeMovimentacao";
            this.nudQuantidadeMovimentacao.Size = new System.Drawing.Size(168, 26);
            this.nudQuantidadeMovimentacao.TabIndex = 6;
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMotivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblMotivo.Location = new System.Drawing.Point(22, 170);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.TabIndex = 7;
            this.lblMotivo.Text = "Motivo";
            // 
            // cmbMotivo
            // 
            this.cmbMotivo.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMotivo.FormattingEnabled = true;
            this.cmbMotivo.Location = new System.Drawing.Point(22, 192);
            this.cmbMotivo.Name = "cmbMotivo";
            this.cmbMotivo.Size = new System.Drawing.Size(168, 27);
            this.cmbMotivo.TabIndex = 8;
            // 
            // lblResponsavelEstoque
            // 
            this.lblResponsavelEstoque.AutoSize = true;
            this.lblResponsavelEstoque.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponsavelEstoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblResponsavelEstoque.Location = new System.Drawing.Point(210, 170);
            this.lblResponsavelEstoque.Name = "lblResponsavelEstoque";
            this.lblResponsavelEstoque.TabIndex = 9;
            this.lblResponsavelEstoque.Text = "Responsável (opcional)";
            // 
            // cmbResponsavelEstoque
            // 
            this.cmbResponsavelEstoque.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbResponsavelEstoque.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbResponsavelEstoque.FormattingEnabled = true;
            this.cmbResponsavelEstoque.Location = new System.Drawing.Point(210, 192);
            this.cmbResponsavelEstoque.Name = "cmbResponsavelEstoque";
            this.cmbResponsavelEstoque.Size = new System.Drawing.Size(168, 27);
            this.cmbResponsavelEstoque.TabIndex = 10;
            // 
            // btnRegistrarMovimentacao
            // 
            this.btnRegistrarMovimentacao.Location = new System.Drawing.Point(22, 230);
            this.btnRegistrarMovimentacao.Name = "btnRegistrarMovimentacao";
            this.btnRegistrarMovimentacao.Size = new System.Drawing.Size(356, 36);
            this.btnRegistrarMovimentacao.TabIndex = 11;
            this.btnRegistrarMovimentacao.Tag = "primario";
            this.btnRegistrarMovimentacao.Text = "Registrar movimentação";
            this.btnRegistrarMovimentacao.UseVisualStyleBackColor = false;
            this.btnRegistrarMovimentacao.Click += new System.EventHandler(this.btnRegistrarMovimentacao_Click);
            // 
            // lblSecaoHistorico
            // 
            this.lblSecaoHistorico.AutoSize = true;
            this.lblSecaoHistorico.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoHistorico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoHistorico.Location = new System.Drawing.Point(24, 396);
            this.lblSecaoHistorico.Name = "lblSecaoHistorico";
            this.lblSecaoHistorico.TabIndex = 6;
            this.lblSecaoHistorico.Text = "Histórico de movimentações";
            // 
            // lblHistoricoInfo
            // 
            this.lblHistoricoInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.lblHistoricoInfo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHistoricoInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblHistoricoInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblHistoricoInfo.Location = new System.Drawing.Point(520, 398);
            this.lblHistoricoInfo.Name = "lblHistoricoInfo";
            this.lblHistoricoInfo.Size = new System.Drawing.Size(560, 20);
            this.lblHistoricoInfo.TabIndex = 7;
            this.lblHistoricoInfo.Text = "";
            // 
            // pnlHistorico
            // 
            this.pnlHistorico.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlHistorico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlHistorico.Controls.Add(this.dgvHistorico);
            this.pnlHistorico.Location = new System.Drawing.Point(20, 424);
            this.pnlHistorico.Name = "pnlHistorico";
            this.pnlHistorico.Padding = new System.Windows.Forms.Padding(10);
            this.pnlHistorico.Size = new System.Drawing.Size(1060, 150);
            this.pnlHistorico.TabIndex = 8;
            this.pnlHistorico.Tag = "cartao";
            // 
            // dgvHistorico
            // 
            this.dgvHistorico.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHistorico.AllowUserToAddRows = false;
            this.dgvHistorico.AllowUserToDeleteRows = false;
            this.dgvHistorico.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHistorico.BackgroundColor = System.Drawing.Color.White;
            this.dgvHistorico.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvHistorico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvHistorico.MultiSelect = false;
            this.dgvHistorico.ReadOnly = true;
            this.dgvHistorico.RowHeadersVisible = false;
            this.dgvHistorico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHistorico.Location = new System.Drawing.Point(0, 0);
            this.dgvHistorico.Name = "dgvHistorico";
            this.dgvHistorico.Size = new System.Drawing.Size(100, 100);
            this.dgvHistorico.TabIndex = 0;
            this.dgvHistorico.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvHistorico_CellFormatting);
            // 
            // btnExportarEstoque
            // 
            this.btnExportarEstoque.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnExportarEstoque.Location = new System.Drawing.Point(840, 586);
            this.btnExportarEstoque.Name = "btnExportarEstoque";
            this.btnExportarEstoque.Size = new System.Drawing.Size(136, 36);
            this.btnExportarEstoque.TabIndex = 9;
            this.btnExportarEstoque.Tag = "confirmar";
            this.btnExportarEstoque.Text = "Exportar Excel";
            this.btnExportarEstoque.UseVisualStyleBackColor = false;
            this.btnExportarEstoque.Click += new System.EventHandler(this.btnExportarEstoque_Click);
            // 
            // btnVoltarEstoque
            // 
            this.btnVoltarEstoque.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarEstoque.Location = new System.Drawing.Point(986, 586);
            this.btnVoltarEstoque.Name = "btnVoltarEstoque";
            this.btnVoltarEstoque.Size = new System.Drawing.Size(94, 36);
            this.btnVoltarEstoque.TabIndex = 10;
            this.btnVoltarEstoque.Tag = "neutro";
            this.btnVoltarEstoque.Text = "Voltar";
            this.btnVoltarEstoque.UseVisualStyleBackColor = false;
            this.btnVoltarEstoque.Click += new System.EventHandler(this.btnVoltarEstoque_Click);
            // 
            // FrmEstoque
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1100, 638);
            this.Controls.Add(this.btnVoltarEstoque);
            this.Controls.Add(this.btnExportarEstoque);
            this.Controls.Add(this.pnlHistorico);
            this.Controls.Add(this.lblHistoricoInfo);
            this.Controls.Add(this.lblSecaoHistorico);
            this.Controls.Add(this.pnlMovimentar);
            this.Controls.Add(this.pnlProdutosEstoque);
            this.Controls.Add(this.lblLegendaEstoque);
            this.Controls.Add(this.lblExibindoEstoque);
            this.Controls.Add(this.pnlFiltros);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1116, 677);
            this.Name = "FrmEstoque";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Controle de Estoque";
            this.Load += new System.EventHandler(this.FrmEstoque_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstoque)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantidadeMovimentacao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistorico)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlFiltros.ResumeLayout(false);
            this.pnlFiltros.PerformLayout();
            this.pnlProdutosEstoque.ResumeLayout(false);
            this.pnlProdutosEstoque.PerformLayout();
            this.pnlMovimentar.ResumeLayout(false);
            this.pnlMovimentar.PerformLayout();
            this.pnlHistorico.ResumeLayout(false);
            this.pnlHistorico.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlFiltros;
        private System.Windows.Forms.Label lblPesquisarEstoque;
        private System.Windows.Forms.TextBox txtPesquisarEstoque;
        private System.Windows.Forms.Button btnPesquisarEstoque;
        private System.Windows.Forms.Button btnAtualizarEstoque;
        private System.Windows.Forms.Button btnEstoqueBaixo;
        private System.Windows.Forms.Label lblExibindoEstoque;
        private System.Windows.Forms.Label lblLegendaEstoque;
        private System.Windows.Forms.Panel pnlProdutosEstoque;
        private System.Windows.Forms.DataGridView dgvEstoque;
        private System.Windows.Forms.Panel pnlMovimentar;
        private System.Windows.Forms.Label lblSecaoMovimentar;
        private System.Windows.Forms.Label lblProdutoSelecionado;
        private System.Windows.Forms.Label lblEstoqueAtual;
        private System.Windows.Forms.Label lblTipoMovimentacao;
        private System.Windows.Forms.ComboBox cmbTipoMovimentacao;
        private System.Windows.Forms.Label lblQuantidadeMovimentacao;
        private System.Windows.Forms.NumericUpDown nudQuantidadeMovimentacao;
        private System.Windows.Forms.Label lblMotivo;
        private System.Windows.Forms.ComboBox cmbMotivo;
        private System.Windows.Forms.Label lblResponsavelEstoque;
        private System.Windows.Forms.ComboBox cmbResponsavelEstoque;
        private System.Windows.Forms.Button btnRegistrarMovimentacao;
        private System.Windows.Forms.Label lblSecaoHistorico;
        private System.Windows.Forms.Label lblHistoricoInfo;
        private System.Windows.Forms.Panel pnlHistorico;
        private System.Windows.Forms.DataGridView dgvHistorico;
        private System.Windows.Forms.Button btnExportarEstoque;
        private System.Windows.Forms.Button btnVoltarEstoque;
    }
}
