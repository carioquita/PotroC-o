﻿
using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;
using ClosedXML.Excel;

namespace PotroCao.Formularios
{
    public partial class FrmConsultarCliente : Form
    {
        public FrmConsultarCliente()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void FrmConsultarCliente_Load(object sender, EventArgs e)
        {
            CarregarClientes();
        }
  
        private void CarregarClientes()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT
                        codCli AS 'Código',
                        nome AS 'Nome',
                        cpf AS 'CPF',
                        rg AS 'RG',
                        telefone AS 'Telefone',
                        email AS 'E-mail',
                        datanasc AS 'Data de nascimento',
                        endereco AS 'Endereço',
                        cidade AS 'Cidade'
                        FROM cliente
                        WHERE status = 'Ativo'
                        ORDER BY nome";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvClientes.DataSource = tabela;
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show(
                    "Erro ao carregar clientes: " + erro.Message
                );
            }
        }


        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            txtPesquisar.Clear();
            CarregarClientes();

            CaixaMensagem.Show("Lista de clientes atualizada!");
        }


        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT
                        codCli AS 'Código',
                        nome AS 'Nome',
                        cpf AS 'CPF',
                        rg AS 'RG',
                        telefone AS 'Telefone',
                        email AS 'E-mail',
                        datanasc AS 'Data de nascimento',
                        endereco AS 'Endereço',
                        cidade AS 'Cidade'
                        FROM cliente
                        WHERE nome LIKE @pesquisa
                        AND status = 'Ativo'
                        ORDER BY nome";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    adaptador.SelectCommand.Parameters.AddWithValue(
                        "@pesquisa",
                        "%" + txtPesquisar.Text.Trim() + "%"
                    );

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvClientes.DataSource = tabela;
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show(
                    "Erro ao pesquisar clientes: " + erro.Message
                );
            }
        }

       
        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            if (dgvClientes.DataSource == null ||
                dgvClientes.Rows.Count == 0 ||
                (dgvClientes.AllowUserToAddRows &&
                 dgvClientes.Rows.Count == 1))
            {
                CaixaMensagem.Show("Não existem clientes para exportar!");
                return;
            }

            DataTable tabela = dgvClientes.DataSource as DataTable;

            if (tabela == null || tabela.Rows.Count == 0)
            {
                CaixaMensagem.Show(
                    "Não existem dados disponíveis para exportação!"
                );
                return;
            }

            using (SaveFileDialog salvar = new SaveFileDialog())
            {
                salvar.Filter = "Arquivo Excel (*.xlsx)|*.xlsx";
                salvar.Title = "Exportar clientes";
                salvar.FileName = "Clientes_PotroCao.xlsx";
                salvar.DefaultExt = "xlsx";
                salvar.AddExtension = true;

                if (salvar.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (XLWorkbook planilha = new XLWorkbook())
                        {
                            var aba = planilha.Worksheets.Add("Clientes");

                            aba.Cell(1, 1).InsertTable(tabela, false);

                            aba.Row(1).Style.Font.Bold = true;

                            aba.Row(1).Style.Fill.BackgroundColor =
                                XLColor.FromHtml("#6320B5");

                            aba.Row(1).Style.Font.FontColor =
                                XLColor.White;

                            aba.Columns().AdjustToContents();

                            aba.RangeUsed().SetAutoFilter();

                            aba.SheetView.FreezeRows(1);

                            planilha.SaveAs(salvar.FileName);
                        }

                        CaixaMensagem.Show(
                            "Planilha exportada com sucesso!",
                            "PotroCão",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                    }
                    catch (Exception erro)
                    {
                        CaixaMensagem.Show(
                            "Erro ao exportar a planilha: " + erro.Message,
                            "PotroCão",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
            }
        }

        
        private void dgvClientes_CellContentClick(
            object sender,
            DataGridViewCellEventArgs e)
        {

        }

        
        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um cliente para editar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvClientes.CurrentRow.Cells["Código"].Value
            );

            FrmCadastrarCliente formulario =
                new FrmCadastrarCliente();

            formulario.CarregarCliente(codigo);

            formulario.ShowDialog();

            CarregarClientes();
        }

        // INATIVAR CLIENTE
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um cliente para inativar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvClientes.CurrentRow.Cells["Código"].Value
            );

            DialogResult resposta = CaixaMensagem.Show(
                "Tem certeza que deseja inativar este cliente?",
                "Confirmar inativação",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (resposta == DialogResult.Yes)
            {
                try
                {
                    using (MySqlConnection conexao = Conexao.Conectar())
                    {
                        conexao.Open();

                        string sql = @"UPDATE cliente
                                       SET status = 'Inativo'
                                       WHERE codCli = @codigo";

                        using (MySqlCommand cmd =
                            new MySqlCommand(sql, conexao))
                        {
                            cmd.Parameters.AddWithValue(
                                "@codigo", codigo
                            );

                            cmd.ExecuteNonQuery();
                        }
                    }

                    CaixaMensagem.Show(
                        "Cliente inativado com sucesso!",
                        "PotroCão",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );

                    CarregarClientes();
                }
                catch (Exception erro)
                {
                    CaixaMensagem.Show(
                        "Erro ao inativar cliente: " + erro.Message
                    );
                }
            }
        }

        private void btnVerInativos_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT
                codCli AS 'Código',
                nome AS 'Nome',
                cpf AS 'CPF',
                rg AS 'RG',
                telefone AS 'Telefone',
                email AS 'E-mail',
                datanasc AS 'Data de nascimento',
                endereco AS 'Endereço',
                cidade AS 'Cidade'
                FROM cliente
                WHERE status = 'Inativo'
                ORDER BY nome";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvClientes.DataSource = tabela;

                    CaixaMensagem.Show("Lista de clientes inativos carregada!");
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show(
                    "Erro ao carregar clientes inativos: " + erro.Message
                );
            }
        }


        private void btnReativarCliente_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um cliente para reativar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvClientes.CurrentRow.Cells["Código"].Value
            );

            DialogResult resposta = CaixaMensagem.Show(
                "Deseja reativar este cliente?",
                "Confirmar reativação",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resposta == DialogResult.Yes)
            {
                try
                {
                    using (MySqlConnection conexao = Conexao.Conectar())
                    {
                        conexao.Open();

                        string sql = @"UPDATE cliente
                               SET status = 'Ativo'
                               WHERE codCli = @codigo";

                        using (MySqlCommand cmd =
                            new MySqlCommand(sql, conexao))
                        {
                            cmd.Parameters.AddWithValue("@codigo", codigo);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    CaixaMensagem.Show(
                        "Cliente reativado com sucesso!",
                        "PotroCão",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );

                   
                    btnVerInativos_Click(sender, e);
                }
                catch (Exception erro)
                {
                    CaixaMensagem.Show(
                        "Erro ao reativar cliente: " + erro.Message
                    );
                }
            }
        }

        // Abre o cadastro de um novo cliente a partir da consulta
        private void btnNovoCliente_Click(object sender, EventArgs e)
        {
            using (FrmCadastrarCliente tela = new FrmCadastrarCliente())
            {
                tela.ShowDialog();
            }

            CarregarClientes();
        }
    }
}
