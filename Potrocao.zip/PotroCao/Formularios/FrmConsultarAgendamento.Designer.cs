﻿namespace PotroCao.Formularios
{
    partial class FrmConsultarAgendamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlFiltros = new System.Windows.Forms.Panel();
            this.lblPesquisarAgendamento = new System.Windows.Forms.Label();
            this.txtPesquisarAgendamento = new System.Windows.Forms.TextBox();
            this.btnPesquisarAgendamento = new System.Windows.Forms.Button();
            this.btnAtualizarAgendamento = new System.Windows.Forms.Button();
            this.btnEditarAgendamento = new System.Windows.Forms.Button();
            this.btnNovoAgendamento = new System.Windows.Forms.Button();
            this.pnlGrade = new System.Windows.Forms.Panel();
            this.dgvAgendamentos = new System.Windows.Forms.DataGridView();
            this.btnVerTodos = new System.Windows.Forms.Button();
            this.btnVerCancelados = new System.Windows.Forms.Button();
            this.btnVoltarAgendamento = new System.Windows.Forms.Button();
            this.btnCancelarAgendamento = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlFiltros.SuspendLayout();
            this.pnlGrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgendamentos)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTitulo.Location = new System.Drawing.Point(22, 14);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Agendamentos";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Acompanhe, edite ou cancele os atendimentos marcados.";
            // 
            // pnlFiltros
            // 
            this.pnlFiltros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.pnlFiltros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlFiltros.Controls.Add(this.btnNovoAgendamento);
            this.pnlFiltros.Controls.Add(this.btnEditarAgendamento);
            this.pnlFiltros.Controls.Add(this.btnAtualizarAgendamento);
            this.pnlFiltros.Controls.Add(this.btnPesquisarAgendamento);
            this.pnlFiltros.Controls.Add(this.txtPesquisarAgendamento);
            this.pnlFiltros.Controls.Add(this.lblPesquisarAgendamento);
            this.pnlFiltros.Location = new System.Drawing.Point(20, 100);
            this.pnlFiltros.Name = "pnlFiltros";
            this.pnlFiltros.Size = new System.Drawing.Size(1000, 72);
            this.pnlFiltros.TabIndex = 1;
            this.pnlFiltros.Tag = "cartao";
            // 
            // lblPesquisarAgendamento
            // 
            this.lblPesquisarAgendamento.AutoSize = true;
            this.lblPesquisarAgendamento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesquisarAgendamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPesquisarAgendamento.Location = new System.Drawing.Point(18, 10);
            this.lblPesquisarAgendamento.Name = "lblPesquisarAgendamento";
            this.lblPesquisarAgendamento.TabIndex = 0;
            this.lblPesquisarAgendamento.Text = "Pesquisar por cliente ou pet";
            // 
            // txtPesquisarAgendamento
            // 
            this.txtPesquisarAgendamento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisarAgendamento.Location = new System.Drawing.Point(18, 33);
            this.txtPesquisarAgendamento.Name = "txtPesquisarAgendamento";
            this.txtPesquisarAgendamento.Size = new System.Drawing.Size(300, 25);
            this.txtPesquisarAgendamento.TabIndex = 1;
            // 
            // btnPesquisarAgendamento
            // 
            this.btnPesquisarAgendamento.Location = new System.Drawing.Point(328, 28);
            this.btnPesquisarAgendamento.Name = "btnPesquisarAgendamento";
            this.btnPesquisarAgendamento.Size = new System.Drawing.Size(124, 36);
            this.btnPesquisarAgendamento.TabIndex = 2;
            this.btnPesquisarAgendamento.Tag = "primario";
            this.btnPesquisarAgendamento.Text = "Pesquisar";
            this.btnPesquisarAgendamento.UseVisualStyleBackColor = false;
            this.btnPesquisarAgendamento.Click += new System.EventHandler(this.btnPesquisarAgendamento_Click);
            // 
            // btnAtualizarAgendamento
            // 
            this.btnAtualizarAgendamento.Location = new System.Drawing.Point(462, 28);
            this.btnAtualizarAgendamento.Name = "btnAtualizarAgendamento";
            this.btnAtualizarAgendamento.Size = new System.Drawing.Size(36, 36);
            this.btnAtualizarAgendamento.TabIndex = 3;
            this.btnAtualizarAgendamento.Tag = "secundario";
            this.btnAtualizarAgendamento.Text = "Atualizar";
            this.btnAtualizarAgendamento.UseVisualStyleBackColor = false;
            this.btnAtualizarAgendamento.Click += new System.EventHandler(this.btnAtualizarAgendamento_Click);
            // 
            // btnEditarAgendamento
            // 
            this.btnEditarAgendamento.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnEditarAgendamento.Location = new System.Drawing.Point(878, 18);
            this.btnEditarAgendamento.Name = "btnEditarAgendamento";
            this.btnEditarAgendamento.Size = new System.Drawing.Size(104, 36);
            this.btnEditarAgendamento.TabIndex = 4;
            this.btnEditarAgendamento.Tag = "primario";
            this.btnEditarAgendamento.Text = "Editar";
            this.btnEditarAgendamento.UseVisualStyleBackColor = false;
            this.btnEditarAgendamento.Click += new System.EventHandler(this.btnEditarAgendamento_Click);
            // 
            // btnNovoAgendamento
            // 
            this.btnNovoAgendamento.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnNovoAgendamento.Location = new System.Drawing.Point(697, 18);
            this.btnNovoAgendamento.Name = "btnNovoAgendamento";
            this.btnNovoAgendamento.Size = new System.Drawing.Size(171, 36);
            this.btnNovoAgendamento.TabIndex = 5;
            this.btnNovoAgendamento.Tag = "especial";
            this.btnNovoAgendamento.Text = "Novo Agendamento";
            this.btnNovoAgendamento.UseVisualStyleBackColor = false;
            this.btnNovoAgendamento.Click += new System.EventHandler(this.btnNovoAgendamento_Click);
            // 
            // pnlGrade
            // 
            this.pnlGrade.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlGrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlGrade.Controls.Add(this.dgvAgendamentos);
            this.pnlGrade.Location = new System.Drawing.Point(20, 186);
            this.pnlGrade.Name = "pnlGrade";
            this.pnlGrade.Padding = new System.Windows.Forms.Padding(12);
            this.pnlGrade.Size = new System.Drawing.Size(1000, 354);
            this.pnlGrade.TabIndex = 2;
            this.pnlGrade.Tag = "cartao";
            // 
            // dgvAgendamentos
            // 
            this.dgvAgendamentos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAgendamentos.AllowUserToAddRows = false;
            this.dgvAgendamentos.AllowUserToDeleteRows = false;
            this.dgvAgendamentos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAgendamentos.BackgroundColor = System.Drawing.Color.White;
            this.dgvAgendamentos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvAgendamentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvAgendamentos.MultiSelect = false;
            this.dgvAgendamentos.ReadOnly = true;
            this.dgvAgendamentos.RowHeadersVisible = false;
            this.dgvAgendamentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAgendamentos.Location = new System.Drawing.Point(0, 0);
            this.dgvAgendamentos.Name = "dgvAgendamentos";
            this.dgvAgendamentos.Size = new System.Drawing.Size(100, 100);
            this.dgvAgendamentos.TabIndex = 0;
            // 
            // btnVerTodos
            // 
            this.btnVerTodos.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerTodos.Location = new System.Drawing.Point(20, 560);
            this.btnVerTodos.Name = "btnVerTodos";
            this.btnVerTodos.Size = new System.Drawing.Size(120, 36);
            this.btnVerTodos.TabIndex = 3;
            this.btnVerTodos.Tag = "secundario";
            this.btnVerTodos.Text = "Ver Todos";
            this.btnVerTodos.UseVisualStyleBackColor = false;
            this.btnVerTodos.Click += new System.EventHandler(this.btnVerTodos_Click_1);
            // 
            // btnVerCancelados
            // 
            this.btnVerCancelados.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerCancelados.Location = new System.Drawing.Point(150, 560);
            this.btnVerCancelados.Name = "btnVerCancelados";
            this.btnVerCancelados.Size = new System.Drawing.Size(156, 36);
            this.btnVerCancelados.TabIndex = 4;
            this.btnVerCancelados.Tag = "secundario";
            this.btnVerCancelados.Text = "Ver Cancelados";
            this.btnVerCancelados.UseVisualStyleBackColor = false;
            this.btnVerCancelados.Click += new System.EventHandler(this.btnVerCancelados_Click);
            // 
            // btnVoltarAgendamento
            // 
            this.btnVoltarAgendamento.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarAgendamento.Location = new System.Drawing.Point(916, 560);
            this.btnVoltarAgendamento.Name = "btnVoltarAgendamento";
            this.btnVoltarAgendamento.Size = new System.Drawing.Size(104, 36);
            this.btnVoltarAgendamento.TabIndex = 5;
            this.btnVoltarAgendamento.Tag = "neutro";
            this.btnVoltarAgendamento.Text = "Voltar";
            this.btnVoltarAgendamento.UseVisualStyleBackColor = false;
            this.btnVoltarAgendamento.Click += new System.EventHandler(this.btnVoltarAgendamento_Click_1);
            // 
            // btnCancelarAgendamento
            // 
            this.btnCancelarAgendamento.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnCancelarAgendamento.Location = new System.Drawing.Point(706, 560);
            this.btnCancelarAgendamento.Name = "btnCancelarAgendamento";
            this.btnCancelarAgendamento.Size = new System.Drawing.Size(200, 36);
            this.btnCancelarAgendamento.TabIndex = 6;
            this.btnCancelarAgendamento.Tag = "alerta";
            this.btnCancelarAgendamento.Text = "Cancelar Agendamento";
            this.btnCancelarAgendamento.UseVisualStyleBackColor = false;
            this.btnCancelarAgendamento.Click += new System.EventHandler(this.btnCancelarAgendamento_Click);
            // 
            // FrmConsultarAgendamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1040, 620);
            this.Controls.Add(this.btnCancelarAgendamento);
            this.Controls.Add(this.btnVoltarAgendamento);
            this.Controls.Add(this.btnVerCancelados);
            this.Controls.Add(this.btnVerTodos);
            this.Controls.Add(this.pnlGrade);
            this.Controls.Add(this.pnlFiltros);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1056, 659);
            this.Name = "FrmConsultarAgendamento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Consulta de Agendamentos";
            this.Load += new System.EventHandler(this.FrmConsultarAgendamento_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgendamentos)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlFiltros.ResumeLayout(false);
            this.pnlFiltros.PerformLayout();
            this.pnlGrade.ResumeLayout(false);
            this.pnlGrade.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlFiltros;
        private System.Windows.Forms.Label lblPesquisarAgendamento;
        private System.Windows.Forms.TextBox txtPesquisarAgendamento;
        private System.Windows.Forms.Button btnPesquisarAgendamento;
        private System.Windows.Forms.Button btnAtualizarAgendamento;
        private System.Windows.Forms.Button btnEditarAgendamento;
        private System.Windows.Forms.Button btnNovoAgendamento;
        private System.Windows.Forms.Panel pnlGrade;
        private System.Windows.Forms.DataGridView dgvAgendamentos;
        private System.Windows.Forms.Button btnVerTodos;
        private System.Windows.Forms.Button btnVerCancelados;
        private System.Windows.Forms.Button btnVoltarAgendamento;
        private System.Windows.Forms.Button btnCancelarAgendamento;
    }
}
