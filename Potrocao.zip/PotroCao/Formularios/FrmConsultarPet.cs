﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;
using ClosedXML.Excel;
using System.IO;

namespace PotroCao.Formularios
{
    public partial class FrmConsultarPet : Form
    {
        
        public FrmConsultarPet()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void CarregarPets()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT
                                   pet.codpet AS Código,
                                   pet.nome AS Pet,
                                   pet.especie AS Espécie,
                                   pet.raca AS Raça,
                                   cliente.nome AS Dono
                                   FROM pet
                                    INNER JOIN cliente
                                    ON pet.codCli = cliente.codCli
                                    WHERE pet.status = 'Ativo'
                                    ORDER BY pet.nome";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvPets.DataSource = tabela;
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao carregar pets: " + erro.Message);
            }
        }

        private void FrmConsultarPet_Load(object sender, EventArgs e)
        {
            CarregarPets();
        }

        private void dgvPets_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnPesquisarPet_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT
                           pet.codpet AS Código,
                           pet.nome AS Pet,
                           pet.especie AS Espécie,
                           pet.raca AS Raça,
                           cliente.nome AS Dono
                           FROM pet
                           INNER JOIN cliente
                           ON pet.codCli = cliente.codCli
                          WHERE pet.nome LIKE @nome
                            AND pet.status = 'Ativo'
                            ORDER BY pet.nome";

                    MySqlCommand comando = new MySqlCommand(sql, conexao);

                    comando.Parameters.AddWithValue(
                        "@nome", "%" + txtPesquisarPet.Text.Trim() + "%");

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvPets.DataSource = tabela;
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao pesquisar pet: " + erro.Message);
            }
        }

        private void btnAtualizarPet_Click(object sender, EventArgs e)
        {
            txtPesquisarPet.Clear();
            CarregarPets();
        }



        private void btnExcluirPet_Click(object sender, EventArgs e)
        {
            if (dgvPets.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um pet para inativar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvPets.CurrentRow.Cells["Código"].Value);

            string nomePet = dgvPets.CurrentRow.Cells["Pet"].Value.ToString();

            DialogResult resposta = CaixaMensagem.Show(
                "Deseja realmente inativar o pet " + nomePet + "?",
                "Confirmar inativação",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resposta == DialogResult.Yes)
            {
                try
                {
                    using (MySqlConnection conexao = Conexao.Conectar())
                    {
                        conexao.Open();

                        string sql = "UPDATE pet SET status = 'Inativo' WHERE codpet = @codigo";

                        MySqlCommand comando = new MySqlCommand(sql, conexao);
                        comando.Parameters.AddWithValue("@codigo", codigo);

                        comando.ExecuteNonQuery();

                        CaixaMensagem.Show("Pet inativado com sucesso!");

                        CarregarPets();
                    }
                }
                catch (Exception erro)
                {
                    CaixaMensagem.Show("Erro ao inativar pet: " + erro.Message);
                }
            }
        }


        private void btnVerInativos_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT
                           pet.codpet AS Código,
                           pet.nome AS Pet,
                           pet.especie AS Espécie,
                           pet.raca AS Raça,
                           cliente.nome AS Dono
                           FROM pet
                           INNER JOIN cliente
                           ON pet.codCli = cliente.codCli
                           WHERE pet.status = 'Inativo'
                           ORDER BY pet.nome";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvPets.DataSource = tabela;
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao carregar pets inativos: " + erro.Message);
            }
        }


        private void btnReativarPet_Click(object sender, EventArgs e)
        {
            if (dgvPets.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um pet para reativar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvPets.CurrentRow.Cells["Código"].Value);

            string nomePet = dgvPets.CurrentRow.Cells["Pet"].Value.ToString();

            DialogResult resposta = CaixaMensagem.Show(
                "Deseja reativar o pet " + nomePet + "?",
                "Confirmar reativação",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resposta == DialogResult.Yes)
            {
                try
                {
                    using (MySqlConnection conexao = Conexao.Conectar())
                    {
                        conexao.Open();

                        string sql = "UPDATE pet SET status = 'Ativo' WHERE codpet = @codigo";

                        MySqlCommand comando = new MySqlCommand(sql, conexao);
                        comando.Parameters.AddWithValue("@codigo", codigo);

                        comando.ExecuteNonQuery();

                        CaixaMensagem.Show("Pet reativado com sucesso!");

                        CarregarPets();
                    }
                }
                catch (Exception erro)
                {
                    CaixaMensagem.Show("Erro ao reativar pet: " + erro.Message);
                }
            }
        }


        private void btnEditarPet_Click(object sender, EventArgs e)
        {
            if (dgvPets.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um pet para editar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvPets.CurrentRow.Cells["Código"].Value);

            FrmCadastrarPet telaCadastro = new FrmCadastrarPet();

            telaCadastro.CarregarPet(codigo);

            telaCadastro.ShowDialog();

            CarregarPets();
        }


        private void btnExportarPet_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPets.Rows.Count == 0)
                {
                    CaixaMensagem.Show("Não existem pets para exportar!");
                    return;
                }

                SaveFileDialog salvar = new SaveFileDialog();

                salvar.Filter = "Arquivo Excel (*.xlsx)|*.xlsx";
                salvar.Title = "Exportar Pets";
                salvar.FileName = "Relatorio_Pets.xlsx";

                if (salvar.ShowDialog() == DialogResult.OK)
                {
                    using (XLWorkbook planilha = new XLWorkbook())
                    {
                        DataTable tabela = new DataTable();

                        foreach (DataGridViewColumn coluna in dgvPets.Columns)
                        {
                            tabela.Columns.Add(coluna.HeaderText);
                        }

                        foreach (DataGridViewRow linha in dgvPets.Rows)
                        {
                            if (!linha.IsNewRow)
                            {
                                DataRow novaLinha = tabela.NewRow();

                                for (int i = 0; i < dgvPets.Columns.Count; i++)
                                {
                                    novaLinha[i] = linha.Cells[i].Value ?? "";
                                }

                                tabela.Rows.Add(novaLinha);
                            }
                        }

                        var aba = planilha.Worksheets.Add(tabela, "Pets");

                        aba.Columns().AdjustToContents();

                        aba.Row(1).Style.Font.Bold = true;

                        planilha.SaveAs(salvar.FileName);
                    }

                    CaixaMensagem.Show("Planilha exportada com sucesso!");
                }
            }
            catch (Exception erro)
            {
                CaixaMensagem.Show("Erro ao exportar pets: " + erro.Message);
            }
        }

        // Abre o cadastro de um novo pet a partir da consulta
        private void btnNovoPet_Click(object sender, EventArgs e)
        {
            using (FrmCadastrarPet tela = new FrmCadastrarPet())
            {
                tela.ShowDialog();
            }

            CarregarPets();
        }

        private void btnVoltarConsultaPet_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

