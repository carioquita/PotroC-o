﻿
using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmConsultarAgendamento : Form
    {
        public FrmConsultarAgendamento()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        // CARREGAR AGENDAMENTOS ATIVOS
        private void FrmConsultarAgendamento_Load(object sender, EventArgs e)
        {
            CarregarAgendamentos();
        }

        private void CarregarAgendamentos(string pesquisa = "")
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            ag.codAgendamento AS 'Código',
                            cli.nome AS 'Cliente',
                            p.nome AS 'Pet',
                            fun.nome AS 'Funcionário',
                            ag.data AS 'Data',
                            ag.horario AS 'Horário',
                            ag.status AS 'Status',
                            ag.observacoes AS 'Observações'
                        FROM agendamento ag
                        INNER JOIN cliente cli
                            ON ag.codCli = cli.codCli
                        INNER JOIN pet p
                            ON ag.codpet = p.codpet
                        LEFT JOIN funcionario fun
                            ON ag.codFun = fun.codFun
                        WHERE
                            (cli.nome LIKE @pesquisa
                            OR p.nome LIKE @pesquisa)
                            AND ag.status <> 'Cancelado'
                        ORDER BY ag.data, ag.horario";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    adaptador.SelectCommand.Parameters.AddWithValue(
                        "@pesquisa", "%" + pesquisa + "%"
                    );

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvAgendamentos.DataSource = tabela;
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show(
                    "Erro ao carregar agendamentos: " + ex.Message
                );
            }
        }

        // PESQUISAR
        private void btnPesquisarAgendamento_Click(object sender, EventArgs e)
        {
            CarregarAgendamentos(txtPesquisarAgendamento.Text.Trim());
        }

        // ATUALIZAR
        private void btnAtualizarAgendamento_Click(object sender, EventArgs e)
        {
            txtPesquisarAgendamento.Clear();
            CarregarAgendamentos();

            CaixaMensagem.Show("Lista de agendamentos atualizada!");
        }

        // EDITAR
        private void btnEditarAgendamento_Click(object sender, EventArgs e)
        {
            if (dgvAgendamentos.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um agendamento para editar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvAgendamentos.CurrentRow.Cells["Código"].Value
            );

            FrmCadastrarAgendamento tela =
                new FrmCadastrarAgendamento();

            tela.CarregarAgendamento(codigo);

            tela.ShowDialog();

            CarregarAgendamentos();
        }

        // CANCELAR
        private void btnCancelarAgendamento_Click(object sender, EventArgs e)
        {
            if (dgvAgendamentos.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um agendamento para cancelar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvAgendamentos.CurrentRow.Cells["Código"].Value
            );

            DialogResult resposta = CaixaMensagem.Show(
                "Deseja realmente cancelar este agendamento?",
                "Confirmar cancelamento",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resposta == DialogResult.No)
                return;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                        UPDATE agendamento
                        SET status = 'Cancelado'
                        WHERE codAgendamento = @codigo";

                    MySqlCommand comando =
                        new MySqlCommand(sql, conexao);

                    comando.Parameters.AddWithValue("@codigo", codigo);

                    comando.ExecuteNonQuery();

                    CaixaMensagem.Show("Agendamento cancelado com sucesso!");

                    CarregarAgendamentos(
                        txtPesquisarAgendamento.Text.Trim()
                    );
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show(
                    "Erro ao cancelar agendamento: " + ex.Message
                );
            }
        }

        // VISUALIZAR CANCELADOS
        private void btnVerCancelados_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            ag.codAgendamento AS 'Código',
                            cli.nome AS 'Cliente',
                            p.nome AS 'Pet',
                            fun.nome AS 'Funcionário',
                            ag.data AS 'Data',
                            ag.horario AS 'Horário',
                            ag.status AS 'Status',
                            ag.observacoes AS 'Observações'
                        FROM agendamento ag
                        INNER JOIN cliente cli
                            ON ag.codCli = cli.codCli
                        INNER JOIN pet p
                            ON ag.codpet = p.codpet
                        LEFT JOIN funcionario fun
                            ON ag.codFun = fun.codFun
                        WHERE ag.status = 'Cancelado'
                        ORDER BY ag.data, ag.horario";

                    MySqlDataAdapter adaptador =
                        new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvAgendamentos.DataSource = tabela;

                    txtPesquisarAgendamento.Clear();
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show(
                    "Erro ao carregar agendamentos cancelados: " + ex.Message
                );
            }
        }

       
       

        private void btnVerTodos_Click_1(object sender, EventArgs e)
        {
            txtPesquisarAgendamento.Clear();
            CarregarAgendamentos();
        }


        private void btnVoltarAgendamento_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        // Abre um novo agendamento a partir da consulta
        private void btnNovoAgendamento_Click(object sender, EventArgs e)
        {
            using (FrmCadastrarAgendamento tela = new FrmCadastrarAgendamento())
            {
                tela.ShowDialog();
            }

            CarregarAgendamentos(txtPesquisarAgendamento.Text.Trim());
        }
    }
}
