﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmConsultarProduto : Form
    {
        // Qual lista está sendo exibida: "ativos", "inativos" ou "todos"
        private string filtroAtual = "ativos";

        public FrmConsultarProduto()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void FrmConsultarProduto_Load(object sender, EventArgs e)
        {
            lblLegendaEstoque.Text = "Linhas em vermelho = estoque baixo (" +
                Utilitarios.ESTOQUE_BAIXO + " unidades ou menos)";

            CarregarProdutos();
        }

        private void CarregarProdutos()
        {
            string condicao;

            if (filtroAtual == "inativos")
            {
                condicao = "p.ativo = 0";
                lblExibindoProduto.Text = "Exibindo: produtos inativos";
            }
            else if (filtroAtual == "todos")
            {
                condicao = "1 = 1";
                lblExibindoProduto.Text = "Exibindo: todos os produtos";
            }
            else
            {
                condicao = "p.ativo = 1";
                lblExibindoProduto.Text = "Exibindo: produtos ativos";
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            p.codProduto AS 'Código',
                            p.nome AS 'Produto',
                            c.nome AS 'Categoria',
                            p.preco AS 'Preço (R$)',
                            p.quantidadeEstoque AS 'Estoque',
                            p.descricao AS 'Descrição',
                            CASE WHEN p.ativo = 1 THEN 'Ativo' ELSE 'Inativo' END AS 'Situação'
                        FROM produto p
                        INNER JOIN categoria_produto c ON c.codCategoria = p.codCategoria
                        WHERE " + condicao + @"
                        AND (p.nome LIKE @pesquisa OR c.nome LIKE @pesquisa)
                        ORDER BY p.nome";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@pesquisa",
                            "%" + txtPesquisarProduto.Text.Trim() + "%");

                        using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                        {
                            DataTable tabela = new DataTable();
                            adaptador.Fill(tabela);
                            dgvProdutos.DataSource = tabela;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar produtos: " + ex.Message);
            }
        }

        private void dgvProdutos_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (dgvProdutos.Columns.Contains("Código"))
                dgvProdutos.Columns["Código"].FillWeight = 40;

            if (dgvProdutos.Columns.Contains("Produto"))
                dgvProdutos.Columns["Produto"].FillWeight = 160;

            if (dgvProdutos.Columns.Contains("Preço (R$)"))
            {
                dgvProdutos.Columns["Preço (R$)"].DefaultCellStyle.Format = "N2";
                dgvProdutos.Columns["Preço (R$)"].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
                dgvProdutos.Columns["Preço (R$)"].FillWeight = 60;
            }

            if (dgvProdutos.Columns.Contains("Estoque"))
            {
                dgvProdutos.Columns["Estoque"].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleCenter;
                dgvProdutos.Columns["Estoque"].FillWeight = 50;
            }

            if (dgvProdutos.Columns.Contains("Descrição"))
                dgvProdutos.Columns["Descrição"].FillWeight = 180;

            if (dgvProdutos.Columns.Contains("Situação"))
                dgvProdutos.Columns["Situação"].FillWeight = 50;

            // Destaca em vermelho os produtos ativos com estoque baixo
            foreach (DataGridViewRow linha in dgvProdutos.Rows)
            {
                int estoque = Convert.ToInt32(linha.Cells["Estoque"].Value);
                string situacao = Convert.ToString(linha.Cells["Situação"].Value);

                if (situacao == "Ativo" && estoque <= Utilitarios.ESTOQUE_BAIXO)
                {
                    linha.DefaultCellStyle.ForeColor = Color.Firebrick;
                    linha.DefaultCellStyle.BackColor = Color.FromArgb(255, 235, 235);
                }
            }

            Utilitarios.DestacarInativos(dgvProdutos, "Situação");
        }

        // ---------- PESQUISA E FILTROS ----------

        private void btnPesquisarProduto_Click(object sender, EventArgs e)
        {
            CarregarProdutos();
        }

        private void btnAtualizarProduto_Click(object sender, EventArgs e)
        {
            txtPesquisarProduto.Clear();
            filtroAtual = "ativos";
            CarregarProdutos();
        }

        private void btnVerAtivosProduto_Click(object sender, EventArgs e)
        {
            filtroAtual = "ativos";
            CarregarProdutos();
        }

        private void btnVerInativosProduto_Click(object sender, EventArgs e)
        {
            filtroAtual = "inativos";
            CarregarProdutos();
        }

        private void btnVerTodosProdutos_Click(object sender, EventArgs e)
        {
            filtroAtual = "todos";
            CarregarProdutos();
        }

        // ---------- NOVO / EDITAR / CATEGORIAS ----------

        private void btnNovoProduto_Click(object sender, EventArgs e)
        {
            using (FrmCadastrarProduto tela = new FrmCadastrarProduto())
            {
                tela.ShowDialog();
            }

            CarregarProdutos();
        }

        private void btnEditarProduto_Click(object sender, EventArgs e)
        {
            EditarSelecionado();
        }

        private void dgvProdutos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                EditarSelecionado();
        }

        private void EditarSelecionado()
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvProdutos);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione um produto para editar!");
                return;
            }

            using (FrmCadastrarProduto tela = new FrmCadastrarProduto())
            {
                tela.CarregarProduto(codigo);
                tela.ShowDialog();
            }

            CarregarProdutos();
        }

        private void btnCategorias_Click(object sender, EventArgs e)
        {
            using (FrmConsultarCategoria tela = new FrmConsultarCategoria())
            {
                tela.ShowDialog();
            }

            CarregarProdutos();
        }

        // Abre o controle de estoque já com o produto selecionado
        private void btnEstoqueProduto_Click(object sender, EventArgs e)
        {
            using (FrmEstoque tela = new FrmEstoque())
            {
                int codigo = Utilitarios.CodigoSelecionado(dgvProdutos);

                if (codigo != 0)
                    tela.SelecionarProduto(codigo);

                tela.ShowDialog();
            }

            CarregarProdutos();
        }

        // ---------- INATIVAR / REATIVAR ----------

        private void btnInativarProduto_Click(object sender, EventArgs e)
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvProdutos);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione um produto para inativar!");
                return;
            }

            if (Utilitarios.TextoSelecionado(dgvProdutos, "Situação") == "Inativo")
            {
                Utilitarios.Aviso("Esse produto já está inativo.");
                return;
            }

            if (!Utilitarios.Confirmar("Deseja realmente inativar este produto?\n\n" +
                    "Ele não será excluído, apenas deixará de aparecer na lista de ativos.",
                    "Confirmar inativação"))
                return;

            AlterarSituacao(codigo, 0);
        }

        private void btnReativarProduto_Click(object sender, EventArgs e)
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvProdutos);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione um produto para reativar!\n\n" +
                    "Dica: clique em \"Ver Inativos\" para listar os produtos inativos.");
                return;
            }

            if (Utilitarios.TextoSelecionado(dgvProdutos, "Situação") == "Ativo")
            {
                Utilitarios.Aviso("Esse produto já está ativo.");
                return;
            }

            try
            {
                // Não deixa reativar produto cuja categoria está inativa
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT c.ativo, c.nome
                                   FROM produto p
                                   INNER JOIN categoria_produto c ON c.codCategoria = p.codCategoria
                                   WHERE p.codProduto = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@codigo", codigo);

                        using (MySqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.Read() && Convert.ToInt32(reader["ativo"]) == 0)
                            {
                                Utilitarios.Aviso("A categoria \"" + reader["nome"] +
                                    "\" deste produto está inativa.\n\n" +
                                    "Reative a categoria primeiro (botão Categorias) " +
                                    "ou edite o produto e escolha outra categoria.");
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao verificar categoria: " + ex.Message);
                return;
            }

            if (!Utilitarios.Confirmar("Deseja realmente reativar este produto?",
                                       "Confirmar reativação"))
                return;

            AlterarSituacao(codigo, 1);
        }

        private void AlterarSituacao(int codigo, int ativo)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"UPDATE produto SET ativo = @ativo
                                   WHERE codProduto = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@ativo", ativo);
                        comando.Parameters.AddWithValue("@codigo", codigo);
                        comando.ExecuteNonQuery();
                    }
                }

                Utilitarios.Sucesso(ativo == 1
                    ? "Produto reativado com sucesso!"
                    : "Produto inativado com sucesso!");

                CarregarProdutos();
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao alterar situação do produto: " + ex.Message);
            }
        }

        // ---------- EXPORTAR / VOLTAR ----------

        private void btnExportarProdutos_Click(object sender, EventArgs e)
        {
            Utilitarios.ExportarExcel(dgvProdutos, "Produtos", "Produtos");
        }

        private void btnVoltarProduto_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
