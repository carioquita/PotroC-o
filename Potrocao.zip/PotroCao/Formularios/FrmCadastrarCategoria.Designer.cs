﻿namespace PotroCao.Formularios
{
    partial class FrmCadastrarCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTituloCategoria = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlDados = new System.Windows.Forms.Panel();
            this.lblSecaoCategoria = new System.Windows.Forms.Label();
            this.lblNomeCategoria = new System.Windows.Forms.Label();
            this.txtNomeCategoria = new System.Windows.Forms.TextBox();
            this.lblDescricaoCategoria = new System.Windows.Forms.Label();
            this.txtDescricaoCategoria = new System.Windows.Forms.TextBox();
            this.btnSalvarCategoria = new System.Windows.Forms.Button();
            this.btnLimparCategoria = new System.Windows.Forms.Button();
            this.btnVoltarCategoria = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTituloCategoria);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTituloCategoria
            // 
            this.lblTituloCategoria.AutoSize = true;
            this.lblTituloCategoria.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloCategoria.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTituloCategoria.Location = new System.Drawing.Point(22, 14);
            this.lblTituloCategoria.Name = "lblTituloCategoria";
            this.lblTituloCategoria.TabIndex = 0;
            this.lblTituloCategoria.Text = "Cadastrar Categoria";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Categorias organizam os produtos do estoque.";
            // 
            // pnlDados
            // 
            this.pnlDados.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlDados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlDados.Controls.Add(this.btnVoltarCategoria);
            this.pnlDados.Controls.Add(this.btnLimparCategoria);
            this.pnlDados.Controls.Add(this.btnSalvarCategoria);
            this.pnlDados.Controls.Add(this.txtDescricaoCategoria);
            this.pnlDados.Controls.Add(this.lblDescricaoCategoria);
            this.pnlDados.Controls.Add(this.txtNomeCategoria);
            this.pnlDados.Controls.Add(this.lblNomeCategoria);
            this.pnlDados.Controls.Add(this.lblSecaoCategoria);
            this.pnlDados.Location = new System.Drawing.Point(20, 100);
            this.pnlDados.Name = "pnlDados";
            this.pnlDados.Size = new System.Drawing.Size(560, 296);
            this.pnlDados.TabIndex = 1;
            this.pnlDados.Tag = "cartao";
            // 
            // lblSecaoCategoria
            // 
            this.lblSecaoCategoria.AutoSize = true;
            this.lblSecaoCategoria.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoCategoria.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoCategoria.Location = new System.Drawing.Point(24, 16);
            this.lblSecaoCategoria.Name = "lblSecaoCategoria";
            this.lblSecaoCategoria.TabIndex = 0;
            this.lblSecaoCategoria.Text = "Dados da categoria";
            // 
            // lblNomeCategoria
            // 
            this.lblNomeCategoria.AutoSize = true;
            this.lblNomeCategoria.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeCategoria.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblNomeCategoria.Location = new System.Drawing.Point(24, 50);
            this.lblNomeCategoria.Name = "lblNomeCategoria";
            this.lblNomeCategoria.TabIndex = 1;
            this.lblNomeCategoria.Text = "Nome *";
            // 
            // txtNomeCategoria
            // 
            this.txtNomeCategoria.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeCategoria.Location = new System.Drawing.Point(24, 72);
            this.txtNomeCategoria.MaxLength = 80;
            this.txtNomeCategoria.Name = "txtNomeCategoria";
            this.txtNomeCategoria.Size = new System.Drawing.Size(512, 25);
            this.txtNomeCategoria.TabIndex = 2;
            // 
            // lblDescricaoCategoria
            // 
            this.lblDescricaoCategoria.AutoSize = true;
            this.lblDescricaoCategoria.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescricaoCategoria.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblDescricaoCategoria.Location = new System.Drawing.Point(24, 110);
            this.lblDescricaoCategoria.Name = "lblDescricaoCategoria";
            this.lblDescricaoCategoria.TabIndex = 3;
            this.lblDescricaoCategoria.Text = "Descrição";
            // 
            // txtDescricaoCategoria
            // 
            this.txtDescricaoCategoria.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescricaoCategoria.Multiline = true;
            this.txtDescricaoCategoria.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescricaoCategoria.Location = new System.Drawing.Point(24, 132);
            this.txtDescricaoCategoria.MaxLength = 225;
            this.txtDescricaoCategoria.Name = "txtDescricaoCategoria";
            this.txtDescricaoCategoria.Size = new System.Drawing.Size(512, 90);
            this.txtDescricaoCategoria.TabIndex = 4;
            // 
            // btnSalvarCategoria
            // 
            this.btnSalvarCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnSalvarCategoria.Location = new System.Drawing.Point(200, 238);
            this.btnSalvarCategoria.Name = "btnSalvarCategoria";
            this.btnSalvarCategoria.Size = new System.Drawing.Size(108, 36);
            this.btnSalvarCategoria.TabIndex = 5;
            this.btnSalvarCategoria.Tag = "primario";
            this.btnSalvarCategoria.Text = "Salvar";
            this.btnSalvarCategoria.UseVisualStyleBackColor = false;
            this.btnSalvarCategoria.Click += new System.EventHandler(this.btnSalvarCategoria_Click);
            // 
            // btnLimparCategoria
            // 
            this.btnLimparCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnLimparCategoria.Location = new System.Drawing.Point(318, 238);
            this.btnLimparCategoria.Name = "btnLimparCategoria";
            this.btnLimparCategoria.Size = new System.Drawing.Size(108, 36);
            this.btnLimparCategoria.TabIndex = 6;
            this.btnLimparCategoria.Tag = "secundario";
            this.btnLimparCategoria.Text = "Limpar";
            this.btnLimparCategoria.UseVisualStyleBackColor = false;
            this.btnLimparCategoria.Click += new System.EventHandler(this.btnLimparCategoria_Click);
            // 
            // btnVoltarCategoria
            // 
            this.btnVoltarCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarCategoria.Location = new System.Drawing.Point(436, 238);
            this.btnVoltarCategoria.Name = "btnVoltarCategoria";
            this.btnVoltarCategoria.Size = new System.Drawing.Size(100, 36);
            this.btnVoltarCategoria.TabIndex = 7;
            this.btnVoltarCategoria.Tag = "neutro";
            this.btnVoltarCategoria.Text = "Voltar";
            this.btnVoltarCategoria.UseVisualStyleBackColor = false;
            this.btnVoltarCategoria.Click += new System.EventHandler(this.btnVoltarCategoria_Click);
            // 
            // FrmCadastrarCategoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(600, 416);
            this.Controls.Add(this.pnlDados);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmCadastrarCategoria";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Cadastrar Categoria";
            this.Load += new System.EventHandler(this.FrmCadastrarCategoria_Load);
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlDados.ResumeLayout(false);
            this.pnlDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTituloCategoria;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlDados;
        private System.Windows.Forms.Label lblSecaoCategoria;
        private System.Windows.Forms.Label lblNomeCategoria;
        private System.Windows.Forms.TextBox txtNomeCategoria;
        private System.Windows.Forms.Label lblDescricaoCategoria;
        private System.Windows.Forms.TextBox txtDescricaoCategoria;
        private System.Windows.Forms.Button btnSalvarCategoria;
        private System.Windows.Forms.Button btnLimparCategoria;
        private System.Windows.Forms.Button btnVoltarCategoria;
    }
}
