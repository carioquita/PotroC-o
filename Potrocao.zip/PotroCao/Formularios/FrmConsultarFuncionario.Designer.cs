﻿namespace PotroCao.Formularios
{
    partial class FrmConsultarFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlFiltros = new System.Windows.Forms.Panel();
            this.lblPesquisarFuncionario = new System.Windows.Forms.Label();
            this.txtPesquisarFuncionario = new System.Windows.Forms.TextBox();
            this.btnPesquisarFuncionario = new System.Windows.Forms.Button();
            this.btnAtualizarFuncionario = new System.Windows.Forms.Button();
            this.btnEditarFuncionario = new System.Windows.Forms.Button();
            this.btnNovoFuncionario = new System.Windows.Forms.Button();
            this.pnlGrade = new System.Windows.Forms.Panel();
            this.dgvFuncionarios = new System.Windows.Forms.DataGridView();
            this.btnVerTodosFuncionarios = new System.Windows.Forms.Button();
            this.btnVerInativosFuncionario = new System.Windows.Forms.Button();
            this.btnVoltarFuncionario = new System.Windows.Forms.Button();
            this.btnExportarFuncionarios = new System.Windows.Forms.Button();
            this.btnReativarFuncionario = new System.Windows.Forms.Button();
            this.btnInativarFuncionario = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlFiltros.SuspendLayout();
            this.pnlGrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuncionarios)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTitulo.Location = new System.Drawing.Point(22, 14);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Funcionários";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Equipe cadastrada: pesquise por nome ou RG.";
            // 
            // pnlFiltros
            // 
            this.pnlFiltros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.pnlFiltros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlFiltros.Controls.Add(this.btnNovoFuncionario);
            this.pnlFiltros.Controls.Add(this.btnEditarFuncionario);
            this.pnlFiltros.Controls.Add(this.btnAtualizarFuncionario);
            this.pnlFiltros.Controls.Add(this.btnPesquisarFuncionario);
            this.pnlFiltros.Controls.Add(this.txtPesquisarFuncionario);
            this.pnlFiltros.Controls.Add(this.lblPesquisarFuncionario);
            this.pnlFiltros.Location = new System.Drawing.Point(20, 100);
            this.pnlFiltros.Name = "pnlFiltros";
            this.pnlFiltros.Size = new System.Drawing.Size(1000, 72);
            this.pnlFiltros.TabIndex = 1;
            this.pnlFiltros.Tag = "cartao";
            // 
            // lblPesquisarFuncionario
            // 
            this.lblPesquisarFuncionario.AutoSize = true;
            this.lblPesquisarFuncionario.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesquisarFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPesquisarFuncionario.Location = new System.Drawing.Point(18, 10);
            this.lblPesquisarFuncionario.Name = "lblPesquisarFuncionario";
            this.lblPesquisarFuncionario.TabIndex = 0;
            this.lblPesquisarFuncionario.Text = "Pesquisar funcionário (nome ou RG)";
            // 
            // txtPesquisarFuncionario
            // 
            this.txtPesquisarFuncionario.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisarFuncionario.Location = new System.Drawing.Point(18, 33);
            this.txtPesquisarFuncionario.Name = "txtPesquisarFuncionario";
            this.txtPesquisarFuncionario.Size = new System.Drawing.Size(300, 25);
            this.txtPesquisarFuncionario.TabIndex = 1;
            // 
            // btnPesquisarFuncionario
            // 
            this.btnPesquisarFuncionario.Location = new System.Drawing.Point(328, 28);
            this.btnPesquisarFuncionario.Name = "btnPesquisarFuncionario";
            this.btnPesquisarFuncionario.Size = new System.Drawing.Size(124, 36);
            this.btnPesquisarFuncionario.TabIndex = 2;
            this.btnPesquisarFuncionario.Tag = "primario";
            this.btnPesquisarFuncionario.Text = "Pesquisar";
            this.btnPesquisarFuncionario.UseVisualStyleBackColor = false;
            this.btnPesquisarFuncionario.Click += new System.EventHandler(this.btnPesquisarFuncionario_Click);
            // 
            // btnAtualizarFuncionario
            // 
            this.btnAtualizarFuncionario.Location = new System.Drawing.Point(462, 28);
            this.btnAtualizarFuncionario.Name = "btnAtualizarFuncionario";
            this.btnAtualizarFuncionario.Size = new System.Drawing.Size(36, 36);
            this.btnAtualizarFuncionario.TabIndex = 3;
            this.btnAtualizarFuncionario.Tag = "secundario";
            this.btnAtualizarFuncionario.Text = "Atualizar";
            this.btnAtualizarFuncionario.UseVisualStyleBackColor = false;
            this.btnAtualizarFuncionario.Click += new System.EventHandler(this.btnAtualizarFuncionario_Click);
            // 
            // btnEditarFuncionario
            // 
            this.btnEditarFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnEditarFuncionario.Location = new System.Drawing.Point(878, 18);
            this.btnEditarFuncionario.Name = "btnEditarFuncionario";
            this.btnEditarFuncionario.Size = new System.Drawing.Size(104, 36);
            this.btnEditarFuncionario.TabIndex = 4;
            this.btnEditarFuncionario.Tag = "primario";
            this.btnEditarFuncionario.Text = "Editar";
            this.btnEditarFuncionario.UseVisualStyleBackColor = false;
            this.btnEditarFuncionario.Click += new System.EventHandler(this.btnEditarFuncionario_Click);
            // 
            // btnNovoFuncionario
            // 
            this.btnNovoFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnNovoFuncionario.Location = new System.Drawing.Point(697, 18);
            this.btnNovoFuncionario.Name = "btnNovoFuncionario";
            this.btnNovoFuncionario.Size = new System.Drawing.Size(171, 36);
            this.btnNovoFuncionario.TabIndex = 5;
            this.btnNovoFuncionario.Tag = "especial";
            this.btnNovoFuncionario.Text = "Novo Funcionário";
            this.btnNovoFuncionario.UseVisualStyleBackColor = false;
            this.btnNovoFuncionario.Click += new System.EventHandler(this.btnNovoFuncionario_Click);
            // 
            // pnlGrade
            // 
            this.pnlGrade.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlGrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlGrade.Controls.Add(this.dgvFuncionarios);
            this.pnlGrade.Location = new System.Drawing.Point(20, 186);
            this.pnlGrade.Name = "pnlGrade";
            this.pnlGrade.Padding = new System.Windows.Forms.Padding(12);
            this.pnlGrade.Size = new System.Drawing.Size(1000, 354);
            this.pnlGrade.TabIndex = 2;
            this.pnlGrade.Tag = "cartao";
            // 
            // dgvFuncionarios
            // 
            this.dgvFuncionarios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFuncionarios.AllowUserToAddRows = false;
            this.dgvFuncionarios.AllowUserToDeleteRows = false;
            this.dgvFuncionarios.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvFuncionarios.BackgroundColor = System.Drawing.Color.White;
            this.dgvFuncionarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvFuncionarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvFuncionarios.MultiSelect = false;
            this.dgvFuncionarios.ReadOnly = true;
            this.dgvFuncionarios.RowHeadersVisible = false;
            this.dgvFuncionarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFuncionarios.Location = new System.Drawing.Point(0, 0);
            this.dgvFuncionarios.Name = "dgvFuncionarios";
            this.dgvFuncionarios.Size = new System.Drawing.Size(100, 100);
            this.dgvFuncionarios.TabIndex = 0;
            // 
            // btnVerTodosFuncionarios
            // 
            this.btnVerTodosFuncionarios.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerTodosFuncionarios.Location = new System.Drawing.Point(20, 560);
            this.btnVerTodosFuncionarios.Name = "btnVerTodosFuncionarios";
            this.btnVerTodosFuncionarios.Size = new System.Drawing.Size(128, 36);
            this.btnVerTodosFuncionarios.TabIndex = 3;
            this.btnVerTodosFuncionarios.Tag = "secundario";
            this.btnVerTodosFuncionarios.Text = "Ver Ativos";
            this.btnVerTodosFuncionarios.UseVisualStyleBackColor = false;
            this.btnVerTodosFuncionarios.Click += new System.EventHandler(this.btnVerTodosFuncionarios_Click);
            // 
            // btnVerInativosFuncionario
            // 
            this.btnVerInativosFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerInativosFuncionario.Location = new System.Drawing.Point(158, 560);
            this.btnVerInativosFuncionario.Name = "btnVerInativosFuncionario";
            this.btnVerInativosFuncionario.Size = new System.Drawing.Size(142, 36);
            this.btnVerInativosFuncionario.TabIndex = 4;
            this.btnVerInativosFuncionario.Tag = "secundario";
            this.btnVerInativosFuncionario.Text = "Ver Inativos";
            this.btnVerInativosFuncionario.UseVisualStyleBackColor = false;
            this.btnVerInativosFuncionario.Click += new System.EventHandler(this.btnVerInativosFuncionario_Click);
            // 
            // btnVoltarFuncionario
            // 
            this.btnVoltarFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarFuncionario.Location = new System.Drawing.Point(916, 560);
            this.btnVoltarFuncionario.Name = "btnVoltarFuncionario";
            this.btnVoltarFuncionario.Size = new System.Drawing.Size(104, 36);
            this.btnVoltarFuncionario.TabIndex = 5;
            this.btnVoltarFuncionario.Tag = "neutro";
            this.btnVoltarFuncionario.Text = "Voltar";
            this.btnVoltarFuncionario.UseVisualStyleBackColor = false;
            this.btnVoltarFuncionario.Click += new System.EventHandler(this.btnVoltarFuncionario_Click);
            // 
            // btnExportarFuncionarios
            // 
            this.btnExportarFuncionarios.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnExportarFuncionarios.Location = new System.Drawing.Point(750, 560);
            this.btnExportarFuncionarios.Name = "btnExportarFuncionarios";
            this.btnExportarFuncionarios.Size = new System.Drawing.Size(156, 36);
            this.btnExportarFuncionarios.TabIndex = 6;
            this.btnExportarFuncionarios.Tag = "confirmar";
            this.btnExportarFuncionarios.Text = "Exportar Excel";
            this.btnExportarFuncionarios.UseVisualStyleBackColor = false;
            this.btnExportarFuncionarios.Click += new System.EventHandler(this.btnExportarFuncionarios_Click);
            // 
            // btnReativarFuncionario
            // 
            this.btnReativarFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnReativarFuncionario.Location = new System.Drawing.Point(627, 560);
            this.btnReativarFuncionario.Name = "btnReativarFuncionario";
            this.btnReativarFuncionario.Size = new System.Drawing.Size(113, 36);
            this.btnReativarFuncionario.TabIndex = 7;
            this.btnReativarFuncionario.Tag = "confirmar";
            this.btnReativarFuncionario.Text = "Reativar";
            this.btnReativarFuncionario.UseVisualStyleBackColor = false;
            this.btnReativarFuncionario.Click += new System.EventHandler(this.btnReativarFuncionario_Click);
            // 
            // btnInativarFuncionario
            // 
            this.btnInativarFuncionario.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnInativarFuncionario.Location = new System.Drawing.Point(504, 560);
            this.btnInativarFuncionario.Name = "btnInativarFuncionario";
            this.btnInativarFuncionario.Size = new System.Drawing.Size(113, 36);
            this.btnInativarFuncionario.TabIndex = 8;
            this.btnInativarFuncionario.Tag = "alerta";
            this.btnInativarFuncionario.Text = "Inativar";
            this.btnInativarFuncionario.UseVisualStyleBackColor = false;
            this.btnInativarFuncionario.Click += new System.EventHandler(this.btnInativarFuncionario_Click);
            // 
            // FrmConsultarFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1040, 620);
            this.Controls.Add(this.btnInativarFuncionario);
            this.Controls.Add(this.btnReativarFuncionario);
            this.Controls.Add(this.btnExportarFuncionarios);
            this.Controls.Add(this.btnVoltarFuncionario);
            this.Controls.Add(this.btnVerInativosFuncionario);
            this.Controls.Add(this.btnVerTodosFuncionarios);
            this.Controls.Add(this.pnlGrade);
            this.Controls.Add(this.pnlFiltros);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1056, 659);
            this.Name = "FrmConsultarFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Consulta de Funcionários";
            this.Load += new System.EventHandler(this.FrmConsultarFuncionario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuncionarios)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlFiltros.ResumeLayout(false);
            this.pnlFiltros.PerformLayout();
            this.pnlGrade.ResumeLayout(false);
            this.pnlGrade.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlFiltros;
        private System.Windows.Forms.Label lblPesquisarFuncionario;
        private System.Windows.Forms.TextBox txtPesquisarFuncionario;
        private System.Windows.Forms.Button btnPesquisarFuncionario;
        private System.Windows.Forms.Button btnAtualizarFuncionario;
        private System.Windows.Forms.Button btnEditarFuncionario;
        private System.Windows.Forms.Button btnNovoFuncionario;
        private System.Windows.Forms.Panel pnlGrade;
        private System.Windows.Forms.DataGridView dgvFuncionarios;
        private System.Windows.Forms.Button btnVerTodosFuncionarios;
        private System.Windows.Forms.Button btnVerInativosFuncionario;
        private System.Windows.Forms.Button btnVoltarFuncionario;
        private System.Windows.Forms.Button btnExportarFuncionarios;
        private System.Windows.Forms.Button btnReativarFuncionario;
        private System.Windows.Forms.Button btnInativarFuncionario;
    }
}
