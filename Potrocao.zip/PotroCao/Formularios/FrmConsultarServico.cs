﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;

namespace PotroCao.Formularios
{
    public partial class FrmConsultarServico : Form
    {
        // Qual lista está sendo exibida: "ativos", "inativos" ou "todos"
        private string filtroAtual = "ativos";

        public FrmConsultarServico()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void FrmConsultarServico_Load(object sender, EventArgs e)
        {
            CarregarServicos();
        }

        private void CarregarServicos()
        {
            string condicao;

            if (filtroAtual == "inativos")
            {
                condicao = "ativo = 0";
                lblExibindoServico.Text = "Exibindo: serviços inativos";
            }
            else if (filtroAtual == "todos")
            {
                condicao = "1 = 1";
                lblExibindoServico.Text = "Exibindo: todos os serviços";
            }
            else
            {
                condicao = "ativo = 1";
                lblExibindoServico.Text = "Exibindo: serviços ativos";
            }

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            codServico AS 'Código',
                            nome AS 'Serviço',
                            descricao AS 'Descrição',
                            preco AS 'Preço (R$)',
                            duracao AS 'Duração (min)',
                            CASE WHEN ativo = 1 THEN 'Ativo' ELSE 'Inativo' END AS 'Situação'
                        FROM servico
                        WHERE " + condicao + @"
                        AND nome LIKE @pesquisa
                        ORDER BY nome";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@pesquisa",
                            "%" + txtPesquisarServico.Text.Trim() + "%");

                        using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                        {
                            DataTable tabela = new DataTable();
                            adaptador.Fill(tabela);
                            dgvServicos.DataSource = tabela;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao carregar serviços: " + ex.Message);
            }
        }

        private void dgvServicos_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (dgvServicos.Columns.Contains("Código"))
                dgvServicos.Columns["Código"].FillWeight = 40;

            if (dgvServicos.Columns.Contains("Serviço"))
                dgvServicos.Columns["Serviço"].FillWeight = 130;

            if (dgvServicos.Columns.Contains("Descrição"))
                dgvServicos.Columns["Descrição"].FillWeight = 220;

            if (dgvServicos.Columns.Contains("Preço (R$)"))
            {
                dgvServicos.Columns["Preço (R$)"].DefaultCellStyle.Format = "N2";
                dgvServicos.Columns["Preço (R$)"].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
                dgvServicos.Columns["Preço (R$)"].FillWeight = 60;
            }

            if (dgvServicos.Columns.Contains("Duração (min)"))
            {
                dgvServicos.Columns["Duração (min)"].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleCenter;
                dgvServicos.Columns["Duração (min)"].FillWeight = 60;
            }

            if (dgvServicos.Columns.Contains("Situação"))
                dgvServicos.Columns["Situação"].FillWeight = 50;

            Utilitarios.DestacarInativos(dgvServicos, "Situação");
        }

        // ---------- PESQUISA E FILTROS ----------

        private void btnPesquisarServico_Click(object sender, EventArgs e)
        {
            CarregarServicos();
        }

        private void btnAtualizarServico_Click(object sender, EventArgs e)
        {
            txtPesquisarServico.Clear();
            filtroAtual = "ativos";
            CarregarServicos();
        }

        private void btnVerAtivosServico_Click(object sender, EventArgs e)
        {
            filtroAtual = "ativos";
            CarregarServicos();
        }

        private void btnVerInativosServico_Click(object sender, EventArgs e)
        {
            filtroAtual = "inativos";
            CarregarServicos();
        }

        private void btnVerTodosServicos_Click(object sender, EventArgs e)
        {
            filtroAtual = "todos";
            CarregarServicos();
        }

        // ---------- NOVO / EDITAR ----------

        private void btnNovoServico_Click(object sender, EventArgs e)
        {
            using (FrmCadastrarServico tela = new FrmCadastrarServico())
            {
                tela.ShowDialog();
            }

            CarregarServicos();
        }

        private void btnEditarServico_Click(object sender, EventArgs e)
        {
            EditarSelecionado();
        }

        private void dgvServicos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                EditarSelecionado();
        }

        private void EditarSelecionado()
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvServicos);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione um serviço para editar!");
                return;
            }

            using (FrmCadastrarServico tela = new FrmCadastrarServico())
            {
                tela.CarregarServico(codigo);
                tela.ShowDialog();
            }

            CarregarServicos();
        }

        // ---------- INATIVAR / REATIVAR ----------

        private void btnInativarServico_Click(object sender, EventArgs e)
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvServicos);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione um serviço para inativar!");
                return;
            }

            if (Utilitarios.TextoSelecionado(dgvServicos, "Situação") == "Inativo")
            {
                Utilitarios.Aviso("Esse serviço já está inativo.");
                return;
            }

            string aviso = "Deseja realmente inativar este serviço?\n\n" +
                           "Ele não será excluído, apenas deixará de aparecer na lista de ativos.";

            try
            {
                // Avisa se o serviço está em agendamentos futuros ainda não concluídos
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"SELECT COUNT(*)
                                   FROM agendamento_servico ags
                                   INNER JOIN agendamento ag ON ag.codAgendamento = ags.codAgendamento
                                   WHERE ags.codServico = @codigo
                                     AND ag.status IN ('Pendente', 'Confirmado')
                                     AND ag.data >= CURDATE()";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@codigo", codigo);
                        int qtd = Convert.ToInt32(comando.ExecuteScalar());

                        if (qtd > 0)
                            aviso += "\n\nAtenção: ele está em " + qtd + " agendamento(s) futuro(s). " +
                                     "Esses agendamentos não serão alterados.";
                    }
                }
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao verificar agendamentos do serviço: " + ex.Message);
                return;
            }

            if (!Utilitarios.Confirmar(aviso, "Confirmar inativação"))
                return;

            AlterarSituacao(codigo, 0);
        }

        private void btnReativarServico_Click(object sender, EventArgs e)
        {
            int codigo = Utilitarios.CodigoSelecionado(dgvServicos);

            if (codigo == 0)
            {
                Utilitarios.Aviso("Selecione um serviço para reativar!\n\n" +
                    "Dica: clique em \"Ver Inativos\" para listar os serviços inativos.");
                return;
            }

            if (Utilitarios.TextoSelecionado(dgvServicos, "Situação") == "Ativo")
            {
                Utilitarios.Aviso("Esse serviço já está ativo.");
                return;
            }

            if (!Utilitarios.Confirmar("Deseja realmente reativar este serviço?", "Confirmar reativação"))
                return;

            AlterarSituacao(codigo, 1);
        }

        private void AlterarSituacao(int codigo, int ativo)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = "UPDATE servico SET ativo = @ativo WHERE codServico = @codigo";

                    using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@ativo", ativo);
                        comando.Parameters.AddWithValue("@codigo", codigo);
                        comando.ExecuteNonQuery();
                    }
                }

                Utilitarios.Sucesso(ativo == 1
                    ? "Serviço reativado com sucesso!"
                    : "Serviço inativado com sucesso!");

                CarregarServicos();
            }
            catch (Exception ex)
            {
                Utilitarios.Erro("Erro ao alterar situação do serviço: " + ex.Message);
            }
        }

        // ---------- EXPORTAR / VOLTAR ----------

        private void btnExportarServicos_Click(object sender, EventArgs e)
        {
            Utilitarios.ExportarExcel(dgvServicos, "Serviços", "Servicos");
        }

        private void btnVoltarServico_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
