﻿namespace PotroCao.Formularios
{
    partial class FrmConsultarServico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTituloConsultaServico = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlFiltros = new System.Windows.Forms.Panel();
            this.lblPesquisarServico = new System.Windows.Forms.Label();
            this.txtPesquisarServico = new System.Windows.Forms.TextBox();
            this.btnPesquisarServico = new System.Windows.Forms.Button();
            this.btnAtualizarServico = new System.Windows.Forms.Button();
            this.btnEditarServico = new System.Windows.Forms.Button();
            this.btnNovoServico = new System.Windows.Forms.Button();
            this.lblExibindoServico = new System.Windows.Forms.Label();
            this.pnlGrade = new System.Windows.Forms.Panel();
            this.dgvServicos = new System.Windows.Forms.DataGridView();
            this.btnVerAtivosServico = new System.Windows.Forms.Button();
            this.btnVerInativosServico = new System.Windows.Forms.Button();
            this.btnVerTodosServicos = new System.Windows.Forms.Button();
            this.btnVoltarServico = new System.Windows.Forms.Button();
            this.btnExportarServicos = new System.Windows.Forms.Button();
            this.btnReativarServico = new System.Windows.Forms.Button();
            this.btnInativarServico = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlFiltros.SuspendLayout();
            this.pnlGrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvServicos)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTituloConsultaServico);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTituloConsultaServico
            // 
            this.lblTituloConsultaServico.AutoSize = true;
            this.lblTituloConsultaServico.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloConsultaServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTituloConsultaServico.Location = new System.Drawing.Point(22, 14);
            this.lblTituloConsultaServico.Name = "lblTituloConsultaServico";
            this.lblTituloConsultaServico.TabIndex = 0;
            this.lblTituloConsultaServico.Text = "Serviços";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Serviços oferecidos, preços e duração.";
            // 
            // pnlFiltros
            // 
            this.pnlFiltros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.pnlFiltros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlFiltros.Controls.Add(this.btnNovoServico);
            this.pnlFiltros.Controls.Add(this.btnEditarServico);
            this.pnlFiltros.Controls.Add(this.btnAtualizarServico);
            this.pnlFiltros.Controls.Add(this.btnPesquisarServico);
            this.pnlFiltros.Controls.Add(this.txtPesquisarServico);
            this.pnlFiltros.Controls.Add(this.lblPesquisarServico);
            this.pnlFiltros.Location = new System.Drawing.Point(20, 100);
            this.pnlFiltros.Name = "pnlFiltros";
            this.pnlFiltros.Size = new System.Drawing.Size(1000, 72);
            this.pnlFiltros.TabIndex = 1;
            this.pnlFiltros.Tag = "cartao";
            // 
            // lblPesquisarServico
            // 
            this.lblPesquisarServico.AutoSize = true;
            this.lblPesquisarServico.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesquisarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPesquisarServico.Location = new System.Drawing.Point(18, 10);
            this.lblPesquisarServico.Name = "lblPesquisarServico";
            this.lblPesquisarServico.TabIndex = 0;
            this.lblPesquisarServico.Text = "Pesquisar serviço";
            // 
            // txtPesquisarServico
            // 
            this.txtPesquisarServico.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisarServico.Location = new System.Drawing.Point(18, 33);
            this.txtPesquisarServico.Name = "txtPesquisarServico";
            this.txtPesquisarServico.Size = new System.Drawing.Size(300, 25);
            this.txtPesquisarServico.TabIndex = 1;
            // 
            // btnPesquisarServico
            // 
            this.btnPesquisarServico.Location = new System.Drawing.Point(328, 28);
            this.btnPesquisarServico.Name = "btnPesquisarServico";
            this.btnPesquisarServico.Size = new System.Drawing.Size(124, 36);
            this.btnPesquisarServico.TabIndex = 2;
            this.btnPesquisarServico.Tag = "primario";
            this.btnPesquisarServico.Text = "Pesquisar";
            this.btnPesquisarServico.UseVisualStyleBackColor = false;
            this.btnPesquisarServico.Click += new System.EventHandler(this.btnPesquisarServico_Click);
            // 
            // btnAtualizarServico
            // 
            this.btnAtualizarServico.Location = new System.Drawing.Point(462, 28);
            this.btnAtualizarServico.Name = "btnAtualizarServico";
            this.btnAtualizarServico.Size = new System.Drawing.Size(36, 36);
            this.btnAtualizarServico.TabIndex = 3;
            this.btnAtualizarServico.Tag = "secundario";
            this.btnAtualizarServico.Text = "Atualizar";
            this.btnAtualizarServico.UseVisualStyleBackColor = false;
            this.btnAtualizarServico.Click += new System.EventHandler(this.btnAtualizarServico_Click);
            // 
            // btnEditarServico
            // 
            this.btnEditarServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnEditarServico.Location = new System.Drawing.Point(878, 18);
            this.btnEditarServico.Name = "btnEditarServico";
            this.btnEditarServico.Size = new System.Drawing.Size(104, 36);
            this.btnEditarServico.TabIndex = 4;
            this.btnEditarServico.Tag = "primario";
            this.btnEditarServico.Text = "Editar";
            this.btnEditarServico.UseVisualStyleBackColor = false;
            this.btnEditarServico.Click += new System.EventHandler(this.btnEditarServico_Click);
            // 
            // btnNovoServico
            // 
            this.btnNovoServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnNovoServico.Location = new System.Drawing.Point(726, 18);
            this.btnNovoServico.Name = "btnNovoServico";
            this.btnNovoServico.Size = new System.Drawing.Size(142, 36);
            this.btnNovoServico.TabIndex = 5;
            this.btnNovoServico.Tag = "especial";
            this.btnNovoServico.Text = "Novo Serviço";
            this.btnNovoServico.UseVisualStyleBackColor = false;
            this.btnNovoServico.Click += new System.EventHandler(this.btnNovoServico_Click);
            // 
            // lblExibindoServico
            // 
            this.lblExibindoServico.AutoSize = true;
            this.lblExibindoServico.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExibindoServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblExibindoServico.Location = new System.Drawing.Point(24, 184);
            this.lblExibindoServico.Name = "lblExibindoServico";
            this.lblExibindoServico.TabIndex = 2;
            this.lblExibindoServico.Text = "Exibindo: registros ativos";
            // 
            // pnlGrade
            // 
            this.pnlGrade.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlGrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlGrade.Controls.Add(this.dgvServicos);
            this.pnlGrade.Location = new System.Drawing.Point(20, 212);
            this.pnlGrade.Name = "pnlGrade";
            this.pnlGrade.Padding = new System.Windows.Forms.Padding(12);
            this.pnlGrade.Size = new System.Drawing.Size(1000, 328);
            this.pnlGrade.TabIndex = 3;
            this.pnlGrade.Tag = "cartao";
            // 
            // dgvServicos
            // 
            this.dgvServicos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvServicos.AllowUserToAddRows = false;
            this.dgvServicos.AllowUserToDeleteRows = false;
            this.dgvServicos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvServicos.BackgroundColor = System.Drawing.Color.White;
            this.dgvServicos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvServicos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvServicos.MultiSelect = false;
            this.dgvServicos.ReadOnly = true;
            this.dgvServicos.RowHeadersVisible = false;
            this.dgvServicos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvServicos.Location = new System.Drawing.Point(0, 0);
            this.dgvServicos.Name = "dgvServicos";
            this.dgvServicos.Size = new System.Drawing.Size(100, 100);
            this.dgvServicos.TabIndex = 0;
            this.dgvServicos.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvServicos_CellDoubleClick);
            this.dgvServicos.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvServicos_DataBindingComplete);
            // 
            // btnVerAtivosServico
            // 
            this.btnVerAtivosServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerAtivosServico.Location = new System.Drawing.Point(20, 560);
            this.btnVerAtivosServico.Name = "btnVerAtivosServico";
            this.btnVerAtivosServico.Size = new System.Drawing.Size(128, 36);
            this.btnVerAtivosServico.TabIndex = 4;
            this.btnVerAtivosServico.Tag = "secundario";
            this.btnVerAtivosServico.Text = "Ver Ativos";
            this.btnVerAtivosServico.UseVisualStyleBackColor = false;
            this.btnVerAtivosServico.Click += new System.EventHandler(this.btnVerAtivosServico_Click);
            // 
            // btnVerInativosServico
            // 
            this.btnVerInativosServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerInativosServico.Location = new System.Drawing.Point(158, 560);
            this.btnVerInativosServico.Name = "btnVerInativosServico";
            this.btnVerInativosServico.Size = new System.Drawing.Size(142, 36);
            this.btnVerInativosServico.TabIndex = 5;
            this.btnVerInativosServico.Tag = "secundario";
            this.btnVerInativosServico.Text = "Ver Inativos";
            this.btnVerInativosServico.UseVisualStyleBackColor = false;
            this.btnVerInativosServico.Click += new System.EventHandler(this.btnVerInativosServico_Click);
            // 
            // btnVerTodosServicos
            // 
            this.btnVerTodosServicos.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerTodosServicos.Location = new System.Drawing.Point(310, 560);
            this.btnVerTodosServicos.Name = "btnVerTodosServicos";
            this.btnVerTodosServicos.Size = new System.Drawing.Size(120, 36);
            this.btnVerTodosServicos.TabIndex = 6;
            this.btnVerTodosServicos.Tag = "secundario";
            this.btnVerTodosServicos.Text = "Ver Todos";
            this.btnVerTodosServicos.UseVisualStyleBackColor = false;
            this.btnVerTodosServicos.Click += new System.EventHandler(this.btnVerTodosServicos_Click);
            // 
            // btnVoltarServico
            // 
            this.btnVoltarServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarServico.Location = new System.Drawing.Point(916, 560);
            this.btnVoltarServico.Name = "btnVoltarServico";
            this.btnVoltarServico.Size = new System.Drawing.Size(104, 36);
            this.btnVoltarServico.TabIndex = 7;
            this.btnVoltarServico.Tag = "neutro";
            this.btnVoltarServico.Text = "Voltar";
            this.btnVoltarServico.UseVisualStyleBackColor = false;
            this.btnVoltarServico.Click += new System.EventHandler(this.btnVoltarServico_Click);
            // 
            // btnExportarServicos
            // 
            this.btnExportarServicos.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnExportarServicos.Location = new System.Drawing.Point(750, 560);
            this.btnExportarServicos.Name = "btnExportarServicos";
            this.btnExportarServicos.Size = new System.Drawing.Size(156, 36);
            this.btnExportarServicos.TabIndex = 8;
            this.btnExportarServicos.Tag = "confirmar";
            this.btnExportarServicos.Text = "Exportar Excel";
            this.btnExportarServicos.UseVisualStyleBackColor = false;
            this.btnExportarServicos.Click += new System.EventHandler(this.btnExportarServicos_Click);
            // 
            // btnReativarServico
            // 
            this.btnReativarServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnReativarServico.Location = new System.Drawing.Point(627, 560);
            this.btnReativarServico.Name = "btnReativarServico";
            this.btnReativarServico.Size = new System.Drawing.Size(113, 36);
            this.btnReativarServico.TabIndex = 9;
            this.btnReativarServico.Tag = "confirmar";
            this.btnReativarServico.Text = "Reativar";
            this.btnReativarServico.UseVisualStyleBackColor = false;
            this.btnReativarServico.Click += new System.EventHandler(this.btnReativarServico_Click);
            // 
            // btnInativarServico
            // 
            this.btnInativarServico.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnInativarServico.Location = new System.Drawing.Point(504, 560);
            this.btnInativarServico.Name = "btnInativarServico";
            this.btnInativarServico.Size = new System.Drawing.Size(113, 36);
            this.btnInativarServico.TabIndex = 10;
            this.btnInativarServico.Tag = "alerta";
            this.btnInativarServico.Text = "Inativar";
            this.btnInativarServico.UseVisualStyleBackColor = false;
            this.btnInativarServico.Click += new System.EventHandler(this.btnInativarServico_Click);
            // 
            // FrmConsultarServico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1040, 620);
            this.Controls.Add(this.btnInativarServico);
            this.Controls.Add(this.btnReativarServico);
            this.Controls.Add(this.btnExportarServicos);
            this.Controls.Add(this.btnVoltarServico);
            this.Controls.Add(this.btnVerTodosServicos);
            this.Controls.Add(this.btnVerInativosServico);
            this.Controls.Add(this.btnVerAtivosServico);
            this.Controls.Add(this.pnlGrade);
            this.Controls.Add(this.lblExibindoServico);
            this.Controls.Add(this.pnlFiltros);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1056, 659);
            this.Name = "FrmConsultarServico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Serviços";
            this.Load += new System.EventHandler(this.FrmConsultarServico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvServicos)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlFiltros.ResumeLayout(false);
            this.pnlFiltros.PerformLayout();
            this.pnlGrade.ResumeLayout(false);
            this.pnlGrade.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTituloConsultaServico;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlFiltros;
        private System.Windows.Forms.Label lblPesquisarServico;
        private System.Windows.Forms.TextBox txtPesquisarServico;
        private System.Windows.Forms.Button btnPesquisarServico;
        private System.Windows.Forms.Button btnAtualizarServico;
        private System.Windows.Forms.Button btnEditarServico;
        private System.Windows.Forms.Button btnNovoServico;
        private System.Windows.Forms.Label lblExibindoServico;
        private System.Windows.Forms.Panel pnlGrade;
        private System.Windows.Forms.DataGridView dgvServicos;
        private System.Windows.Forms.Button btnVerAtivosServico;
        private System.Windows.Forms.Button btnVerInativosServico;
        private System.Windows.Forms.Button btnVerTodosServicos;
        private System.Windows.Forms.Button btnVoltarServico;
        private System.Windows.Forms.Button btnExportarServicos;
        private System.Windows.Forms.Button btnReativarServico;
        private System.Windows.Forms.Button btnInativarServico;
    }
}
