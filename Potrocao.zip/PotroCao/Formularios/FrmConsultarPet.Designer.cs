﻿namespace PotroCao.Formularios
{
    partial class FrmConsultarPet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlFiltros = new System.Windows.Forms.Panel();
            this.lblPesquisar = new System.Windows.Forms.Label();
            this.txtPesquisarPet = new System.Windows.Forms.TextBox();
            this.btnPesquisarPet = new System.Windows.Forms.Button();
            this.btnAtualizarPet = new System.Windows.Forms.Button();
            this.btnEditarPet = new System.Windows.Forms.Button();
            this.btnNovoPet = new System.Windows.Forms.Button();
            this.pnlGrade = new System.Windows.Forms.Panel();
            this.dgvPets = new System.Windows.Forms.DataGridView();
            this.btnVerInativos = new System.Windows.Forms.Button();
            this.btnVoltarConsultaPet = new System.Windows.Forms.Button();
            this.btnExportarPet = new System.Windows.Forms.Button();
            this.btnReativarPet = new System.Windows.Forms.Button();
            this.btnExcluirPet = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlFiltros.SuspendLayout();
            this.pnlGrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPets)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTitulo.Location = new System.Drawing.Point(22, 14);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Pets";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Animais cadastrados e seus tutores.";
            // 
            // pnlFiltros
            // 
            this.pnlFiltros.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right));
            this.pnlFiltros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlFiltros.Controls.Add(this.btnNovoPet);
            this.pnlFiltros.Controls.Add(this.btnEditarPet);
            this.pnlFiltros.Controls.Add(this.btnAtualizarPet);
            this.pnlFiltros.Controls.Add(this.btnPesquisarPet);
            this.pnlFiltros.Controls.Add(this.txtPesquisarPet);
            this.pnlFiltros.Controls.Add(this.lblPesquisar);
            this.pnlFiltros.Location = new System.Drawing.Point(20, 100);
            this.pnlFiltros.Name = "pnlFiltros";
            this.pnlFiltros.Size = new System.Drawing.Size(1000, 72);
            this.pnlFiltros.TabIndex = 1;
            this.pnlFiltros.Tag = "cartao";
            // 
            // lblPesquisar
            // 
            this.lblPesquisar.AutoSize = true;
            this.lblPesquisar.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesquisar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPesquisar.Location = new System.Drawing.Point(18, 10);
            this.lblPesquisar.Name = "lblPesquisar";
            this.lblPesquisar.TabIndex = 0;
            this.lblPesquisar.Text = "Pesquisar pet";
            // 
            // txtPesquisarPet
            // 
            this.txtPesquisarPet.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisarPet.Location = new System.Drawing.Point(18, 33);
            this.txtPesquisarPet.Name = "txtPesquisarPet";
            this.txtPesquisarPet.Size = new System.Drawing.Size(300, 25);
            this.txtPesquisarPet.TabIndex = 1;
            // 
            // btnPesquisarPet
            // 
            this.btnPesquisarPet.Location = new System.Drawing.Point(328, 28);
            this.btnPesquisarPet.Name = "btnPesquisarPet";
            this.btnPesquisarPet.Size = new System.Drawing.Size(124, 36);
            this.btnPesquisarPet.TabIndex = 2;
            this.btnPesquisarPet.Tag = "primario";
            this.btnPesquisarPet.Text = "Pesquisar";
            this.btnPesquisarPet.UseVisualStyleBackColor = false;
            this.btnPesquisarPet.Click += new System.EventHandler(this.btnPesquisarPet_Click);
            // 
            // btnAtualizarPet
            // 
            this.btnAtualizarPet.Location = new System.Drawing.Point(462, 28);
            this.btnAtualizarPet.Name = "btnAtualizarPet";
            this.btnAtualizarPet.Size = new System.Drawing.Size(36, 36);
            this.btnAtualizarPet.TabIndex = 3;
            this.btnAtualizarPet.Tag = "secundario";
            this.btnAtualizarPet.Text = "Atualizar";
            this.btnAtualizarPet.UseVisualStyleBackColor = false;
            this.btnAtualizarPet.Click += new System.EventHandler(this.btnAtualizarPet_Click);
            // 
            // btnEditarPet
            // 
            this.btnEditarPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnEditarPet.Location = new System.Drawing.Point(878, 18);
            this.btnEditarPet.Name = "btnEditarPet";
            this.btnEditarPet.Size = new System.Drawing.Size(104, 36);
            this.btnEditarPet.TabIndex = 4;
            this.btnEditarPet.Tag = "primario";
            this.btnEditarPet.Text = "Editar";
            this.btnEditarPet.UseVisualStyleBackColor = false;
            this.btnEditarPet.Click += new System.EventHandler(this.btnEditarPet_Click);
            // 
            // btnNovoPet
            // 
            this.btnNovoPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.btnNovoPet.Location = new System.Drawing.Point(755, 18);
            this.btnNovoPet.Name = "btnNovoPet";
            this.btnNovoPet.Size = new System.Drawing.Size(113, 36);
            this.btnNovoPet.TabIndex = 5;
            this.btnNovoPet.Tag = "especial";
            this.btnNovoPet.Text = "Novo Pet";
            this.btnNovoPet.UseVisualStyleBackColor = false;
            this.btnNovoPet.Click += new System.EventHandler(this.btnNovoPet_Click);
            // 
            // pnlGrade
            // 
            this.pnlGrade.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlGrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlGrade.Controls.Add(this.dgvPets);
            this.pnlGrade.Location = new System.Drawing.Point(20, 186);
            this.pnlGrade.Name = "pnlGrade";
            this.pnlGrade.Padding = new System.Windows.Forms.Padding(12);
            this.pnlGrade.Size = new System.Drawing.Size(1000, 354);
            this.pnlGrade.TabIndex = 2;
            this.pnlGrade.Tag = "cartao";
            // 
            // dgvPets
            // 
            this.dgvPets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPets.AllowUserToAddRows = false;
            this.dgvPets.AllowUserToDeleteRows = false;
            this.dgvPets.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPets.BackgroundColor = System.Drawing.Color.White;
            this.dgvPets.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvPets.MultiSelect = false;
            this.dgvPets.ReadOnly = true;
            this.dgvPets.RowHeadersVisible = false;
            this.dgvPets.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPets.Location = new System.Drawing.Point(0, 0);
            this.dgvPets.Name = "dgvPets";
            this.dgvPets.Size = new System.Drawing.Size(100, 100);
            this.dgvPets.TabIndex = 0;
            this.dgvPets.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPets_CellContentClick);
            // 
            // btnVerInativos
            // 
            this.btnVerInativos.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left));
            this.btnVerInativos.Location = new System.Drawing.Point(20, 560);
            this.btnVerInativos.Name = "btnVerInativos";
            this.btnVerInativos.Size = new System.Drawing.Size(142, 36);
            this.btnVerInativos.TabIndex = 3;
            this.btnVerInativos.Tag = "secundario";
            this.btnVerInativos.Text = "Ver Inativos";
            this.btnVerInativos.UseVisualStyleBackColor = false;
            this.btnVerInativos.Click += new System.EventHandler(this.btnVerInativos_Click);
            // 
            // btnVoltarConsultaPet
            // 
            this.btnVoltarConsultaPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarConsultaPet.Location = new System.Drawing.Point(916, 560);
            this.btnVoltarConsultaPet.Name = "btnVoltarConsultaPet";
            this.btnVoltarConsultaPet.Size = new System.Drawing.Size(104, 36);
            this.btnVoltarConsultaPet.TabIndex = 4;
            this.btnVoltarConsultaPet.Tag = "neutro";
            this.btnVoltarConsultaPet.Text = "Voltar";
            this.btnVoltarConsultaPet.UseVisualStyleBackColor = false;
            this.btnVoltarConsultaPet.Click += new System.EventHandler(this.btnVoltarConsultaPet_Click);
            // 
            // btnExportarPet
            // 
            this.btnExportarPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnExportarPet.Location = new System.Drawing.Point(750, 560);
            this.btnExportarPet.Name = "btnExportarPet";
            this.btnExportarPet.Size = new System.Drawing.Size(156, 36);
            this.btnExportarPet.TabIndex = 5;
            this.btnExportarPet.Tag = "confirmar";
            this.btnExportarPet.Text = "Exportar Excel";
            this.btnExportarPet.UseVisualStyleBackColor = false;
            this.btnExportarPet.Click += new System.EventHandler(this.btnExportarPet_Click);
            // 
            // btnReativarPet
            // 
            this.btnReativarPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnReativarPet.Location = new System.Drawing.Point(627, 560);
            this.btnReativarPet.Name = "btnReativarPet";
            this.btnReativarPet.Size = new System.Drawing.Size(113, 36);
            this.btnReativarPet.TabIndex = 6;
            this.btnReativarPet.Tag = "confirmar";
            this.btnReativarPet.Text = "Reativar";
            this.btnReativarPet.UseVisualStyleBackColor = false;
            this.btnReativarPet.Click += new System.EventHandler(this.btnReativarPet_Click);
            // 
            // btnExcluirPet
            // 
            this.btnExcluirPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnExcluirPet.Location = new System.Drawing.Point(504, 560);
            this.btnExcluirPet.Name = "btnExcluirPet";
            this.btnExcluirPet.Size = new System.Drawing.Size(113, 36);
            this.btnExcluirPet.TabIndex = 7;
            this.btnExcluirPet.Tag = "alerta";
            this.btnExcluirPet.Text = "Inativar";
            this.btnExcluirPet.UseVisualStyleBackColor = false;
            this.btnExcluirPet.Click += new System.EventHandler(this.btnExcluirPet_Click);
            // 
            // FrmConsultarPet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1040, 620);
            this.Controls.Add(this.btnExcluirPet);
            this.Controls.Add(this.btnReativarPet);
            this.Controls.Add(this.btnExportarPet);
            this.Controls.Add(this.btnVoltarConsultaPet);
            this.Controls.Add(this.btnVerInativos);
            this.Controls.Add(this.pnlGrade);
            this.Controls.Add(this.pnlFiltros);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1056, 659);
            this.Name = "FrmConsultarPet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Consulta de Pets";
            this.Load += new System.EventHandler(this.FrmConsultarPet_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPets)).EndInit();
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlFiltros.ResumeLayout(false);
            this.pnlFiltros.PerformLayout();
            this.pnlGrade.ResumeLayout(false);
            this.pnlGrade.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlFiltros;
        private System.Windows.Forms.Label lblPesquisar;
        private System.Windows.Forms.TextBox txtPesquisarPet;
        private System.Windows.Forms.Button btnPesquisarPet;
        private System.Windows.Forms.Button btnAtualizarPet;
        private System.Windows.Forms.Button btnEditarPet;
        private System.Windows.Forms.Button btnNovoPet;
        private System.Windows.Forms.Panel pnlGrade;
        private System.Windows.Forms.DataGridView dgvPets;
        private System.Windows.Forms.Button btnVerInativos;
        private System.Windows.Forms.Button btnVoltarConsultaPet;
        private System.Windows.Forms.Button btnExportarPet;
        private System.Windows.Forms.Button btnReativarPet;
        private System.Windows.Forms.Button btnExcluirPet;
    }
}
