﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao;
using ClosedXML.Excel;

namespace PotroCao.Formularios
{
    public partial class FrmConsultarFuncionario : Form
    {
        public FrmConsultarFuncionario()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void CarregarFuncionarios(string pesquisa = "")
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                SELECT
                    codFun AS 'Código',
                    nome AS 'Nome',
                    rg AS 'RG',
                    email AS 'Email',
                    telefone AS 'Telefone',
                    endereco AS 'Endereço',
                    datanasc AS 'Nascimento',
                    cargo AS 'Cargo'
                FROM funcionario
                WHERE status = 'Ativo'
                AND (nome LIKE @pesquisa OR rg LIKE @pesquisa)
                ORDER BY nome";

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(sql, conexao);

                    adaptador.SelectCommand.Parameters.AddWithValue(
                        "@pesquisa", "%" + pesquisa + "%"
                    );

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvFuncionarios.DataSource = tabela;
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao carregar funcionários: " + ex.Message);
            }
        }
        private void FrmConsultarFuncionario_Load(object sender, EventArgs e)
        {
            CarregarFuncionarios();
        }

        private void btnPesquisarFuncionario_Click(object sender, EventArgs e)
        {
            CarregarFuncionarios(txtPesquisarFuncionario.Text.Trim());
        }

        private void btnAtualizarFuncionario_Click(object sender, EventArgs e)
        {
            txtPesquisarFuncionario.Clear();
            CarregarFuncionarios();

            CaixaMensagem.Show("Lista de funcionários atualizada!");
        }

        private void btnEditarFuncionario_Click(object sender, EventArgs e)
        {
            if (dgvFuncionarios.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um funcionário para editar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvFuncionarios.CurrentRow.Cells["Código"].Value
            );

            FrmCadastrarFuncionario tela = new FrmCadastrarFuncionario();

            tela.CarregarFuncionario(codigo);

            tela.ShowDialog();

            CarregarFuncionarios(txtPesquisarFuncionario.Text.Trim());
        }

        private void btnVerInativosFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"
                SELECT
                    codFun AS 'Código',
                    nome AS 'Nome',
                    rg AS 'RG',
                    email AS 'Email',
                    telefone AS 'Telefone',
                    endereco AS 'Endereço',
                    datanasc AS 'Nascimento',
                    cargo AS 'Cargo'
                FROM funcionario
                WHERE status = 'Inativo'
                ORDER BY nome";

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dgvFuncionarios.DataSource = tabela;
                    txtPesquisarFuncionario.Clear();
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao carregar funcionários inativos: " + ex.Message);
            }
        }
        private void btnInativarFuncionario_Click(object sender, EventArgs e)
        {
            if (dgvFuncionarios.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um funcionário para inativar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvFuncionarios.CurrentRow.Cells["Código"].Value
            );

            DialogResult resposta = CaixaMensagem.Show(
                "Deseja realmente inativar este funcionário?",
                "Confirmar inativação",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resposta == DialogResult.No)
                return;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"UPDATE funcionario
                           SET status = 'Inativo'
                           WHERE codFun = @codigo";

                    MySqlCommand comando = new MySqlCommand(sql, conexao);
                    comando.Parameters.AddWithValue("@codigo", codigo);

                    comando.ExecuteNonQuery();

                    CaixaMensagem.Show("Funcionário inativado com sucesso!");

                    CarregarFuncionarios(txtPesquisarFuncionario.Text.Trim());
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao inativar funcionário: " + ex.Message);
            }
        }

        private void btnReativarFuncionario_Click(object sender, EventArgs e)
        {
            if (dgvFuncionarios.CurrentRow == null)
            {
                CaixaMensagem.Show("Selecione um funcionário para reativar!");
                return;
            }

            int codigo = Convert.ToInt32(
                dgvFuncionarios.CurrentRow.Cells["Código"].Value
            );

            DialogResult resposta = CaixaMensagem.Show(
                "Deseja realmente reativar este funcionário?",
                "Confirmar reativação",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resposta == DialogResult.No)
                return;

            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    string sql = @"UPDATE funcionario
                           SET status = 'Ativo'
                           WHERE codFun = @codigo";

                    MySqlCommand comando = new MySqlCommand(sql, conexao);
                    comando.Parameters.AddWithValue("@codigo", codigo);

                    comando.ExecuteNonQuery();

                    CaixaMensagem.Show("Funcionário reativado com sucesso!");

                    CarregarFuncionarios();
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao reativar funcionário: " + ex.Message);
            }
        }

        private void btnVerTodosFuncionarios_Click(object sender, EventArgs e)
        {
            txtPesquisarFuncionario.Clear();
            CarregarFuncionarios();
        }

        private void btnExportarFuncionarios_Click(object sender, EventArgs e)
        {
            if (dgvFuncionarios.Rows.Count == 0)
            {
                CaixaMensagem.Show("Não há funcionários para exportar!");
                return;
            }

            try
            {
                using (SaveFileDialog salvar = new SaveFileDialog())
                {
                    salvar.Filter = "Arquivo Excel (*.xlsx)|*.xlsx";
                    salvar.Title = "Salvar funcionários";
                    salvar.FileName = "Funcionarios.xlsx";

                    if (salvar.ShowDialog() == DialogResult.OK)
                    {
                        using (var workbook = new ClosedXML.Excel.XLWorkbook())
                        {
                            var planilha = workbook.Worksheets.Add("Funcionários");

                            for (int coluna = 0; coluna < dgvFuncionarios.Columns.Count; coluna++)
                            {
                                planilha.Cell(1, coluna + 1).Value =
                                    dgvFuncionarios.Columns[coluna].HeaderText;
                            }

                            for (int linha = 0; linha < dgvFuncionarios.Rows.Count; linha++)
                            {
                                for (int coluna = 0; coluna < dgvFuncionarios.Columns.Count; coluna++)
                                {
                                    planilha.Cell(linha + 2, coluna + 1).Value =
                                        dgvFuncionarios.Rows[linha].Cells[coluna].Value?.ToString();
                                }
                            }

                            planilha.Columns().AdjustToContents();
                            workbook.SaveAs(salvar.FileName);
                        }

                        CaixaMensagem.Show("Funcionários exportados com sucesso!");
                    }
                }
            }
            catch (Exception ex)
            {
                CaixaMensagem.Show("Erro ao exportar funcionários: " + ex.Message);
            }
        }

        private void btnVoltarFuncionario_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Abre o cadastro de um novo funcionário a partir da consulta
        private void btnNovoFuncionario_Click(object sender, EventArgs e)
        {
            using (FrmCadastrarFuncionario tela = new FrmCadastrarFuncionario())
            {
                tela.ShowDialog();
            }

            CarregarFuncionarios(txtPesquisarFuncionario.Text.Trim());
        }
    }
}
