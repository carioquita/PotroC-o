﻿namespace PotroCao.Formularios
{
    partial class FrmCadastrarAgendamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlDados = new System.Windows.Forms.Panel();
            this.lblSecaoCliente = new System.Windows.Forms.Label();
            this.lblClienteAgendamento = new System.Windows.Forms.Label();
            this.cmbClienteAgendamento = new System.Windows.Forms.ComboBox();
            this.lblPetAgendamento = new System.Windows.Forms.Label();
            this.cmbPetAgendamento = new System.Windows.Forms.ComboBox();
            this.lblSecaoAtendimento = new System.Windows.Forms.Label();
            this.lblFuncionarioAgendamento = new System.Windows.Forms.Label();
            this.cmbFuncionarioAgendamento = new System.Windows.Forms.ComboBox();
            this.lblStatusAgendamento = new System.Windows.Forms.Label();
            this.cmbStatusAgendamento = new System.Windows.Forms.ComboBox();
            this.lblSecaoData = new System.Windows.Forms.Label();
            this.lblDataAgendamento = new System.Windows.Forms.Label();
            this.dtpDataAgendamento = new System.Windows.Forms.DateTimePicker();
            this.lblHorarioAgendamento = new System.Windows.Forms.Label();
            this.cmbHorarioAgendamento = new System.Windows.Forms.ComboBox();
            this.lblDicaHorario = new System.Windows.Forms.Label();
            this.lblObservacoes = new System.Windows.Forms.Label();
            this.txtObservacoesAgendamento = new System.Windows.Forms.TextBox();
            this.btnSalvarAgendamento = new System.Windows.Forms.Button();
            this.btnLimparAgendamento = new System.Windows.Forms.Button();
            this.btnVoltarAgendamento = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTitulo.Location = new System.Drawing.Point(22, 14);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Agendamento";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Marque o atendimento escolhendo tutor, pet, data e horário.";
            // 
            // pnlDados
            // 
            this.pnlDados.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlDados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlDados.Controls.Add(this.btnVoltarAgendamento);
            this.pnlDados.Controls.Add(this.btnLimparAgendamento);
            this.pnlDados.Controls.Add(this.btnSalvarAgendamento);
            this.pnlDados.Controls.Add(this.txtObservacoesAgendamento);
            this.pnlDados.Controls.Add(this.lblObservacoes);
            this.pnlDados.Controls.Add(this.lblDicaHorario);
            this.pnlDados.Controls.Add(this.cmbHorarioAgendamento);
            this.pnlDados.Controls.Add(this.lblHorarioAgendamento);
            this.pnlDados.Controls.Add(this.dtpDataAgendamento);
            this.pnlDados.Controls.Add(this.lblDataAgendamento);
            this.pnlDados.Controls.Add(this.lblSecaoData);
            this.pnlDados.Controls.Add(this.cmbStatusAgendamento);
            this.pnlDados.Controls.Add(this.lblStatusAgendamento);
            this.pnlDados.Controls.Add(this.cmbFuncionarioAgendamento);
            this.pnlDados.Controls.Add(this.lblFuncionarioAgendamento);
            this.pnlDados.Controls.Add(this.lblSecaoAtendimento);
            this.pnlDados.Controls.Add(this.cmbPetAgendamento);
            this.pnlDados.Controls.Add(this.lblPetAgendamento);
            this.pnlDados.Controls.Add(this.cmbClienteAgendamento);
            this.pnlDados.Controls.Add(this.lblClienteAgendamento);
            this.pnlDados.Controls.Add(this.lblSecaoCliente);
            this.pnlDados.Location = new System.Drawing.Point(20, 100);
            this.pnlDados.Name = "pnlDados";
            this.pnlDados.Size = new System.Drawing.Size(720, 432);
            this.pnlDados.TabIndex = 1;
            this.pnlDados.Tag = "cartao";
            // 
            // lblSecaoCliente
            // 
            this.lblSecaoCliente.AutoSize = true;
            this.lblSecaoCliente.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoCliente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoCliente.Location = new System.Drawing.Point(24, 16);
            this.lblSecaoCliente.Name = "lblSecaoCliente";
            this.lblSecaoCliente.TabIndex = 0;
            this.lblSecaoCliente.Text = "Tutor e pet";
            // 
            // lblClienteAgendamento
            // 
            this.lblClienteAgendamento.AutoSize = true;
            this.lblClienteAgendamento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClienteAgendamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblClienteAgendamento.Location = new System.Drawing.Point(24, 50);
            this.lblClienteAgendamento.Name = "lblClienteAgendamento";
            this.lblClienteAgendamento.TabIndex = 1;
            this.lblClienteAgendamento.Text = "Cliente";
            // 
            // cmbClienteAgendamento
            // 
            this.cmbClienteAgendamento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbClienteAgendamento.FormattingEnabled = true;
            this.cmbClienteAgendamento.Location = new System.Drawing.Point(24, 72);
            this.cmbClienteAgendamento.Name = "cmbClienteAgendamento";
            this.cmbClienteAgendamento.Size = new System.Drawing.Size(320, 27);
            this.cmbClienteAgendamento.TabIndex = 2;
            this.cmbClienteAgendamento.SelectedIndexChanged += new System.EventHandler(this.cmbClienteAgendamento_SelectedIndexChanged);
            // 
            // lblPetAgendamento
            // 
            this.lblPetAgendamento.AutoSize = true;
            this.lblPetAgendamento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPetAgendamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblPetAgendamento.Location = new System.Drawing.Point(24, 110);
            this.lblPetAgendamento.Name = "lblPetAgendamento";
            this.lblPetAgendamento.TabIndex = 3;
            this.lblPetAgendamento.Text = "Pet";
            // 
            // cmbPetAgendamento
            // 
            this.cmbPetAgendamento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPetAgendamento.FormattingEnabled = true;
            this.cmbPetAgendamento.Location = new System.Drawing.Point(24, 132);
            this.cmbPetAgendamento.Name = "cmbPetAgendamento";
            this.cmbPetAgendamento.Size = new System.Drawing.Size(320, 27);
            this.cmbPetAgendamento.TabIndex = 4;
            // 
            // lblSecaoAtendimento
            // 
            this.lblSecaoAtendimento.AutoSize = true;
            this.lblSecaoAtendimento.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoAtendimento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoAtendimento.Location = new System.Drawing.Point(376, 16);
            this.lblSecaoAtendimento.Name = "lblSecaoAtendimento";
            this.lblSecaoAtendimento.TabIndex = 5;
            this.lblSecaoAtendimento.Text = "Atendimento";
            // 
            // lblFuncionarioAgendamento
            // 
            this.lblFuncionarioAgendamento.AutoSize = true;
            this.lblFuncionarioAgendamento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFuncionarioAgendamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblFuncionarioAgendamento.Location = new System.Drawing.Point(376, 50);
            this.lblFuncionarioAgendamento.Name = "lblFuncionarioAgendamento";
            this.lblFuncionarioAgendamento.TabIndex = 6;
            this.lblFuncionarioAgendamento.Text = "Funcionário responsável (opcional)";
            // 
            // cmbFuncionarioAgendamento
            // 
            this.cmbFuncionarioAgendamento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFuncionarioAgendamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFuncionarioAgendamento.FormattingEnabled = true;
            this.cmbFuncionarioAgendamento.Location = new System.Drawing.Point(376, 72);
            this.cmbFuncionarioAgendamento.Name = "cmbFuncionarioAgendamento";
            this.cmbFuncionarioAgendamento.Size = new System.Drawing.Size(320, 27);
            this.cmbFuncionarioAgendamento.TabIndex = 7;
            // 
            // lblStatusAgendamento
            // 
            this.lblStatusAgendamento.AutoSize = true;
            this.lblStatusAgendamento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatusAgendamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblStatusAgendamento.Location = new System.Drawing.Point(376, 110);
            this.lblStatusAgendamento.Name = "lblStatusAgendamento";
            this.lblStatusAgendamento.TabIndex = 8;
            this.lblStatusAgendamento.Text = "Status";
            // 
            // cmbStatusAgendamento
            // 
            this.cmbStatusAgendamento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStatusAgendamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatusAgendamento.FormattingEnabled = true;
            this.cmbStatusAgendamento.Location = new System.Drawing.Point(376, 132);
            this.cmbStatusAgendamento.Name = "cmbStatusAgendamento";
            this.cmbStatusAgendamento.Size = new System.Drawing.Size(200, 27);
            this.cmbStatusAgendamento.TabIndex = 9;
            // 
            // lblSecaoData
            // 
            this.lblSecaoData.AutoSize = true;
            this.lblSecaoData.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoData.Location = new System.Drawing.Point(24, 176);
            this.lblSecaoData.Name = "lblSecaoData";
            this.lblSecaoData.TabIndex = 10;
            this.lblSecaoData.Text = "Data e horário";
            // 
            // lblDataAgendamento
            // 
            this.lblDataAgendamento.AutoSize = true;
            this.lblDataAgendamento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataAgendamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblDataAgendamento.Location = new System.Drawing.Point(24, 208);
            this.lblDataAgendamento.Name = "lblDataAgendamento";
            this.lblDataAgendamento.TabIndex = 11;
            this.lblDataAgendamento.Text = "Data";
            // 
            // dtpDataAgendamento
            // 
            this.dtpDataAgendamento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDataAgendamento.Location = new System.Drawing.Point(24, 230);
            this.dtpDataAgendamento.Name = "dtpDataAgendamento";
            this.dtpDataAgendamento.Size = new System.Drawing.Size(320, 26);
            this.dtpDataAgendamento.TabIndex = 12;
            this.dtpDataAgendamento.ValueChanged += new System.EventHandler(this.dtpDataAgendamento_ValueChanged);
            // 
            // lblHorarioAgendamento
            // 
            this.lblHorarioAgendamento.AutoSize = true;
            this.lblHorarioAgendamento.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHorarioAgendamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblHorarioAgendamento.Location = new System.Drawing.Point(376, 208);
            this.lblHorarioAgendamento.Name = "lblHorarioAgendamento";
            this.lblHorarioAgendamento.TabIndex = 13;
            this.lblHorarioAgendamento.Text = "Horário";
            // 
            // cmbHorarioAgendamento
            // 
            this.cmbHorarioAgendamento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbHorarioAgendamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbHorarioAgendamento.FormattingEnabled = true;
            this.cmbHorarioAgendamento.Location = new System.Drawing.Point(376, 230);
            this.cmbHorarioAgendamento.Name = "cmbHorarioAgendamento";
            this.cmbHorarioAgendamento.Size = new System.Drawing.Size(200, 27);
            this.cmbHorarioAgendamento.TabIndex = 14;
            // 
            // lblDicaHorario
            // 
            this.lblDicaHorario.AutoSize = true;
            this.lblDicaHorario.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDicaHorario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblDicaHorario.Location = new System.Drawing.Point(24, 264);
            this.lblDicaHorario.Name = "lblDicaHorario";
            this.lblDicaHorario.TabIndex = 15;
            this.lblDicaHorario.Text = "Seg. a sex.: 08h às 18h  •  Sábado: 08h às 14h  •  Domingo: fechado  •  Intervalos de 30 min";
            // 
            // lblObservacoes
            // 
            this.lblObservacoes.AutoSize = true;
            this.lblObservacoes.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObservacoes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblObservacoes.Location = new System.Drawing.Point(24, 294);
            this.lblObservacoes.Name = "lblObservacoes";
            this.lblObservacoes.TabIndex = 16;
            this.lblObservacoes.Text = "Observações";
            // 
            // txtObservacoesAgendamento
            // 
            this.txtObservacoesAgendamento.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtObservacoesAgendamento.Multiline = true;
            this.txtObservacoesAgendamento.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtObservacoesAgendamento.Location = new System.Drawing.Point(24, 316);
            this.txtObservacoesAgendamento.Name = "txtObservacoesAgendamento";
            this.txtObservacoesAgendamento.Size = new System.Drawing.Size(672, 50);
            this.txtObservacoesAgendamento.TabIndex = 17;
            // 
            // btnSalvarAgendamento
            // 
            this.btnSalvarAgendamento.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnSalvarAgendamento.Location = new System.Drawing.Point(360, 378);
            this.btnSalvarAgendamento.Name = "btnSalvarAgendamento";
            this.btnSalvarAgendamento.Size = new System.Drawing.Size(108, 36);
            this.btnSalvarAgendamento.TabIndex = 18;
            this.btnSalvarAgendamento.Tag = "primario";
            this.btnSalvarAgendamento.Text = "Salvar";
            this.btnSalvarAgendamento.UseVisualStyleBackColor = false;
            this.btnSalvarAgendamento.Click += new System.EventHandler(this.btnSalvarAgendamento_Click);
            // 
            // btnLimparAgendamento
            // 
            this.btnLimparAgendamento.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnLimparAgendamento.Location = new System.Drawing.Point(478, 378);
            this.btnLimparAgendamento.Name = "btnLimparAgendamento";
            this.btnLimparAgendamento.Size = new System.Drawing.Size(108, 36);
            this.btnLimparAgendamento.TabIndex = 19;
            this.btnLimparAgendamento.Tag = "secundario";
            this.btnLimparAgendamento.Text = "Limpar";
            this.btnLimparAgendamento.UseVisualStyleBackColor = false;
            this.btnLimparAgendamento.Click += new System.EventHandler(this.btnLimparAgendamento_Click_1);
            // 
            // btnVoltarAgendamento
            // 
            this.btnVoltarAgendamento.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarAgendamento.Location = new System.Drawing.Point(596, 378);
            this.btnVoltarAgendamento.Name = "btnVoltarAgendamento";
            this.btnVoltarAgendamento.Size = new System.Drawing.Size(100, 36);
            this.btnVoltarAgendamento.TabIndex = 20;
            this.btnVoltarAgendamento.Tag = "neutro";
            this.btnVoltarAgendamento.Text = "Voltar";
            this.btnVoltarAgendamento.UseVisualStyleBackColor = false;
            this.btnVoltarAgendamento.Click += new System.EventHandler(this.btnVoltarAgendamento_Click_1);
            // 
            // FrmCadastrarAgendamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(760, 552);
            this.Controls.Add(this.pnlDados);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmCadastrarAgendamento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Agendamento";
            this.Load += new System.EventHandler(this.FrmCadastrarAgendamento_Load);
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlDados.ResumeLayout(false);
            this.pnlDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlDados;
        private System.Windows.Forms.Label lblSecaoCliente;
        private System.Windows.Forms.Label lblClienteAgendamento;
        private System.Windows.Forms.ComboBox cmbClienteAgendamento;
        private System.Windows.Forms.Label lblPetAgendamento;
        private System.Windows.Forms.ComboBox cmbPetAgendamento;
        private System.Windows.Forms.Label lblSecaoAtendimento;
        private System.Windows.Forms.Label lblFuncionarioAgendamento;
        private System.Windows.Forms.ComboBox cmbFuncionarioAgendamento;
        private System.Windows.Forms.Label lblStatusAgendamento;
        private System.Windows.Forms.ComboBox cmbStatusAgendamento;
        private System.Windows.Forms.Label lblSecaoData;
        private System.Windows.Forms.Label lblDataAgendamento;
        private System.Windows.Forms.DateTimePicker dtpDataAgendamento;
        private System.Windows.Forms.Label lblHorarioAgendamento;
        private System.Windows.Forms.ComboBox cmbHorarioAgendamento;
        private System.Windows.Forms.Label lblDicaHorario;
        private System.Windows.Forms.Label lblObservacoes;
        private System.Windows.Forms.TextBox txtObservacoesAgendamento;
        private System.Windows.Forms.Button btnSalvarAgendamento;
        private System.Windows.Forms.Button btnLimparAgendamento;
        private System.Windows.Forms.Button btnVoltarAgendamento;
    }
}
