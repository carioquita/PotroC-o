﻿namespace PotroCao.Formularios
{
    partial class FrmCadastrarPet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.pnlDados = new System.Windows.Forms.Panel();
            this.lblSecaoPet = new System.Windows.Forms.Label();
            this.lblNomePet = new System.Windows.Forms.Label();
            this.txtNomePet = new System.Windows.Forms.TextBox();
            this.lblEspecie = new System.Windows.Forms.Label();
            this.cmbEspecie = new System.Windows.Forms.ComboBox();
            this.lblRacaPet = new System.Windows.Forms.Label();
            this.txtRacaPet = new System.Windows.Forms.TextBox();
            this.lblDonoPet = new System.Windows.Forms.Label();
            this.cmbDonoPet = new System.Windows.Forms.ComboBox();
            this.btnSalvarPet = new System.Windows.Forms.Button();
            this.btnLimparPet = new System.Windows.Forms.Button();
            this.btnVoltarPet = new System.Windows.Forms.Button();
            this.pnlCabecalho.SuspendLayout();
            this.pnlDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlCabecalho.Controls.Add(this.lblSubtitulo);
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCabecalho.Location = new System.Drawing.Point(0, 0);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(800, 84);
            this.pnlCabecalho.TabIndex = 0;
            this.pnlCabecalho.Tag = "cabecalho";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblTitulo.Location = new System.Drawing.Point(22, 14);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Cadastro de Pets";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtitulo.Location = new System.Drawing.Point(25, 50);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.TabIndex = 1;
            this.lblSubtitulo.Text = "Registre o animal e vincule ao tutor. Todos os campos são obrigatórios.";
            // 
            // pnlDados
            // 
            this.pnlDados.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlDados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlDados.Controls.Add(this.btnVoltarPet);
            this.pnlDados.Controls.Add(this.btnLimparPet);
            this.pnlDados.Controls.Add(this.btnSalvarPet);
            this.pnlDados.Controls.Add(this.cmbDonoPet);
            this.pnlDados.Controls.Add(this.lblDonoPet);
            this.pnlDados.Controls.Add(this.txtRacaPet);
            this.pnlDados.Controls.Add(this.lblRacaPet);
            this.pnlDados.Controls.Add(this.cmbEspecie);
            this.pnlDados.Controls.Add(this.lblEspecie);
            this.pnlDados.Controls.Add(this.txtNomePet);
            this.pnlDados.Controls.Add(this.lblNomePet);
            this.pnlDados.Controls.Add(this.lblSecaoPet);
            this.pnlDados.Location = new System.Drawing.Point(20, 100);
            this.pnlDados.Name = "pnlDados";
            this.pnlDados.Size = new System.Drawing.Size(600, 246);
            this.pnlDados.TabIndex = 1;
            this.pnlDados.Tag = "cartao";
            // 
            // lblSecaoPet
            // 
            this.lblSecaoPet.AutoSize = true;
            this.lblSecaoPet.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoPet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblSecaoPet.Location = new System.Drawing.Point(24, 16);
            this.lblSecaoPet.Name = "lblSecaoPet";
            this.lblSecaoPet.TabIndex = 0;
            this.lblSecaoPet.Text = "Dados do pet";
            // 
            // lblNomePet
            // 
            this.lblNomePet.AutoSize = true;
            this.lblNomePet.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblNomePet.Location = new System.Drawing.Point(24, 50);
            this.lblNomePet.Name = "lblNomePet";
            this.lblNomePet.TabIndex = 1;
            this.lblNomePet.Text = "Nome do pet";
            // 
            // txtNomePet
            // 
            this.txtNomePet.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomePet.Location = new System.Drawing.Point(24, 72);
            this.txtNomePet.MaxLength = 100;
            this.txtNomePet.Name = "txtNomePet";
            this.txtNomePet.Size = new System.Drawing.Size(264, 25);
            this.txtNomePet.TabIndex = 2;
            // 
            // lblEspecie
            // 
            this.lblEspecie.AutoSize = true;
            this.lblEspecie.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEspecie.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblEspecie.Location = new System.Drawing.Point(312, 50);
            this.lblEspecie.Name = "lblEspecie";
            this.lblEspecie.TabIndex = 3;
            this.lblEspecie.Text = "Espécie";
            // 
            // cmbEspecie
            // 
            this.cmbEspecie.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEspecie.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEspecie.FormattingEnabled = true;
            this.cmbEspecie.Items.AddRange(new object[] {
            "Cachorro",
            "Gato",
            "Ave",
            "Peixe",
            "Roedor",
            "Réptil",
            "Outro"});
            this.cmbEspecie.Location = new System.Drawing.Point(312, 72);
            this.cmbEspecie.Name = "cmbEspecie";
            this.cmbEspecie.Size = new System.Drawing.Size(264, 27);
            this.cmbEspecie.TabIndex = 4;
            // 
            // lblRacaPet
            // 
            this.lblRacaPet.AutoSize = true;
            this.lblRacaPet.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRacaPet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblRacaPet.Location = new System.Drawing.Point(24, 110);
            this.lblRacaPet.Name = "lblRacaPet";
            this.lblRacaPet.TabIndex = 5;
            this.lblRacaPet.Text = "Raça";
            // 
            // txtRacaPet
            // 
            this.txtRacaPet.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRacaPet.Location = new System.Drawing.Point(24, 132);
            this.txtRacaPet.MaxLength = 100;
            this.txtRacaPet.Name = "txtRacaPet";
            this.txtRacaPet.Size = new System.Drawing.Size(264, 25);
            this.txtRacaPet.TabIndex = 6;
            // 
            // lblDonoPet
            // 
            this.lblDonoPet.AutoSize = true;
            this.lblDonoPet.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDonoPet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(63)))), ((int)(((byte)(99)))));
            this.lblDonoPet.Location = new System.Drawing.Point(312, 110);
            this.lblDonoPet.Name = "lblDonoPet";
            this.lblDonoPet.TabIndex = 7;
            this.lblDonoPet.Text = "Tutor (dono do pet)";
            // 
            // cmbDonoPet
            // 
            this.cmbDonoPet.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDonoPet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDonoPet.FormattingEnabled = true;
            this.cmbDonoPet.Location = new System.Drawing.Point(312, 132);
            this.cmbDonoPet.Name = "cmbDonoPet";
            this.cmbDonoPet.Size = new System.Drawing.Size(264, 27);
            this.cmbDonoPet.TabIndex = 8;
            // 
            // btnSalvarPet
            // 
            this.btnSalvarPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnSalvarPet.Location = new System.Drawing.Point(240, 186);
            this.btnSalvarPet.Name = "btnSalvarPet";
            this.btnSalvarPet.Size = new System.Drawing.Size(108, 36);
            this.btnSalvarPet.TabIndex = 9;
            this.btnSalvarPet.Tag = "primario";
            this.btnSalvarPet.Text = "Salvar";
            this.btnSalvarPet.UseVisualStyleBackColor = false;
            this.btnSalvarPet.Click += new System.EventHandler(this.btnSalvarPet_Click);
            // 
            // btnLimparPet
            // 
            this.btnLimparPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnLimparPet.Location = new System.Drawing.Point(358, 186);
            this.btnLimparPet.Name = "btnLimparPet";
            this.btnLimparPet.Size = new System.Drawing.Size(108, 36);
            this.btnLimparPet.TabIndex = 10;
            this.btnLimparPet.Tag = "secundario";
            this.btnLimparPet.Text = "Limpar";
            this.btnLimparPet.UseVisualStyleBackColor = false;
            this.btnLimparPet.Click += new System.EventHandler(this.btnLimparPet_Click);
            // 
            // btnVoltarPet
            // 
            this.btnVoltarPet.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right));
            this.btnVoltarPet.Location = new System.Drawing.Point(476, 186);
            this.btnVoltarPet.Name = "btnVoltarPet";
            this.btnVoltarPet.Size = new System.Drawing.Size(100, 36);
            this.btnVoltarPet.TabIndex = 11;
            this.btnVoltarPet.Tag = "neutro";
            this.btnVoltarPet.Text = "Voltar";
            this.btnVoltarPet.UseVisualStyleBackColor = false;
            this.btnVoltarPet.Click += new System.EventHandler(this.btnVoltarPet_Click);
            // 
            // FrmCadastrarPet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(640, 366);
            this.Controls.Add(this.pnlDados);
            this.Controls.Add(this.pnlCabecalho);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmCadastrarPet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Cadastro de Pets";
            this.Load += new System.EventHandler(this.FrmCadastrarPet_Load);
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlDados.ResumeLayout(false);
            this.pnlDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel pnlDados;
        private System.Windows.Forms.Label lblSecaoPet;
        private System.Windows.Forms.Label lblNomePet;
        private System.Windows.Forms.TextBox txtNomePet;
        private System.Windows.Forms.Label lblEspecie;
        private System.Windows.Forms.ComboBox cmbEspecie;
        private System.Windows.Forms.Label lblRacaPet;
        private System.Windows.Forms.TextBox txtRacaPet;
        private System.Windows.Forms.Label lblDonoPet;
        private System.Windows.Forms.ComboBox cmbDonoPet;
        private System.Windows.Forms.Button btnSalvarPet;
        private System.Windows.Forms.Button btnLimparPet;
        private System.Windows.Forms.Button btnVoltarPet;
    }
}
