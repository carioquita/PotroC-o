﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace PotroCao
{
    // Caixa de mensagem com a identidade visual do PotroCão.
    // Funciona igual ao MessageBox.Show (mesmos parâmetros e mesmo retorno).
    public static class CaixaMensagem
    {
        public static DialogResult Show(string mensagem)
        {
            return Show(mensagem, "PotroCão", MessageBoxButtons.OK, DeduzirIcone(mensagem));
        }

        public static DialogResult Show(string mensagem, string titulo)
        {
            return Show(mensagem, titulo, MessageBoxButtons.OK, DeduzirIcone(mensagem));
        }

        // Quando a chamada não informa o ícone, escolhe pelo conteúdo da mensagem
        private static MessageBoxIcon DeduzirIcone(string mensagem)
        {
            string m = (mensagem ?? "").Trim().ToLower();

            if (m.StartsWith("erro")) return MessageBoxIcon.Error;
            if (m.Contains("sucesso") || m.Contains("atualizada") || m.Contains("atualizado"))
                return MessageBoxIcon.Information;
            if (m.StartsWith("selecione") || m.StartsWith("preencha") || m.StartsWith("informe") ||
                m.StartsWith("não") || m.StartsWith("nao") || m.StartsWith("escolha") ||
                m.StartsWith("digite") || m.Contains("inválid") || m.Contains("já "))
                return MessageBoxIcon.Warning;
            return MessageBoxIcon.Information;
        }

        public static DialogResult Show(string mensagem, string titulo, MessageBoxButtons botoes)
        {
            return Show(mensagem, titulo, botoes, MessageBoxIcon.None);
        }

        public static DialogResult Show(string mensagem, string titulo,
                                        MessageBoxButtons botoes, MessageBoxIcon icone)
        {
            try
            {
                using (FrmMensagem tela = new FrmMensagem(mensagem, titulo, botoes, icone))
                {
                    Form dono = Form.ActiveForm;

                    if (dono == null || !dono.Visible)
                    {
                        tela.StartPosition = FormStartPosition.CenterScreen;
                        return tela.ShowDialog();
                    }

                    return tela.ShowDialog(dono);
                }
            }
            catch
            {
                // Se algo der errado ao montar a tela personalizada, usa a caixa padrão do Windows
                return MessageBox.Show(mensagem, titulo, botoes, icone);
            }
        }

        private class FrmMensagem : Form
        {
            public FrmMensagem(string mensagem, string titulo, MessageBoxButtons botoes, MessageBoxIcon icone)
            {
                AutoScaleMode = AutoScaleMode.Dpi;
                AutoScaleDimensions = new SizeF(96F, 96F);
                Font = Tema.Fonte(10f);
                FormBorderStyle = FormBorderStyle.FixedDialog;
                MaximizeBox = false;
                MinimizeBox = false;
                ShowInTaskbar = false;
                StartPosition = FormStartPosition.CenterParent;
                Text = string.IsNullOrWhiteSpace(titulo) ? "PotroCão" : titulo;
                BackColor = Tema.Branco;
                KeyPreview = true;

                if (Tema.Icone != null)
                    Icon = Tema.Icone;

                // Cor e ícone conforme o tipo da mensagem
                Color cor;
                string glifo;
                string tituloInterno;

                if (icone == MessageBoxIcon.Error)
                {
                    cor = Tema.Magenta; glifo = Tema.IcErro; tituloInterno = "Algo deu errado";
                }
                else if (icone == MessageBoxIcon.Warning)
                {
                    cor = Tema.Dourado; glifo = Tema.IcAlerta; tituloInterno = "Atenção";
                }
                else if (icone == MessageBoxIcon.Question || botoes == MessageBoxButtons.YesNo)
                {
                    cor = Tema.Violeta; glifo = Tema.IcPergunta; tituloInterno = "Confirmação";
                }
                else
                {
                    cor = Tema.Violeta; glifo = Tema.IcInfo; tituloInterno = "PotroCão";
                }

                if (!string.IsNullOrWhiteSpace(titulo) && titulo != "PotroCão")
                    tituloInterno = titulo;

                // faixa superior colorida
                Panel faixa = new Panel { Dock = DockStyle.Top, Height = 5, BackColor = cor };

                // ícone
                Label lblIcone = new Label
                {
                    AutoSize = false,
                    Location = new Point(24, 28),
                    Size = new Size(44, 44),
                    TextAlign = ContentAlignment.MiddleCenter,
                    ForeColor = cor == Tema.Dourado ? Tema.DouradoTexto : cor,
                    BackColor = Color.FromArgb(30, cor),
                    Text = Tema.FonteIcones(18f) != null ? glifo : "!",
                    Font = Tema.FonteIcones(18f) ?? Tema.FonteForte(18f)
                };

                Label lblTitulo = new Label
                {
                    AutoSize = true,
                    Location = new Point(84, 26),
                    Font = Tema.FonteForte(13f),
                    ForeColor = Tema.RoxoProfundo,
                    Text = tituloInterno
                };

                // mede o texto (com quebra de linha) para dimensionar a caixa
                float escala = 1f;
                using (Graphics gTela = Graphics.FromHwnd(IntPtr.Zero))
                    escala = gTela.DpiX / 96f;

                Font fonteMensagem = Tema.Fonte(10.5f);
                Size medida = TextRenderer.MeasureText(mensagem ?? "", fonteMensagem,
                    new Size((int)(380 * escala), 0), TextFormatFlags.WordBreak);
                Size tamanhoTexto = new Size((int)Math.Ceiling(medida.Width / escala) + 4,
                                             (int)Math.Ceiling(medida.Height / escala) + 4);

                Label lblMensagem = new Label
                {
                    AutoSize = false,
                    Location = new Point(86, 58),
                    Size = tamanhoTexto,
                    Font = fonteMensagem,
                    ForeColor = Tema.Texto,
                    Text = mensagem ?? ""
                };

                Controls.Add(lblMensagem);
                Controls.Add(lblTitulo);
                Controls.Add(lblIcone);
                Controls.Add(faixa);

                // botões
                Panel rodape = new Panel { Dock = DockStyle.Bottom, Height = 64, BackColor = Tema.Marfim };
                Controls.Add(rodape);

                Button[] lista;

                if (botoes == MessageBoxButtons.YesNo)
                {
                    lista = new[]
                    {
                        CriarBotao("Não", DialogResult.No, "neutro"),
                        CriarBotao("Sim", DialogResult.Yes, "primario")
                    };
                    CancelButton = lista[0];
                    AcceptButton = lista[1];
                }
                else if (botoes == MessageBoxButtons.YesNoCancel)
                {
                    lista = new[]
                    {
                        CriarBotao("Cancelar", DialogResult.Cancel, "neutro"),
                        CriarBotao("Não", DialogResult.No, "secundario"),
                        CriarBotao("Sim", DialogResult.Yes, "primario")
                    };
                    CancelButton = lista[0];
                    AcceptButton = lista[2];
                }
                else if (botoes == MessageBoxButtons.OKCancel)
                {
                    lista = new[]
                    {
                        CriarBotao("Cancelar", DialogResult.Cancel, "neutro"),
                        CriarBotao("OK", DialogResult.OK, "primario")
                    };
                    CancelButton = lista[0];
                    AcceptButton = lista[1];
                }
                else
                {
                    lista = new[] { CriarBotao("OK", DialogResult.OK, "primario") };
                    AcceptButton = lista[0];
                    CancelButton = lista[0];
                }

                Size medidaTitulo = TextRenderer.MeasureText(tituloInterno, lblTitulo.Font);
                int larguraTitulo = (int)Math.Ceiling(medidaTitulo.Width / escala);

                int alturaConteudo = Math.Max(lblMensagem.Top + tamanhoTexto.Height + 24, 104);
                int largura = Math.Max(420, Math.Max(lblMensagem.Left + tamanhoTexto.Width,
                                                     lblTitulo.Left + larguraTitulo) + 32);

                ClientSize = new Size(largura, alturaConteudo + rodape.Height);

                int x = largura - 20;
                foreach (Button b in lista)
                {
                    x -= b.Width;
                    b.Location = new Point(x, 14);
                    b.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                    rodape.Controls.Add(b);
                    x -= 10;
                }

                foreach (Button b in lista)
                    Tema.EstilizarBotao(b);
            }

            private Button CriarBotao(string texto, DialogResult resultado, string papel)
            {
                return new Button
                {
                    Text = texto,
                    DialogResult = resultado,
                    Size = new Size(104, 36),
                    Tag = papel
                };
            }
        }
    }
}
