﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace PotroCao
{
    // =====================================================================
    //  IDENTIDADE VISUAL DO POTROCÃO
    //  Tudo o que é cor, fonte, botão, tabela e cartão fica centralizado aqui.
    //  Para mudar a aparência do sistema inteiro, altere somente esta classe.
    // =====================================================================
    public static class Tema
    {
        // ---------- PALETA OFICIAL ----------
        public static readonly Color RoxoProfundo = ColorTranslator.FromHtml("#26085F");
        public static readonly Color Violeta = ColorTranslator.FromHtml("#6320B5");
        public static readonly Color Magenta = ColorTranslator.FromHtml("#ED1672");
        public static readonly Color Dourado = ColorTranslator.FromHtml("#FFB900");
        public static readonly Color Marfim = ColorTranslator.FromHtml("#FFFDF7");

        // ---------- CORES AUXILIARES (neutros e variações) ----------
        public static readonly Color Branco = Color.White;
        public static readonly Color Texto = ColorTranslator.FromHtml("#2B2140");
        public static readonly Color TextoSuave = ColorTranslator.FromHtml("#6E6585");
        public static readonly Color Borda = ColorTranslator.FromHtml("#E4DCF0");
        public static readonly Color LilasClaro = ColorTranslator.FromHtml("#F6F2FC");
        public static readonly Color LilasMedio = ColorTranslator.FromHtml("#E9DFF8");
        public static readonly Color VioletaHover = ColorTranslator.FromHtml("#7533CC");
        public static readonly Color VioletaPressionado = ColorTranslator.FromHtml("#4C1590");
        public static readonly Color MagentaHover = ColorTranslator.FromHtml("#F23D88");
        public static readonly Color MagentaPressionado = ColorTranslator.FromHtml("#C80F5E");
        public static readonly Color AlertaFundo = ColorTranslator.FromHtml("#FDECF3");
        public static readonly Color DouradoFundo = ColorTranslator.FromHtml("#FFF5D6");
        public static readonly Color DouradoTexto = ColorTranslator.FromHtml("#7A5600");
        public static readonly Color CinzaFundo = ColorTranslator.FromHtml("#F0EDF4");
        public static readonly Color MenuHover = ColorTranslator.FromHtml("#3A1680");
        public static readonly Color MenuTextoSecao = ColorTranslator.FromHtml("#B9A6E0");
        public static readonly Color Sucesso = ColorTranslator.FromHtml("#1E9E6A");

        // ---------- TIPOGRAFIA ----------
        public const string FonteBase = "Segoe UI";
        public const string FonteSemibold = "Segoe UI Semibold";

        private static readonly Dictionary<string, Font> cacheFontes = new Dictionary<string, Font>();

        public static Font Fonte(float tamanho, FontStyle estilo = FontStyle.Regular)
        {
            return ObterFonte(FonteBase, tamanho, estilo);
        }

        public static Font FonteForte(float tamanho)
        {
            return ObterFonte(FonteSemibold, tamanho, FontStyle.Regular);
        }

        private static Font ObterFonte(string familia, float tamanho, FontStyle estilo)
        {
            string chave = familia + tamanho + estilo;

            if (!cacheFontes.ContainsKey(chave))
                cacheFontes[chave] = new Font(familia, tamanho, estilo);

            return cacheFontes[chave];
        }

        // Fonte de ícones do Windows 10/11. Se não existir, os botões ficam só com texto.
        private static Font fonteIcones;
        private static bool fonteIconesVerificada = false;

        public static Font FonteIcones(float tamanho)
        {
            if (!fonteIconesVerificada)
            {
                fonteIconesVerificada = true;

                using (InstalledFontCollection fontes = new InstalledFontCollection())
                {
                    foreach (FontFamily familia in fontes.Families)
                    {
                        if (familia.Name == "Segoe MDL2 Assets")
                        {
                            fonteIcones = new Font("Segoe MDL2 Assets", 10f);
                            break;
                        }
                    }
                }
            }

            if (fonteIcones == null)
                return null;

            return ObterFonte("Segoe MDL2 Assets", tamanho, FontStyle.Regular);
        }

        // ---------- ÍCONES (Segoe MDL2 Assets) ----------
        public const string IcSalvar = "\uE74E";
        public const string IcLimpar = "\uE894";
        public const string IcVoltar = "\uE72B";
        public const string IcPesquisar = "\uE721";
        public const string IcEditar = "\uE70F";
        public const string IcNovo = "\uE710";
        public const string IcAtualizar = "\uE72C";
        public const string IcInativar = "\uE711";
        public const string IcReativar = "\uE73E";
        public const string IcExportar = "\uE896";
        public const string IcVer = "\uE890";
        public const string IcLista = "\uE8FD";
        public const string IcCliente = "\uE77B";
        public const string IcPessoas = "\uE716";
        public const string IcAgenda = "\uE787";
        public const string IcProduto = "\uE7BF";
        public const string IcCategoria = "\uE8EC";
        public const string IcServico = "\uE90F";
        public const string IcEstoque = "\uE7B8";
        public const string IcEquipe = "\uE902";
        public const string IcInicio = "\uE80F";
        public const string IcAlerta = "\uE7BA";
        public const string IcInfo = "\uE946";
        public const string IcPergunta = "\uE9CE";
        public const string IcErro = "\uEA39";
        public const string IcCoracao = "\uEB51";
        public const string IcRelogio = "\uE823";
        public const string IcPet = "\U0001F43E"; // pegada (Segoe UI Emoji)

        // ---------- IMAGENS DA MARCA (embutidas no projeto, pasta Recursos) ----------
        private static Image logo, emblema;
        private static Icon icone;

        public static Image Logo { get { return logo ?? (logo = CarregarImagem("logo.png")); } }
        public static Image Emblema { get { return emblema ?? (emblema = CarregarImagem("emblema.png")); } }

        public static Icon Icone
        {
            get
            {
                if (icone == null)
                {
                    try
                    {
                        Stream s = Assembly.GetExecutingAssembly()
                            .GetManifestResourceStream("PotroCao.Recursos.potrocao.ico");
                        if (s != null)
                            icone = new Icon(s);
                    }
                    catch { icone = null; }
                }
                return icone;
            }
        }

        private static Image CarregarImagem(string arquivo)
        {
            try
            {
                Stream s = Assembly.GetExecutingAssembly()
                    .GetManifestResourceStream("PotroCao.Recursos." + arquivo);
                return s == null ? null : Image.FromStream(s);
            }
            catch
            {
                return null;
            }
        }

        // =================================================================
        //  APLICAR O TEMA EM UM FORMULÁRIO INTEIRO
        //  Basta chamar Tema.Aplicar(this) no construtor do formulário,
        //  logo depois do InitializeComponent().
        // =================================================================
        public static void Aplicar(Form form)
        {
            form.BackColor = Marfim;

            if (Icone != null)
                form.Icon = Icone;

            AplicarEmControles(form.Controls);
        }

        private static void AplicarEmControles(Control.ControlCollection controles)
        {
            foreach (Control c in controles)
            {
                string tag = Convert.ToString(c.Tag);

                if (c is Button)
                    EstilizarBotao((Button)c);
                else if (c is DataGridView)
                    EstilizarGrade((DataGridView)c);
                else if (c is TextBox)
                    EstilizarCampo(c);
                else if (c is MaskedTextBox)
                    EstilizarCampo(c);
                else if (c is NumericUpDown)
                    EstilizarCampo(c);
                else if (c is ComboBox)
                {
                    ((ComboBox)c).FlatStyle = FlatStyle.Flat;
                    EstilizarCampo(c);
                }
                else if (c is DateTimePicker)
                {
                    DateTimePicker d = (DateTimePicker)c;
                    d.CalendarTitleBackColor = Violeta;
                    d.CalendarTitleForeColor = Branco;
                    d.CalendarMonthBackground = Branco;
                }
                else if (c is Panel && tag == "cartao")
                    EstilizarCartao((Panel)c);
                else if (c is Panel && tag == "cabecalho")
                    EstilizarCabecalho((Panel)c);
                else if (c is Label && c.ForeColor == SystemColors.ControlText)
                    c.ForeColor = Texto;

                if (c.HasChildren)
                    AplicarEmControles(c.Controls);
            }
        }

        // ---------- CAMPOS ----------
        public static void EstilizarCampo(Control campo)
        {
            if (campo is TextBox)
                ((TextBox)campo).BorderStyle = BorderStyle.FixedSingle;

            if (campo is MaskedTextBox)
                ((MaskedTextBox)campo).BorderStyle = BorderStyle.FixedSingle;

            if (campo is NumericUpDown)
                ((NumericUpDown)campo).BorderStyle = BorderStyle.FixedSingle;

            campo.BackColor = Branco;
            campo.ForeColor = Texto;

            // Indicação de foco: o campo fica lilás clarinho enquanto está sendo editado
            campo.Enter += (s, e) => { if (campo.Enabled) campo.BackColor = LilasClaro; };
            campo.Leave += (s, e) => { campo.BackColor = Branco; };
        }

        // ---------- TABELAS ----------
        public static void EstilizarGrade(DataGridView g)
        {
            float escala = Escala(g);

            g.BorderStyle = BorderStyle.None;
            g.BackgroundColor = Branco;
            g.GridColor = Borda;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.RowHeadersVisible = false;
            g.AllowUserToResizeRows = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.MultiSelect = false;

            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            g.ColumnHeadersHeight = (int)(40 * escala);

            g.ColumnHeadersDefaultCellStyle.BackColor = RoxoProfundo;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Branco;
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = RoxoProfundo;
            g.ColumnHeadersDefaultCellStyle.SelectionForeColor = Branco;
            g.ColumnHeadersDefaultCellStyle.Font = FonteForte(10f);
            g.ColumnHeadersDefaultCellStyle.Padding = new Padding(6, 0, 6, 0);
            g.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            g.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;

            g.DefaultCellStyle.BackColor = Branco;
            g.DefaultCellStyle.ForeColor = Texto;
            g.DefaultCellStyle.Font = Fonte(10f);
            g.DefaultCellStyle.SelectionBackColor = Violeta;
            g.DefaultCellStyle.SelectionForeColor = Branco;
            g.DefaultCellStyle.Padding = new Padding(6, 0, 6, 0);

            g.AlternatingRowsDefaultCellStyle.BackColor = LilasClaro;

            g.RowTemplate.Height = (int)(34 * escala);

            // Formata datas, horários e valores de qualquer tabela para leitura em português
            g.DataBindingComplete += (s, e) =>
            {
                foreach (DataGridViewColumn col in g.Columns)
                {
                    // coluna de código mais estreita (quando a tela não definiu outra largura)
                    if (col.HeaderText == "Código" && col.FillWeight == 100f)
                        col.FillWeight = 45f;

                    if (!string.IsNullOrEmpty(col.DefaultCellStyle.Format))
                        continue;

                    if (col.ValueType == typeof(DateTime))
                        col.DefaultCellStyle.Format = "dd/MM/yyyy";
                    else if (col.ValueType == typeof(TimeSpan))
                        col.DefaultCellStyle.Format = @"hh\:mm";
                    else if (col.ValueType == typeof(decimal))
                    {
                        col.DefaultCellStyle.Format = "N2";
                        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    }
                }
            };
        }

        // ---------- CARTÕES ----------
        public static void EstilizarCartao(Panel p)
        {
            p.BackColor = Branco;

            p.Paint += (s, e) =>
            {
                float esc = e.Graphics.DpiX / 96f;
                int raio = (int)(12 * esc);
                Rectangle r = new Rectangle(0, 0, p.Width - 1, p.Height - 1);

                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

                // pinta os cantos com a cor do fundo para parecer arredondado
                using (GraphicsPath caminho = Arredondado(r, raio))
                using (Region fora = new Region(new Rectangle(0, 0, p.Width, p.Height)))
                {
                    fora.Exclude(caminho);
                    Color fundo = p.Parent != null ? p.Parent.BackColor : Marfim;
                    using (SolidBrush b = new SolidBrush(fundo))
                        e.Graphics.FillRegion(b, fora);

                    using (Pen borda = new Pen(Borda, 1f))
                        e.Graphics.DrawPath(borda, caminho);
                }
            };

            p.Resize += (s, e) => p.Invalidate();
        }

        // ---------- CABEÇALHO DAS TELAS ----------
        public static void EstilizarCabecalho(Panel p)
        {
            p.BackColor = Branco;

            p.Paint += (s, e) =>
            {
                Graphics g = e.Graphics;
                float esc = g.DpiX / 96f;
                int h = p.Height;

                // linha inferior suave
                using (Pen linha = new Pen(Borda, 1f))
                    g.DrawLine(linha, 0, h - 1, p.Width, h - 1);

                // detalhe com as cores da marca (como as linhas do "PET SHOP" da logo)
                int x = (int)(24 * esc);
                int alt = (int)(3 * esc);
                int y = h - alt;
                using (SolidBrush v = new SolidBrush(Violeta))
                    g.FillRectangle(v, x, y, (int)(70 * esc), alt);
                using (SolidBrush m = new SolidBrush(Magenta))
                    g.FillRectangle(m, x + (int)(70 * esc), y, (int)(36 * esc), alt);
                using (SolidBrush d = new SolidBrush(Dourado))
                    g.FillRectangle(d, x + (int)(106 * esc), y, (int)(18 * esc), alt);

                // emblema da logo à direita, sem distorcer
                Image img = Emblema;
                if (img != null)
                {
                    int lado = h - (int)(20 * esc);
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.DrawImage(img, p.Width - lado - (int)(24 * esc), (int)(9 * esc), lado, lado);
                }
            };

            p.Resize += (s, e) => p.Invalidate();
        }

        // =================================================================
        //  BOTÕES
        //  O papel de cada botão vem da propriedade Tag (definida no Designer):
        //    primario   -> violeta      (Salvar, Pesquisar, Editar)
        //    especial   -> magenta      (Novo cadastro)
        //    secundario -> contorno     (Atualizar, filtros, Limpar)
        //    alerta     -> magenta claro (Inativar, Cancelar)
        //    confirmar  -> dourado      (Reativar, Exportar)
        //    neutro     -> cinza        (Voltar)
        //    menu       -> menu lateral
        //    atalho     -> cartão de acesso rápido do painel
        //  Se a Tag estiver vazia, o papel é deduzido pelo texto do botão.
        // =================================================================
        private class EstadoBotao
        {
            public bool Hover;
            public bool Pressionado;
        }

        private static Button menuSelecionado;

        public static void SelecionarMenu(Button botao)
        {
            Button anterior = menuSelecionado;
            menuSelecionado = botao;

            if (anterior != null) anterior.Invalidate();
            if (botao != null) botao.Invalidate();
        }

        public static void EstilizarBotao(Button b)
        {
            string papel = Convert.ToString(b.Tag);

            if (string.IsNullOrEmpty(papel))
                papel = DeduzirPapel(b.Text);

            b.Tag = papel;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = Color.Transparent;
            b.FlatAppearance.MouseDownBackColor = Color.Transparent;
            b.UseVisualStyleBackColor = false;
            b.Cursor = Cursors.Hand;
            b.Font = papel == "menu" ? Fonte(10f) : FonteForte(9.75f);

            EstadoBotao estado = new EstadoBotao();

            b.MouseEnter += (s, e) => { estado.Hover = true; b.Invalidate(); };
            b.MouseLeave += (s, e) => { estado.Hover = false; estado.Pressionado = false; b.Invalidate(); };
            b.MouseDown += (s, e) => { estado.Pressionado = true; b.Invalidate(); };
            b.MouseUp += (s, e) => { estado.Pressionado = false; b.Invalidate(); };
            b.EnabledChanged += (s, e) => b.Invalidate();
            b.TextChanged += (s, e) => b.Invalidate();
            b.GotFocus += (s, e) => b.Invalidate();
            b.LostFocus += (s, e) => b.Invalidate();

            b.Paint += (s, e) => DesenharBotao(b, Convert.ToString(b.Tag), estado, e.Graphics);

            if (papel != "menu" && !papel.StartsWith("atalho") && b.Width < 60)
            {
                ToolTip dica = new ToolTip();
                dica.SetToolTip(b, b.Text);
            }
        }

        private static string DeduzirPapel(string texto)
        {
            string t = (texto ?? "").ToLower();

            if (t.StartsWith("nov")) return "especial";
            if (t.Contains("salvar") || t.Contains("pesquisar") || t.Contains("editar")) return "primario";
            if (t.Contains("inativar") || t.Contains("cancelar") || t.Contains("excluir")) return "alerta";
            if (t.Contains("reativar") || t.Contains("exportar")) return "confirmar";
            if (t.Contains("voltar")) return "neutro";
            return "secundario";
        }

        public static string IconeDoTexto(string texto)
        {
            string t = (texto ?? "").ToLower();

            if (t.StartsWith("nov")) return IcNovo;
            if (t.Contains("salvar")) return IcSalvar;
            if (t.Contains("pesquisar")) return IcPesquisar;
            if (t.Contains("editar")) return IcEditar;
            if (t.Contains("inativar") || t.Contains("cancelar") || t.Contains("excluir")) return IcInativar;
            if (t.Contains("reativar")) return IcReativar;
            if (t.Contains("exportar")) return IcExportar;
            if (t.Contains("voltar")) return IcVoltar;
            if (t.Contains("limpar")) return IcLimpar;
            if (t.Contains("atualizar")) return IcAtualizar;
            if (t.Contains("categoria")) return IcCategoria;
            if (t.Contains("estoque")) return IcEstoque;
            if (t.Contains("registrar")) return IcReativar;
            if (t.Contains("ver ") || t.Contains("inativ") || t.Contains("cancelad")) return IcVer;
            return null;
        }

        private static void DesenharBotao(Button b, string papel, EstadoBotao estado, Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            float esc = g.DpiX / 96f;
            Color fundoPai = b.Parent != null ? b.Parent.BackColor : Marfim;
            g.Clear(fundoPai);

            if (papel == "menu")
            {
                DesenharBotaoMenu(b, estado, g, esc);
                return;
            }

            if (papel.StartsWith("atalho"))
            {
                DesenharAtalho(b, papel, estado, g, esc);
                return;
            }

            Color fundo, texto, borda;
            CoresDoPapel(papel, estado, out fundo, out texto, out borda);

            if (!b.Enabled)
            {
                fundo = CinzaFundo;
                texto = ColorTranslator.FromHtml("#A9A3B5");
                borda = CinzaFundo;
            }

            Rectangle r = new Rectangle(0, 0, b.Width - 1, b.Height - 1);
            int raio = (int)(8 * esc);

            using (GraphicsPath caminho = Arredondado(r, raio))
            {
                using (SolidBrush pincel = new SolidBrush(fundo))
                    g.FillPath(pincel, caminho);

                if (borda != fundo)
                    using (Pen caneta = new Pen(borda, 1f))
                        g.DrawPath(caneta, caminho);
            }

            // ícone + texto centralizados
            string icone = IconeDoTexto(b.Text);
            Font fIcone = icone != null ? FonteIcones(10f) : null;

            // botão estreito (ex.: Atualizar ao lado do Pesquisar): mostra só o ícone
            if (b.Width < (int)(60 * esc))
            {
                bool temFonte = fIcone != null;
                TextRenderer.DrawText(g, temFonte ? icone : "\u21BB", temFonte ? FonteIcones(11f) : Fonte(13f),
                    new Rectangle(0, 0, b.Width, b.Height), texto,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                return;
            }

            Size tamTexto = TextRenderer.MeasureText(g, b.Text, b.Font, Size.Empty, TextFormatFlags.NoPadding);
            int espacoIcone = fIcone != null ? (int)(22 * esc) : 0;
            int larguraTotal = tamTexto.Width + espacoIcone;
            int xInicio = Math.Max((int)(6 * esc), (b.Width - larguraTotal) / 2);

            if (fIcone != null)
            {
                Rectangle ri = new Rectangle(xInicio, 0, espacoIcone, b.Height);
                TextRenderer.DrawText(g, icone, fIcone, ri, texto,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPadding);
            }

            Rectangle rt = new Rectangle(xInicio + espacoIcone, 0, b.Width - xInicio - espacoIcone, b.Height);
            TextRenderer.DrawText(g, b.Text, b.Font, rt, texto,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPadding |
                TextFormatFlags.EndEllipsis);
        }

        private static void CoresDoPapel(string papel, EstadoBotao st, out Color fundo, out Color texto, out Color borda)
        {
            switch (papel)
            {
                case "primario":
                    fundo = st.Pressionado ? VioletaPressionado : st.Hover ? VioletaHover : Violeta;
                    texto = Branco; borda = fundo;
                    break;

                case "especial":
                    fundo = st.Pressionado ? MagentaPressionado : st.Hover ? MagentaHover : Magenta;
                    texto = Branco; borda = fundo;
                    break;

                case "alerta":
                    fundo = st.Pressionado ? ColorTranslator.FromHtml("#F9CFE1")
                          : st.Hover ? ColorTranslator.FromHtml("#FBDDEA") : AlertaFundo;
                    texto = MagentaPressionado;
                    borda = ColorTranslator.FromHtml("#F6BCD5");
                    break;

                case "confirmar":
                    fundo = st.Pressionado ? ColorTranslator.FromHtml("#FFE08A")
                          : st.Hover ? ColorTranslator.FromHtml("#FFEBB0") : DouradoFundo;
                    texto = DouradoTexto;
                    borda = ColorTranslator.FromHtml("#FFD666");
                    break;

                case "neutro":
                    fundo = st.Pressionado ? ColorTranslator.FromHtml("#DCD6E3")
                          : st.Hover ? ColorTranslator.FromHtml("#E6E1EC") : CinzaFundo;
                    texto = Texto;
                    borda = fundo;
                    break;

                default: // secundario
                    fundo = st.Pressionado ? LilasMedio : st.Hover ? LilasClaro : Branco;
                    texto = Violeta;
                    borda = st.Hover ? Violeta : ColorTranslator.FromHtml("#CDBDEA");
                    break;
            }
        }

        private static void DesenharBotaoMenu(Button b, EstadoBotao st, Graphics g, float esc)
        {
            bool selecionado = b == menuSelecionado;
            Rectangle r = new Rectangle((int)(10 * esc), 1, b.Width - (int)(20 * esc), b.Height - 2);

            if (selecionado || st.Hover)
            {
                using (GraphicsPath caminho = Arredondado(r, (int)(8 * esc)))
                using (SolidBrush pincel = new SolidBrush(selecionado ? Violeta : MenuHover))
                    g.FillPath(pincel, caminho);
            }

            if (selecionado)
            {
                using (SolidBrush ouro = new SolidBrush(Dourado))
                    g.FillRectangle(ouro, r.X, r.Y + (int)(8 * esc), (int)(3 * esc), r.Height - (int)(16 * esc));
            }

            string icone = IconeDoMenu(b.Name);
            int xTexto = r.X + (int)(16 * esc);

            if (icone == IcPet)
            {
                Rectangle ri = new Rectangle(r.X + (int)(14 * esc), 0, (int)(24 * esc), b.Height);
                TextRenderer.DrawText(g, icone, Fonte(10.5f), ri, Dourado,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPadding);
                xTexto = r.X + (int)(44 * esc);
            }
            else if (icone != null && FonteIcones(11f) != null)
            {
                Rectangle ri = new Rectangle(r.X + (int)(16 * esc), 0, (int)(24 * esc), b.Height);
                TextRenderer.DrawText(g, icone, FonteIcones(11f), ri,
                    selecionado ? Dourado : MenuTextoSecao,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPadding);
                xTexto = r.X + (int)(44 * esc);
            }

            Rectangle rt = new Rectangle(xTexto, 0, b.Width - xTexto, b.Height);
            TextRenderer.DrawText(g, b.Text, b.Font, rt, Branco,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }

        private static string IconeDoMenu(string nome)
        {
            switch (nome)
            {
                case "btnInicio": return IcInicio;
                case "btnClientes": return IcNovo;
                case "btnConsultarClientes": return IcPessoas;
                case "btnPets": return IcPet;
                case "btnConsultarPets": return IcLista;
                case "btnAgendamentos": return IcAgenda;
                case "btnConsultarAgendamentos": return IcRelogio;
                case "btnFuncionarios": return IcCliente;
                case "btnConsultarFuncionarios": return IcEquipe;
                case "btnProdutos": return IcProduto;
                case "btnCategorias": return IcCategoria;
                case "btnServicos": return IcServico;
                case "btnEstoque": return IcEstoque;
                default: return null;
            }
        }

        // Cartão de atalho do painel. Tag no formato "atalho:<cor>" (violeta, magenta, dourado, roxo)
        private static void DesenharAtalho(Button b, string papel, EstadoBotao st, Graphics g, float esc)
        {
            Color cor = Violeta;
            if (papel.EndsWith("magenta")) cor = Magenta;
            else if (papel.EndsWith("dourado")) cor = Dourado;
            else if (papel.EndsWith("roxo")) cor = RoxoProfundo;

            Rectangle r = new Rectangle(0, 0, b.Width - 1, b.Height - 1);

            using (GraphicsPath caminho = Arredondado(r, (int)(12 * esc)))
            {
                using (SolidBrush fundo = new SolidBrush(st.Hover ? LilasClaro : Branco))
                    g.FillPath(fundo, caminho);
                using (Pen borda = new Pen(st.Hover ? cor : Borda, st.Hover ? 1.5f : 1f))
                    g.DrawPath(borda, caminho);
            }

            // círculo do ícone
            int diam = (int)(40 * esc);
            Rectangle circ = new Rectangle((int)(16 * esc), (b.Height - diam) / 2, diam, diam);
            using (SolidBrush fundoIcone = new SolidBrush(Color.FromArgb(32, cor)))
                g.FillEllipse(fundoIcone, circ);

            string icone = IconeDoMenu(Convert.ToString(b.AccessibleName));
            if (icone == IcPet)
                TextRenderer.DrawText(g, icone, Fonte(14f), circ, cor,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            else if (icone != null && FonteIcones(14f) != null)
                TextRenderer.DrawText(g, icone, FonteIcones(14f), circ, cor == Dourado ? DouradoTexto : cor,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);

            Rectangle rt = new Rectangle(circ.Right + (int)(12 * esc), 0,
                b.Width - circ.Right - (int)(20 * esc), b.Height);
            TextRenderer.DrawText(g, b.Text, FonteForte(10.5f), rt, Texto,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.WordBreak);
        }

        // ---------- UTILITÁRIOS DE DESENHO ----------
        public static GraphicsPath Arredondado(Rectangle r, int raio)
        {
            GraphicsPath p = new GraphicsPath();
            int d = Math.Max(2, raio * 2);

            if (d > r.Height) d = r.Height;
            if (d > r.Width) d = r.Width;

            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        public static float Escala(Control c)
        {
            try
            {
                using (Graphics g = c.CreateGraphics())
                    return g.DpiX / 96f;
            }
            catch
            {
                return 1f;
            }
        }
    }
}
