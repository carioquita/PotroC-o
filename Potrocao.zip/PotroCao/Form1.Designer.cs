﻿namespace PotroCao
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.pnlLogoMenu = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblSecaoGerenciamento = new System.Windows.Forms.Label();
            this.btnClientes = new System.Windows.Forms.Button();
            this.btnConsultarClientes = new System.Windows.Forms.Button();
            this.btnPets = new System.Windows.Forms.Button();
            this.btnConsultarPets = new System.Windows.Forms.Button();
            this.lblSecaoAtendimento = new System.Windows.Forms.Label();
            this.btnAgendamentos = new System.Windows.Forms.Button();
            this.btnConsultarAgendamentos = new System.Windows.Forms.Button();
            this.lblSecaoEquipe = new System.Windows.Forms.Label();
            this.btnFuncionarios = new System.Windows.Forms.Button();
            this.btnConsultarFuncionarios = new System.Windows.Forms.Button();
            this.lblSecaoEstoque = new System.Windows.Forms.Label();
            this.btnProdutos = new System.Windows.Forms.Button();
            this.btnCategorias = new System.Windows.Forms.Button();
            this.btnEstoque = new System.Windows.Forms.Button();
            this.lblSecaoServicos = new System.Windows.Forms.Label();
            this.btnServicos = new System.Windows.Forms.Button();
            this.pnlConteudo = new System.Windows.Forms.Panel();
            this.lblSaudacao = new System.Windows.Forms.Label();
            this.lblSubtituloPainel = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.lblConexao = new System.Windows.Forms.Label();
            this.pnlIndicador1 = new System.Windows.Forms.Panel();
            this.lblIconeIndicador1 = new System.Windows.Forms.Label();
            this.lblValorIndicador1 = new System.Windows.Forms.Label();
            this.lblRotuloIndicador1 = new System.Windows.Forms.Label();
            this.lblExtraIndicador1 = new System.Windows.Forms.Label();
            this.pnlIndicador2 = new System.Windows.Forms.Panel();
            this.lblIconeIndicador2 = new System.Windows.Forms.Label();
            this.lblValorIndicador2 = new System.Windows.Forms.Label();
            this.lblRotuloIndicador2 = new System.Windows.Forms.Label();
            this.lblExtraIndicador2 = new System.Windows.Forms.Label();
            this.pnlIndicador3 = new System.Windows.Forms.Panel();
            this.lblIconeIndicador3 = new System.Windows.Forms.Label();
            this.lblValorIndicador3 = new System.Windows.Forms.Label();
            this.lblRotuloIndicador3 = new System.Windows.Forms.Label();
            this.lblExtraIndicador3 = new System.Windows.Forms.Label();
            this.pnlIndicador4 = new System.Windows.Forms.Panel();
            this.lblIconeIndicador4 = new System.Windows.Forms.Label();
            this.lblValorIndicador4 = new System.Windows.Forms.Label();
            this.lblRotuloIndicador4 = new System.Windows.Forms.Label();
            this.lblExtraIndicador4 = new System.Windows.Forms.Label();
            this.lblAcessoRapido = new System.Windows.Forms.Label();
            this.btnAtalhoNovoCliente = new System.Windows.Forms.Button();
            this.btnAtalhoNovoPet = new System.Windows.Forms.Button();
            this.btnAtalhoNovoAgendamento = new System.Windows.Forms.Button();
            this.btnAtalhoNovoFuncionario = new System.Windows.Forms.Button();
            this.btnAtalhoProdutos = new System.Windows.Forms.Button();
            this.lblProximos = new System.Windows.Forms.Label();
            this.lblProximosInfo = new System.Windows.Forms.Label();
            this.pnlProximos = new System.Windows.Forms.Panel();
            this.dgvProximos = new System.Windows.Forms.DataGridView();
            this.pnlMenu.SuspendLayout();
            this.pnlLogoMenu.SuspendLayout();
            this.pnlConteudo.SuspendLayout();
            this.pnlIndicador1.SuspendLayout();
            this.pnlIndicador2.SuspendLayout();
            this.pnlIndicador3.SuspendLayout();
            this.pnlIndicador4.SuspendLayout();
            this.pnlProximos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProximos)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMenu
            // 
            this.pnlMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.pnlMenu.Controls.Add(this.btnServicos);
            this.pnlMenu.Controls.Add(this.lblSecaoServicos);
            this.pnlMenu.Controls.Add(this.btnEstoque);
            this.pnlMenu.Controls.Add(this.btnCategorias);
            this.pnlMenu.Controls.Add(this.btnProdutos);
            this.pnlMenu.Controls.Add(this.lblSecaoEstoque);
            this.pnlMenu.Controls.Add(this.btnConsultarFuncionarios);
            this.pnlMenu.Controls.Add(this.btnFuncionarios);
            this.pnlMenu.Controls.Add(this.lblSecaoEquipe);
            this.pnlMenu.Controls.Add(this.btnConsultarAgendamentos);
            this.pnlMenu.Controls.Add(this.btnAgendamentos);
            this.pnlMenu.Controls.Add(this.lblSecaoAtendimento);
            this.pnlMenu.Controls.Add(this.btnConsultarPets);
            this.pnlMenu.Controls.Add(this.btnPets);
            this.pnlMenu.Controls.Add(this.btnConsultarClientes);
            this.pnlMenu.Controls.Add(this.btnClientes);
            this.pnlMenu.Controls.Add(this.lblSecaoGerenciamento);
            this.pnlMenu.Controls.Add(this.pnlLogoMenu);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenu.AutoScroll = true;
            this.pnlMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(250, 680);
            this.pnlMenu.TabIndex = 0;
            // 
            // pnlLogoMenu
            // 
            this.pnlLogoMenu.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left));
            this.pnlLogoMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlLogoMenu.Controls.Add(this.picLogo);
            this.pnlLogoMenu.Location = new System.Drawing.Point(16, 12);
            this.pnlLogoMenu.Name = "pnlLogoMenu";
            this.pnlLogoMenu.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.pnlLogoMenu.Size = new System.Drawing.Size(218, 100);
            this.pnlLogoMenu.TabIndex = 0;
            this.pnlLogoMenu.Tag = "cartao";
            // 
            // picLogo
            // 
            this.picLogo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.TabStop = false;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(100, 100);
            this.picLogo.TabIndex = 0;
            // 
            // lblSecaoGerenciamento
            // 
            this.lblSecaoGerenciamento.AutoSize = true;
            this.lblSecaoGerenciamento.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoGerenciamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(166)))), ((int)(((byte)(224)))));
            this.lblSecaoGerenciamento.Location = new System.Drawing.Point(26, 124);
            this.lblSecaoGerenciamento.Name = "lblSecaoGerenciamento";
            this.lblSecaoGerenciamento.TabIndex = 1;
            this.lblSecaoGerenciamento.Text = "GERENCIAMENTO";
            // 
            // btnClientes
            // 
            this.btnClientes.Location = new System.Drawing.Point(0, 144);
            this.btnClientes.Name = "btnClientes";
            this.btnClientes.Size = new System.Drawing.Size(250, 34);
            this.btnClientes.TabIndex = 2;
            this.btnClientes.Tag = "menu";
            this.btnClientes.Text = "Cadastrar Clientes";
            this.btnClientes.UseVisualStyleBackColor = false;
            this.btnClientes.Click += new System.EventHandler(this.btnClientes_Click);
            // 
            // btnConsultarClientes
            // 
            this.btnConsultarClientes.Location = new System.Drawing.Point(0, 178);
            this.btnConsultarClientes.Name = "btnConsultarClientes";
            this.btnConsultarClientes.Size = new System.Drawing.Size(250, 34);
            this.btnConsultarClientes.TabIndex = 3;
            this.btnConsultarClientes.Tag = "menu";
            this.btnConsultarClientes.Text = "Consultar Clientes";
            this.btnConsultarClientes.UseVisualStyleBackColor = false;
            this.btnConsultarClientes.Click += new System.EventHandler(this.btnConsultarClientes_Click);
            // 
            // btnPets
            // 
            this.btnPets.Location = new System.Drawing.Point(0, 212);
            this.btnPets.Name = "btnPets";
            this.btnPets.Size = new System.Drawing.Size(250, 34);
            this.btnPets.TabIndex = 4;
            this.btnPets.Tag = "menu";
            this.btnPets.Text = "Cadastrar Pets";
            this.btnPets.UseVisualStyleBackColor = false;
            this.btnPets.Click += new System.EventHandler(this.btnPets_Click);
            // 
            // btnConsultarPets
            // 
            this.btnConsultarPets.Location = new System.Drawing.Point(0, 246);
            this.btnConsultarPets.Name = "btnConsultarPets";
            this.btnConsultarPets.Size = new System.Drawing.Size(250, 34);
            this.btnConsultarPets.TabIndex = 5;
            this.btnConsultarPets.Tag = "menu";
            this.btnConsultarPets.Text = "Consultar Pets";
            this.btnConsultarPets.UseVisualStyleBackColor = false;
            this.btnConsultarPets.Click += new System.EventHandler(this.btnConsultarPets_Click);
            // 
            // lblSecaoAtendimento
            // 
            this.lblSecaoAtendimento.AutoSize = true;
            this.lblSecaoAtendimento.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoAtendimento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(166)))), ((int)(((byte)(224)))));
            this.lblSecaoAtendimento.Location = new System.Drawing.Point(26, 290);
            this.lblSecaoAtendimento.Name = "lblSecaoAtendimento";
            this.lblSecaoAtendimento.TabIndex = 6;
            this.lblSecaoAtendimento.Text = "ATENDIMENTO";
            // 
            // btnAgendamentos
            // 
            this.btnAgendamentos.Location = new System.Drawing.Point(0, 310);
            this.btnAgendamentos.Name = "btnAgendamentos";
            this.btnAgendamentos.Size = new System.Drawing.Size(250, 34);
            this.btnAgendamentos.TabIndex = 7;
            this.btnAgendamentos.Tag = "menu";
            this.btnAgendamentos.Text = "Agendamentos";
            this.btnAgendamentos.UseVisualStyleBackColor = false;
            this.btnAgendamentos.Click += new System.EventHandler(this.btnAgendamentos_Click);
            // 
            // btnConsultarAgendamentos
            // 
            this.btnConsultarAgendamentos.Location = new System.Drawing.Point(0, 344);
            this.btnConsultarAgendamentos.Name = "btnConsultarAgendamentos";
            this.btnConsultarAgendamentos.Size = new System.Drawing.Size(250, 34);
            this.btnConsultarAgendamentos.TabIndex = 8;
            this.btnConsultarAgendamentos.Tag = "menu";
            this.btnConsultarAgendamentos.Text = "Consultar Agendamentos";
            this.btnConsultarAgendamentos.UseVisualStyleBackColor = false;
            this.btnConsultarAgendamentos.Click += new System.EventHandler(this.btnConsultarAgendamentos_Click);
            // 
            // lblSecaoEquipe
            // 
            this.lblSecaoEquipe.AutoSize = true;
            this.lblSecaoEquipe.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoEquipe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(166)))), ((int)(((byte)(224)))));
            this.lblSecaoEquipe.Location = new System.Drawing.Point(26, 388);
            this.lblSecaoEquipe.Name = "lblSecaoEquipe";
            this.lblSecaoEquipe.TabIndex = 9;
            this.lblSecaoEquipe.Text = "EQUIPE";
            // 
            // btnFuncionarios
            // 
            this.btnFuncionarios.Location = new System.Drawing.Point(0, 408);
            this.btnFuncionarios.Name = "btnFuncionarios";
            this.btnFuncionarios.Size = new System.Drawing.Size(250, 34);
            this.btnFuncionarios.TabIndex = 10;
            this.btnFuncionarios.Tag = "menu";
            this.btnFuncionarios.Text = "Cadastrar Funcionários";
            this.btnFuncionarios.UseVisualStyleBackColor = false;
            this.btnFuncionarios.Click += new System.EventHandler(this.btnFuncionarios_Click);
            // 
            // btnConsultarFuncionarios
            // 
            this.btnConsultarFuncionarios.Location = new System.Drawing.Point(0, 442);
            this.btnConsultarFuncionarios.Name = "btnConsultarFuncionarios";
            this.btnConsultarFuncionarios.Size = new System.Drawing.Size(250, 34);
            this.btnConsultarFuncionarios.TabIndex = 11;
            this.btnConsultarFuncionarios.Tag = "menu";
            this.btnConsultarFuncionarios.Text = "Consultar Funcionários";
            this.btnConsultarFuncionarios.UseVisualStyleBackColor = false;
            this.btnConsultarFuncionarios.Click += new System.EventHandler(this.btnConsultarFuncionarios_Click);
            // 
            // lblSecaoEstoque
            // 
            this.lblSecaoEstoque.AutoSize = true;
            this.lblSecaoEstoque.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoEstoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(166)))), ((int)(((byte)(224)))));
            this.lblSecaoEstoque.Location = new System.Drawing.Point(26, 486);
            this.lblSecaoEstoque.Name = "lblSecaoEstoque";
            this.lblSecaoEstoque.TabIndex = 12;
            this.lblSecaoEstoque.Text = "ESTOQUE";
            // 
            // btnProdutos
            // 
            this.btnProdutos.Location = new System.Drawing.Point(0, 506);
            this.btnProdutos.Name = "btnProdutos";
            this.btnProdutos.Size = new System.Drawing.Size(250, 34);
            this.btnProdutos.TabIndex = 13;
            this.btnProdutos.Tag = "menu";
            this.btnProdutos.Text = "Produtos";
            this.btnProdutos.UseVisualStyleBackColor = false;
            this.btnProdutos.Click += new System.EventHandler(this.btnProdutos_Click);
            // 
            // btnCategorias
            // 
            this.btnCategorias.Location = new System.Drawing.Point(0, 540);
            this.btnCategorias.Name = "btnCategorias";
            this.btnCategorias.Size = new System.Drawing.Size(250, 34);
            this.btnCategorias.TabIndex = 14;
            this.btnCategorias.Tag = "menu";
            this.btnCategorias.Text = "Categorias";
            this.btnCategorias.UseVisualStyleBackColor = false;
            this.btnCategorias.Click += new System.EventHandler(this.btnCategorias_Click);
            // 
            // btnEstoque
            // 
            this.btnEstoque.Location = new System.Drawing.Point(0, 574);
            this.btnEstoque.Name = "btnEstoque";
            this.btnEstoque.Size = new System.Drawing.Size(250, 34);
            this.btnEstoque.TabIndex = 15;
            this.btnEstoque.Tag = "menu";
            this.btnEstoque.Text = "Controle de Estoque";
            this.btnEstoque.UseVisualStyleBackColor = false;
            this.btnEstoque.Click += new System.EventHandler(this.btnEstoque_Click);
            // 
            // lblSecaoServicos
            // 
            this.lblSecaoServicos.AutoSize = true;
            this.lblSecaoServicos.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecaoServicos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(166)))), ((int)(((byte)(224)))));
            this.lblSecaoServicos.Location = new System.Drawing.Point(26, 618);
            this.lblSecaoServicos.Name = "lblSecaoServicos";
            this.lblSecaoServicos.TabIndex = 16;
            this.lblSecaoServicos.Text = "SERVIÇOS";
            // 
            // btnServicos
            // 
            this.btnServicos.Location = new System.Drawing.Point(0, 638);
            this.btnServicos.Name = "btnServicos";
            this.btnServicos.Size = new System.Drawing.Size(250, 34);
            this.btnServicos.TabIndex = 17;
            this.btnServicos.Tag = "menu";
            this.btnServicos.Text = "Serviços";
            this.btnServicos.UseVisualStyleBackColor = false;
            this.btnServicos.Click += new System.EventHandler(this.btnServicos_Click);
            // 
            // pnlConteudo
            // 
            this.pnlConteudo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.pnlConteudo.Controls.Add(this.pnlProximos);
            this.pnlConteudo.Controls.Add(this.lblProximosInfo);
            this.pnlConteudo.Controls.Add(this.lblProximos);
            this.pnlConteudo.Controls.Add(this.btnAtalhoProdutos);
            this.pnlConteudo.Controls.Add(this.btnAtalhoNovoFuncionario);
            this.pnlConteudo.Controls.Add(this.btnAtalhoNovoAgendamento);
            this.pnlConteudo.Controls.Add(this.btnAtalhoNovoPet);
            this.pnlConteudo.Controls.Add(this.btnAtalhoNovoCliente);
            this.pnlConteudo.Controls.Add(this.lblAcessoRapido);
            this.pnlConteudo.Controls.Add(this.pnlIndicador4);
            this.pnlConteudo.Controls.Add(this.pnlIndicador3);
            this.pnlConteudo.Controls.Add(this.pnlIndicador2);
            this.pnlConteudo.Controls.Add(this.pnlIndicador1);
            this.pnlConteudo.Controls.Add(this.lblConexao);
            this.pnlConteudo.Controls.Add(this.lblData);
            this.pnlConteudo.Controls.Add(this.lblSubtituloPainel);
            this.pnlConteudo.Controls.Add(this.lblSaudacao);
            this.pnlConteudo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlConteudo.AutoScroll = true;
            this.pnlConteudo.Location = new System.Drawing.Point(250, 0);
            this.pnlConteudo.Name = "pnlConteudo";
            this.pnlConteudo.Size = new System.Drawing.Size(950, 680);
            this.pnlConteudo.TabIndex = 1;
            this.pnlConteudo.Resize += new System.EventHandler(this.pnlConteudo_Resize);
            // 
            // lblSaudacao
            // 
            this.lblSaudacao.AutoSize = true;
            this.lblSaudacao.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaudacao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblSaudacao.Location = new System.Drawing.Point(34, 26);
            this.lblSaudacao.Name = "lblSaudacao";
            this.lblSaudacao.TabIndex = 0;
            this.lblSaudacao.Text = "Olá! Seja bem-vindo ao PotroCão.";
            // 
            // lblSubtituloPainel
            // 
            this.lblSubtituloPainel.AutoSize = true;
            this.lblSubtituloPainel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtituloPainel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblSubtituloPainel.Location = new System.Drawing.Point(37, 70);
            this.lblSubtituloPainel.Name = "lblSubtituloPainel";
            this.lblSubtituloPainel.TabIndex = 1;
            this.lblSubtituloPainel.Text = "Gerencie seu pet shop com praticidade, organização e carinho.";
            // 
            // lblData
            // 
            this.lblData.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.lblData.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(32)))), ((int)(((byte)(181)))));
            this.lblData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblData.Location = new System.Drawing.Point(560, 30);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(354, 24);
            this.lblData.TabIndex = 2;
            this.lblData.Text = "";
            // 
            // lblConexao
            // 
            this.lblConexao.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.lblConexao.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConexao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblConexao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblConexao.Location = new System.Drawing.Point(560, 56);
            this.lblConexao.Name = "lblConexao";
            this.lblConexao.Size = new System.Drawing.Size(354, 20);
            this.lblConexao.TabIndex = 3;
            this.lblConexao.Text = "";
            // 
            // pnlIndicador1
            // 
            this.pnlIndicador1.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left));
            this.pnlIndicador1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlIndicador1.Controls.Add(this.lblExtraIndicador1);
            this.pnlIndicador1.Controls.Add(this.lblRotuloIndicador1);
            this.pnlIndicador1.Controls.Add(this.lblValorIndicador1);
            this.pnlIndicador1.Controls.Add(this.lblIconeIndicador1);
            this.pnlIndicador1.Location = new System.Drawing.Point(36, 112);
            this.pnlIndicador1.Name = "pnlIndicador1";
            this.pnlIndicador1.Size = new System.Drawing.Size(206, 104);
            this.pnlIndicador1.TabIndex = 4;
            this.pnlIndicador1.Tag = "cartao";
            // 
            // lblIconeIndicador1
            // 
            this.lblIconeIndicador1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconeIndicador1.Location = new System.Drawing.Point(16, 18);
            this.lblIconeIndicador1.Name = "lblIconeIndicador1";
            this.lblIconeIndicador1.Size = new System.Drawing.Size(44, 44);
            this.lblIconeIndicador1.TabIndex = 0;
            this.lblIconeIndicador1.Text = "";
            // 
            // lblValorIndicador1
            // 
            this.lblValorIndicador1.AutoSize = true;
            this.lblValorIndicador1.Font = new System.Drawing.Font("Segoe UI Semibold", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorIndicador1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblValorIndicador1.Location = new System.Drawing.Point(68, 10);
            this.lblValorIndicador1.Name = "lblValorIndicador1";
            this.lblValorIndicador1.TabIndex = 1;
            this.lblValorIndicador1.Text = "–";
            // 
            // lblRotuloIndicador1
            // 
            this.lblRotuloIndicador1.AutoSize = true;
            this.lblRotuloIndicador1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRotuloIndicador1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblRotuloIndicador1.Location = new System.Drawing.Point(70, 54);
            this.lblRotuloIndicador1.Name = "lblRotuloIndicador1";
            this.lblRotuloIndicador1.TabIndex = 2;
            this.lblRotuloIndicador1.Text = "Clientes ativos";
            // 
            // lblExtraIndicador1
            // 
            this.lblExtraIndicador1.AutoSize = true;
            this.lblExtraIndicador1.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtraIndicador1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(22)))), ((int)(((byte)(114)))));
            this.lblExtraIndicador1.Location = new System.Drawing.Point(70, 74);
            this.lblExtraIndicador1.Name = "lblExtraIndicador1";
            this.lblExtraIndicador1.TabIndex = 3;
            this.lblExtraIndicador1.Text = "";
            // 
            // pnlIndicador2
            // 
            this.pnlIndicador2.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left));
            this.pnlIndicador2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlIndicador2.Controls.Add(this.lblExtraIndicador2);
            this.pnlIndicador2.Controls.Add(this.lblRotuloIndicador2);
            this.pnlIndicador2.Controls.Add(this.lblValorIndicador2);
            this.pnlIndicador2.Controls.Add(this.lblIconeIndicador2);
            this.pnlIndicador2.Location = new System.Drawing.Point(260, 112);
            this.pnlIndicador2.Name = "pnlIndicador2";
            this.pnlIndicador2.Size = new System.Drawing.Size(206, 104);
            this.pnlIndicador2.TabIndex = 5;
            this.pnlIndicador2.Tag = "cartao";
            // 
            // lblIconeIndicador2
            // 
            this.lblIconeIndicador2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconeIndicador2.Location = new System.Drawing.Point(16, 18);
            this.lblIconeIndicador2.Name = "lblIconeIndicador2";
            this.lblIconeIndicador2.Size = new System.Drawing.Size(44, 44);
            this.lblIconeIndicador2.TabIndex = 0;
            this.lblIconeIndicador2.Text = "";
            // 
            // lblValorIndicador2
            // 
            this.lblValorIndicador2.AutoSize = true;
            this.lblValorIndicador2.Font = new System.Drawing.Font("Segoe UI Semibold", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorIndicador2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblValorIndicador2.Location = new System.Drawing.Point(68, 10);
            this.lblValorIndicador2.Name = "lblValorIndicador2";
            this.lblValorIndicador2.TabIndex = 1;
            this.lblValorIndicador2.Text = "–";
            // 
            // lblRotuloIndicador2
            // 
            this.lblRotuloIndicador2.AutoSize = true;
            this.lblRotuloIndicador2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRotuloIndicador2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblRotuloIndicador2.Location = new System.Drawing.Point(70, 54);
            this.lblRotuloIndicador2.Name = "lblRotuloIndicador2";
            this.lblRotuloIndicador2.TabIndex = 2;
            this.lblRotuloIndicador2.Text = "Pets ativos";
            // 
            // lblExtraIndicador2
            // 
            this.lblExtraIndicador2.AutoSize = true;
            this.lblExtraIndicador2.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtraIndicador2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(22)))), ((int)(((byte)(114)))));
            this.lblExtraIndicador2.Location = new System.Drawing.Point(70, 74);
            this.lblExtraIndicador2.Name = "lblExtraIndicador2";
            this.lblExtraIndicador2.TabIndex = 3;
            this.lblExtraIndicador2.Text = "";
            // 
            // pnlIndicador3
            // 
            this.pnlIndicador3.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left));
            this.pnlIndicador3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlIndicador3.Controls.Add(this.lblExtraIndicador3);
            this.pnlIndicador3.Controls.Add(this.lblRotuloIndicador3);
            this.pnlIndicador3.Controls.Add(this.lblValorIndicador3);
            this.pnlIndicador3.Controls.Add(this.lblIconeIndicador3);
            this.pnlIndicador3.Location = new System.Drawing.Point(484, 112);
            this.pnlIndicador3.Name = "pnlIndicador3";
            this.pnlIndicador3.Size = new System.Drawing.Size(206, 104);
            this.pnlIndicador3.TabIndex = 6;
            this.pnlIndicador3.Tag = "cartao";
            // 
            // lblIconeIndicador3
            // 
            this.lblIconeIndicador3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconeIndicador3.Location = new System.Drawing.Point(16, 18);
            this.lblIconeIndicador3.Name = "lblIconeIndicador3";
            this.lblIconeIndicador3.Size = new System.Drawing.Size(44, 44);
            this.lblIconeIndicador3.TabIndex = 0;
            this.lblIconeIndicador3.Text = "";
            // 
            // lblValorIndicador3
            // 
            this.lblValorIndicador3.AutoSize = true;
            this.lblValorIndicador3.Font = new System.Drawing.Font("Segoe UI Semibold", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorIndicador3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblValorIndicador3.Location = new System.Drawing.Point(68, 10);
            this.lblValorIndicador3.Name = "lblValorIndicador3";
            this.lblValorIndicador3.TabIndex = 1;
            this.lblValorIndicador3.Text = "–";
            // 
            // lblRotuloIndicador3
            // 
            this.lblRotuloIndicador3.AutoSize = true;
            this.lblRotuloIndicador3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRotuloIndicador3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblRotuloIndicador3.Location = new System.Drawing.Point(70, 54);
            this.lblRotuloIndicador3.Name = "lblRotuloIndicador3";
            this.lblRotuloIndicador3.TabIndex = 2;
            this.lblRotuloIndicador3.Text = "Agendamentos pendentes";
            // 
            // lblExtraIndicador3
            // 
            this.lblExtraIndicador3.AutoSize = true;
            this.lblExtraIndicador3.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtraIndicador3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(22)))), ((int)(((byte)(114)))));
            this.lblExtraIndicador3.Location = new System.Drawing.Point(70, 74);
            this.lblExtraIndicador3.Name = "lblExtraIndicador3";
            this.lblExtraIndicador3.TabIndex = 3;
            this.lblExtraIndicador3.Text = "";
            // 
            // pnlIndicador4
            // 
            this.pnlIndicador4.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left));
            this.pnlIndicador4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlIndicador4.Controls.Add(this.lblExtraIndicador4);
            this.pnlIndicador4.Controls.Add(this.lblRotuloIndicador4);
            this.pnlIndicador4.Controls.Add(this.lblValorIndicador4);
            this.pnlIndicador4.Controls.Add(this.lblIconeIndicador4);
            this.pnlIndicador4.Location = new System.Drawing.Point(708, 112);
            this.pnlIndicador4.Name = "pnlIndicador4";
            this.pnlIndicador4.Size = new System.Drawing.Size(206, 104);
            this.pnlIndicador4.TabIndex = 7;
            this.pnlIndicador4.Tag = "cartao";
            // 
            // lblIconeIndicador4
            // 
            this.lblIconeIndicador4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIconeIndicador4.Location = new System.Drawing.Point(16, 18);
            this.lblIconeIndicador4.Name = "lblIconeIndicador4";
            this.lblIconeIndicador4.Size = new System.Drawing.Size(44, 44);
            this.lblIconeIndicador4.TabIndex = 0;
            this.lblIconeIndicador4.Text = "";
            // 
            // lblValorIndicador4
            // 
            this.lblValorIndicador4.AutoSize = true;
            this.lblValorIndicador4.Font = new System.Drawing.Font("Segoe UI Semibold", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorIndicador4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblValorIndicador4.Location = new System.Drawing.Point(68, 10);
            this.lblValorIndicador4.Name = "lblValorIndicador4";
            this.lblValorIndicador4.TabIndex = 1;
            this.lblValorIndicador4.Text = "–";
            // 
            // lblRotuloIndicador4
            // 
            this.lblRotuloIndicador4.AutoSize = true;
            this.lblRotuloIndicador4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRotuloIndicador4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblRotuloIndicador4.Location = new System.Drawing.Point(70, 54);
            this.lblRotuloIndicador4.Name = "lblRotuloIndicador4";
            this.lblRotuloIndicador4.TabIndex = 2;
            this.lblRotuloIndicador4.Text = "Produtos ativos";
            // 
            // lblExtraIndicador4
            // 
            this.lblExtraIndicador4.AutoSize = true;
            this.lblExtraIndicador4.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtraIndicador4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(22)))), ((int)(((byte)(114)))));
            this.lblExtraIndicador4.Location = new System.Drawing.Point(70, 74);
            this.lblExtraIndicador4.Name = "lblExtraIndicador4";
            this.lblExtraIndicador4.TabIndex = 3;
            this.lblExtraIndicador4.Text = "";
            // 
            // lblAcessoRapido
            // 
            this.lblAcessoRapido.AutoSize = true;
            this.lblAcessoRapido.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAcessoRapido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblAcessoRapido.Location = new System.Drawing.Point(34, 238);
            this.lblAcessoRapido.Name = "lblAcessoRapido";
            this.lblAcessoRapido.TabIndex = 8;
            this.lblAcessoRapido.Text = "Acesso rápido";
            // 
            // btnAtalhoNovoCliente
            // 
            this.btnAtalhoNovoCliente.AccessibleName = "btnClientes";
            this.btnAtalhoNovoCliente.Location = new System.Drawing.Point(36, 272);
            this.btnAtalhoNovoCliente.Name = "btnAtalhoNovoCliente";
            this.btnAtalhoNovoCliente.Size = new System.Drawing.Size(164, 72);
            this.btnAtalhoNovoCliente.TabIndex = 9;
            this.btnAtalhoNovoCliente.Tag = "atalho:violeta";
            this.btnAtalhoNovoCliente.Text = "Novo cliente";
            this.btnAtalhoNovoCliente.UseVisualStyleBackColor = false;
            this.btnAtalhoNovoCliente.Click += new System.EventHandler(this.btnClientes_Click);
            // 
            // btnAtalhoNovoPet
            // 
            this.btnAtalhoNovoPet.AccessibleName = "btnPets";
            this.btnAtalhoNovoPet.Location = new System.Drawing.Point(214, 272);
            this.btnAtalhoNovoPet.Name = "btnAtalhoNovoPet";
            this.btnAtalhoNovoPet.Size = new System.Drawing.Size(164, 72);
            this.btnAtalhoNovoPet.TabIndex = 10;
            this.btnAtalhoNovoPet.Tag = "atalho:magenta";
            this.btnAtalhoNovoPet.Text = "Novo pet";
            this.btnAtalhoNovoPet.UseVisualStyleBackColor = false;
            this.btnAtalhoNovoPet.Click += new System.EventHandler(this.btnPets_Click);
            // 
            // btnAtalhoNovoAgendamento
            // 
            this.btnAtalhoNovoAgendamento.AccessibleName = "btnAgendamentos";
            this.btnAtalhoNovoAgendamento.Location = new System.Drawing.Point(392, 272);
            this.btnAtalhoNovoAgendamento.Name = "btnAtalhoNovoAgendamento";
            this.btnAtalhoNovoAgendamento.Size = new System.Drawing.Size(164, 72);
            this.btnAtalhoNovoAgendamento.TabIndex = 11;
            this.btnAtalhoNovoAgendamento.Tag = "atalho:dourado";
            this.btnAtalhoNovoAgendamento.Text = "Novo agendamento";
            this.btnAtalhoNovoAgendamento.UseVisualStyleBackColor = false;
            this.btnAtalhoNovoAgendamento.Click += new System.EventHandler(this.btnAgendamentos_Click);
            // 
            // btnAtalhoNovoFuncionario
            // 
            this.btnAtalhoNovoFuncionario.AccessibleName = "btnFuncionarios";
            this.btnAtalhoNovoFuncionario.Location = new System.Drawing.Point(570, 272);
            this.btnAtalhoNovoFuncionario.Name = "btnAtalhoNovoFuncionario";
            this.btnAtalhoNovoFuncionario.Size = new System.Drawing.Size(164, 72);
            this.btnAtalhoNovoFuncionario.TabIndex = 12;
            this.btnAtalhoNovoFuncionario.Tag = "atalho:roxo";
            this.btnAtalhoNovoFuncionario.Text = "Novo funcionário";
            this.btnAtalhoNovoFuncionario.UseVisualStyleBackColor = false;
            this.btnAtalhoNovoFuncionario.Click += new System.EventHandler(this.btnFuncionarios_Click);
            // 
            // btnAtalhoProdutos
            // 
            this.btnAtalhoProdutos.AccessibleName = "btnProdutos";
            this.btnAtalhoProdutos.Location = new System.Drawing.Point(748, 272);
            this.btnAtalhoProdutos.Name = "btnAtalhoProdutos";
            this.btnAtalhoProdutos.Size = new System.Drawing.Size(164, 72);
            this.btnAtalhoProdutos.TabIndex = 13;
            this.btnAtalhoProdutos.Tag = "atalho:violeta";
            this.btnAtalhoProdutos.Text = "Consultar produtos";
            this.btnAtalhoProdutos.UseVisualStyleBackColor = false;
            this.btnAtalhoProdutos.Click += new System.EventHandler(this.btnProdutos_Click);
            // 
            // lblProximos
            // 
            this.lblProximos.AutoSize = true;
            this.lblProximos.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProximos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(8)))), ((int)(((byte)(95)))));
            this.lblProximos.Location = new System.Drawing.Point(34, 366);
            this.lblProximos.Name = "lblProximos";
            this.lblProximos.TabIndex = 14;
            this.lblProximos.Text = "Próximos agendamentos";
            // 
            // lblProximosInfo
            // 
            this.lblProximosInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right));
            this.lblProximosInfo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProximosInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.lblProximosInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblProximosInfo.Location = new System.Drawing.Point(560, 370);
            this.lblProximosInfo.Name = "lblProximosInfo";
            this.lblProximosInfo.Size = new System.Drawing.Size(354, 20);
            this.lblProximosInfo.TabIndex = 15;
            this.lblProximosInfo.Text = "Pendentes e confirmados, a partir de agora";
            // 
            // pnlProximos
            // 
            this.pnlProximos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Bottom));
            this.pnlProximos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlProximos.Controls.Add(this.dgvProximos);
            this.pnlProximos.Location = new System.Drawing.Point(36, 398);
            this.pnlProximos.Name = "pnlProximos";
            this.pnlProximos.Padding = new System.Windows.Forms.Padding(12);
            this.pnlProximos.Size = new System.Drawing.Size(878, 252);
            this.pnlProximos.TabIndex = 16;
            this.pnlProximos.Tag = "cartao";
            // 
            // dgvProximos
            // 
            this.dgvProximos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProximos.AllowUserToAddRows = false;
            this.dgvProximos.AllowUserToDeleteRows = false;
            this.dgvProximos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProximos.BackgroundColor = System.Drawing.Color.White;
            this.dgvProximos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvProximos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvProximos.MultiSelect = false;
            this.dgvProximos.ReadOnly = true;
            this.dgvProximos.RowHeadersVisible = false;
            this.dgvProximos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProximos.Location = new System.Drawing.Point(0, 0);
            this.dgvProximos.Name = "dgvProximos";
            this.dgvProximos.Size = new System.Drawing.Size(100, 100);
            this.dgvProximos.TabIndex = 0;
            this.dgvProximos.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvProximos_CellFormatting);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1200, 680);
            this.Controls.Add(this.pnlConteudo);
            this.Controls.Add(this.pnlMenu);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1040, 640);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PotroCão - Sistema de Gestão";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProximos)).EndInit();
            this.pnlMenu.ResumeLayout(false);
            this.pnlMenu.PerformLayout();
            this.pnlLogoMenu.ResumeLayout(false);
            this.pnlLogoMenu.PerformLayout();
            this.pnlConteudo.ResumeLayout(false);
            this.pnlConteudo.PerformLayout();
            this.pnlIndicador1.ResumeLayout(false);
            this.pnlIndicador1.PerformLayout();
            this.pnlIndicador2.ResumeLayout(false);
            this.pnlIndicador2.PerformLayout();
            this.pnlIndicador3.ResumeLayout(false);
            this.pnlIndicador3.PerformLayout();
            this.pnlIndicador4.ResumeLayout(false);
            this.pnlIndicador4.PerformLayout();
            this.pnlProximos.ResumeLayout(false);
            this.pnlProximos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Panel pnlLogoMenu;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblSecaoGerenciamento;
        private System.Windows.Forms.Button btnClientes;
        private System.Windows.Forms.Button btnConsultarClientes;
        private System.Windows.Forms.Button btnPets;
        private System.Windows.Forms.Button btnConsultarPets;
        private System.Windows.Forms.Label lblSecaoAtendimento;
        private System.Windows.Forms.Button btnAgendamentos;
        private System.Windows.Forms.Button btnConsultarAgendamentos;
        private System.Windows.Forms.Label lblSecaoEquipe;
        private System.Windows.Forms.Button btnFuncionarios;
        private System.Windows.Forms.Button btnConsultarFuncionarios;
        private System.Windows.Forms.Label lblSecaoEstoque;
        private System.Windows.Forms.Button btnProdutos;
        private System.Windows.Forms.Button btnCategorias;
        private System.Windows.Forms.Button btnEstoque;
        private System.Windows.Forms.Label lblSecaoServicos;
        private System.Windows.Forms.Button btnServicos;
        private System.Windows.Forms.Panel pnlConteudo;
        private System.Windows.Forms.Label lblSaudacao;
        private System.Windows.Forms.Label lblSubtituloPainel;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblConexao;
        private System.Windows.Forms.Panel pnlIndicador1;
        private System.Windows.Forms.Label lblIconeIndicador1;
        private System.Windows.Forms.Label lblValorIndicador1;
        private System.Windows.Forms.Label lblRotuloIndicador1;
        private System.Windows.Forms.Label lblExtraIndicador1;
        private System.Windows.Forms.Panel pnlIndicador2;
        private System.Windows.Forms.Label lblIconeIndicador2;
        private System.Windows.Forms.Label lblValorIndicador2;
        private System.Windows.Forms.Label lblRotuloIndicador2;
        private System.Windows.Forms.Label lblExtraIndicador2;
        private System.Windows.Forms.Panel pnlIndicador3;
        private System.Windows.Forms.Label lblIconeIndicador3;
        private System.Windows.Forms.Label lblValorIndicador3;
        private System.Windows.Forms.Label lblRotuloIndicador3;
        private System.Windows.Forms.Label lblExtraIndicador3;
        private System.Windows.Forms.Panel pnlIndicador4;
        private System.Windows.Forms.Label lblIconeIndicador4;
        private System.Windows.Forms.Label lblValorIndicador4;
        private System.Windows.Forms.Label lblRotuloIndicador4;
        private System.Windows.Forms.Label lblExtraIndicador4;
        private System.Windows.Forms.Label lblAcessoRapido;
        private System.Windows.Forms.Button btnAtalhoNovoCliente;
        private System.Windows.Forms.Button btnAtalhoNovoPet;
        private System.Windows.Forms.Button btnAtalhoNovoAgendamento;
        private System.Windows.Forms.Button btnAtalhoNovoFuncionario;
        private System.Windows.Forms.Button btnAtalhoProdutos;
        private System.Windows.Forms.Label lblProximos;
        private System.Windows.Forms.Label lblProximosInfo;
        private System.Windows.Forms.Panel pnlProximos;
        private System.Windows.Forms.DataGridView dgvProximos;
    }
}
