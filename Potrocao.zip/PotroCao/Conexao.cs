﻿using MySql.Data.MySqlClient;

namespace PotroCao
{
    public class Conexao
    {
        private static string servidor = "localhost";
        private static string banco = "potrocao";
        private static string usuario = "root";
        private static string senha = "";

        public static MySqlConnection Conectar()
        {
            string conexao = "Server=" + servidor +
                             ";Database=" + banco +
                             ";Uid=" + usuario +
                             ";Pwd=" + senha + ";";

            return new MySqlConnection(conexao);
        }
    }
}