﻿using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PotroCao.Formularios;

namespace PotroCao
{
    // Tela principal: menu lateral + painel com indicadores reais do banco
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Tema.Aplicar(this);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            picLogo.Image = Tema.Logo;

            CultureInfo br = new CultureInfo("pt-BR");
            string data = DateTime.Today.ToString("dddd, dd 'de' MMMM 'de' yyyy", br);
            lblData.Text = char.ToUpper(data[0]) + data.Substring(1);

            ConfigurarIconesIndicadores();
            AjustarLayoutPainel();
            AtualizarPainel();
        }

        // ================== ABERTURA DAS TELAS ==================

        // Abre uma tela, destaca o item do menu enquanto ela estiver aberta
        // e atualiza os indicadores quando ela for fechada.
        private void AbrirTela(Form tela, Button itemMenu)
        {
            Tema.SelecionarMenu(itemMenu);

            try
            {
                tela.ShowDialog(this);
            }
            finally
            {
                tela.Dispose();
                Tema.SelecionarMenu(null);
                AtualizarPainel();
            }
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmCadastrarCliente(), btnClientes);
        }

        private void btnConsultarClientes_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmConsultarCliente(), btnConsultarClientes);
        }

        private void btnPets_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmCadastrarPet(), btnPets);
        }

        private void btnConsultarPets_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmConsultarPet(), btnConsultarPets);
        }

        private void btnAgendamentos_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmCadastrarAgendamento(), btnAgendamentos);
        }

        private void btnConsultarAgendamentos_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmConsultarAgendamento(), btnConsultarAgendamentos);
        }

        private void btnFuncionarios_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmCadastrarFuncionario(), btnFuncionarios);
        }

        private void btnConsultarFuncionarios_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmConsultarFuncionario(), btnConsultarFuncionarios);
        }

        private void btnProdutos_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmConsultarProduto(), btnProdutos);
        }

        private void btnCategorias_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmConsultarCategoria(), btnCategorias);
        }

        private void btnEstoque_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmEstoque(), btnEstoque);
        }

        private void btnServicos_Click(object sender, EventArgs e)
        {
            AbrirTela(new FrmConsultarServico(), btnServicos);
        }

        // ================== INDICADORES (dados reais do banco) ==================

        private void ConfigurarIconesIndicadores()
        {
            ConfigurarIcone(lblIconeIndicador1, Tema.IcPessoas, Tema.Violeta);
            ConfigurarIcone(lblIconeIndicador2, Tema.IcPet, Tema.Magenta);
            ConfigurarIcone(lblIconeIndicador3, Tema.IcAgenda, Tema.Dourado);
            ConfigurarIcone(lblIconeIndicador4, Tema.IcProduto, Tema.RoxoProfundo);
        }

        private void ConfigurarIcone(Label lbl, string glifo, Color cor)
        {
            bool emoji = glifo == Tema.IcPet;
            Font fonteIcone = emoji ? Tema.Fonte(16f) : Tema.FonteIcones(16f);

            lbl.Font = fonteIcone ?? Tema.FonteForte(16f);
            lbl.Text = fonteIcone != null ? glifo : "•";
            lbl.ForeColor = cor == Tema.Dourado ? Tema.DouradoTexto : cor;
            lbl.BackColor = Color.FromArgb(34, cor);
        }

        private void AtualizarPainel()
        {
            try
            {
                using (MySqlConnection conexao = Conexao.Conectar())
                {
                    conexao.Open();

                    lblValorIndicador1.Text = Contar(conexao,
                        "SELECT COUNT(*) FROM cliente WHERE status = 'Ativo'").ToString();

                    lblValorIndicador2.Text = Contar(conexao,
                        "SELECT COUNT(*) FROM pet WHERE status = 'Ativo'").ToString();

                    int pendentes = Contar(conexao,
                        "SELECT COUNT(*) FROM agendamento WHERE status = 'Pendente' AND data >= CURDATE()");
                    lblValorIndicador3.Text = pendentes.ToString();

                    int hoje = Contar(conexao,
                        "SELECT COUNT(*) FROM agendamento WHERE data = CURDATE() AND status <> 'Cancelado'");
                    lblExtraIndicador3.ForeColor = Tema.DouradoTexto;
                    lblExtraIndicador3.Text = hoje == 0 ? "Nenhum atendimento hoje"
                        : hoje == 1 ? "1 atendimento hoje" : hoje + " atendimentos hoje";

                    lblValorIndicador4.Text = Contar(conexao,
                        "SELECT COUNT(*) FROM produto WHERE ativo = 1").ToString();

                    int baixo = Contar(conexao,
                        "SELECT COUNT(*) FROM produto WHERE ativo = 1 AND quantidadeEstoque <= " +
                        Utilitarios.ESTOQUE_BAIXO);
                    lblExtraIndicador4.Text = baixo == 0 ? "" :
                        baixo == 1 ? "1 com estoque baixo" : baixo + " com estoque baixo";

                    CarregarProximosAgendamentos(conexao);
                }

                lblConexao.ForeColor = Tema.Sucesso;
                lblConexao.Text = "● Conectado ao banco de dados";
            }
            catch (Exception ex)
            {
                lblConexao.ForeColor = Tema.Magenta;
                lblConexao.Text = "● Sem conexão com o banco (verifique o XAMPP)";

                foreach (Label l in new[] { lblValorIndicador1, lblValorIndicador2,
                                            lblValorIndicador3, lblValorIndicador4 })
                    l.Text = "–";

                if (!avisouErroConexao)
                {
                    avisouErroConexao = true;
                    CaixaMensagem.Show("Não foi possível conectar ao banco de dados.\n\n" +
                        "Confira se o MySQL do XAMPP está iniciado.\n\nDetalhe: " + ex.Message,
                        "PotroCão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool avisouErroConexao = false;

        private int Contar(MySqlConnection conexao, string sql)
        {
            using (MySqlCommand comando = new MySqlCommand(sql, conexao))
            {
                return Convert.ToInt32(comando.ExecuteScalar());
            }
        }

        private void CarregarProximosAgendamentos(MySqlConnection conexao)
        {
            string sql = @"
                SELECT
                    DATE_FORMAT(ag.data, '%d/%m/%Y') AS 'Data',
                    TIME_FORMAT(ag.horario, '%H:%i') AS 'Horário',
                    cli.nome AS 'Cliente',
                    p.nome AS 'Pet',
                    IFNULL(fun.nome, '—') AS 'Funcionário',
                    ag.status AS 'Status'
                FROM agendamento ag
                INNER JOIN cliente cli ON cli.codCli = ag.codCli
                INNER JOIN pet p ON p.codpet = ag.codpet
                LEFT JOIN funcionario fun ON fun.codFun = ag.codFun
                WHERE ag.status IN ('Pendente', 'Confirmado')
                  AND (ag.data > CURDATE() OR (ag.data = CURDATE() AND ag.horario >= CURTIME()))
                ORDER BY ag.data, ag.horario
                LIMIT 10";

            using (MySqlCommand comando = new MySqlCommand(sql, conexao))
            using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
            {
                DataTable tabela = new DataTable();
                adaptador.Fill(tabela);
                dgvProximos.DataSource = tabela;
            }

            if (dgvProximos.Columns.Contains("Data")) dgvProximos.Columns["Data"].FillWeight = 60;
            if (dgvProximos.Columns.Contains("Horário")) dgvProximos.Columns["Horário"].FillWeight = 45;
            if (dgvProximos.Columns.Contains("Status")) dgvProximos.Columns["Status"].FillWeight = 60;
        }

        // Status com cor: pendente em dourado, confirmado em violeta
        private void dgvProximos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || dgvProximos.Columns[e.ColumnIndex].Name != "Status")
                return;

            string status = Convert.ToString(e.Value);

            if (status == "Pendente")
                e.CellStyle.ForeColor = Tema.DouradoTexto;
            else if (status == "Confirmado")
                e.CellStyle.ForeColor = Tema.Violeta;

            e.CellStyle.Font = Tema.FonteForte(9.75f);
        }

        // ================== LAYOUT RESPONSIVO DO PAINEL ==================

        private void pnlConteudo_Resize(object sender, EventArgs e)
        {
            AjustarLayoutPainel();
        }

        // Distribui os cartões e atalhos pela largura disponível
        private void AjustarLayoutPainel()
        {
            if (pnlConteudo == null || pnlIndicador1 == null)
                return;

            float esc = Tema.Escala(this);
            int margem = (int)(36 * esc);
            int disponivel = pnlConteudo.ClientSize.Width - margem * 2;

            if (disponivel < 400)
                return;

            Panel[] cartoes = { pnlIndicador1, pnlIndicador2, pnlIndicador3, pnlIndicador4 };
            DistribuirNaLinha(cartoes, margem, disponivel, (int)(18 * esc));

            Button[] atalhos = { btnAtalhoNovoCliente, btnAtalhoNovoPet, btnAtalhoNovoAgendamento,
                                 btnAtalhoNovoFuncionario, btnAtalhoProdutos };
            DistribuirNaLinha(atalhos, margem, disponivel, (int)(14 * esc));

            pnlProximos.Left = margem;
            pnlProximos.Width = disponivel;
        }

        private void DistribuirNaLinha(Control[] itens, int inicio, int largura, int espaco)
        {
            int cada = (largura - espaco * (itens.Length - 1)) / itens.Length;
            int x = inicio;

            foreach (Control c in itens)
            {
                c.Left = x;
                c.Width = cada;
                x += cada + espaco;
                c.Invalidate();
            }
        }
    }
}
